# Knowledge Base: Storytelling Frameworks

## Quick Reference

### By Duration
| Duration | Framework | Agent |
|----------|-----------|-------|
| 30s | ABT | @park-howell |
| 2min | SB7 one-liner + plan | @donald-miller |
| 5min | 4 Stories / 5-Second Moment | @kindra-hall / @matthew-dicks |
| 15min | Sparkline | @nancy-duarte |
| 20min | STRONG | @oren-klaff |
| 45min+ | Hero's Journey / Sparkline | @joseph-campbell / @nancy-duarte |
| Serial | Story Circle | @dan-harmon |

### By Context
| Context | Primary Framework | Secondary |
|---------|------------------|-----------|
| Brand | SB7 (StoryBrand) | ABT |
| Sales | 4 Stories (Value + Customer) | STRONG |
| Pitch/Investor | STRONG | Sparkline |
| Keynote | Sparkline | Hero's Journey |
| Personal | 5-Second Moment | Story Circle |
| Movement/Cause | Self/Us/Now | Hero's Journey |
| Course/Series | Story Circle | Save the Cat |
| Quick format | ABT | SB7 one-liner |

### Framework Summaries
- **Hero's Journey (Campbell):** 12 stages, departure → initiation → return
- **Story Grid (Coyne):** Genre = promise, 5 Commandments, value shift
- **SB7 (Miller):** Character → Problem → Guide → Plan → CTA → Failure → Success
- **Sparkline (Duarte):** What IS ↔ What COULD BE → New Bliss
- **Story Circle (Harmon):** 8 beats circular, great for serial content
- **Save the Cat (Snyder):** 15 beats, cinematic structure
- **STRONG (Klaff):** Set frame → Story → Intrigue → Prize → Hook → Decision
- **4 Stories (Hall):** Value + Founder + Purpose + Customer
- **5-Second Moment (Dicks):** Find the transformation moment, build backwards
- **Self/Us/Now (Ganz):** Personal → Collective → Urgent
- **ABT (Howell):** And (setup) / But (conflict) / Therefore (resolution)

### Universal Principles
1. Hero = Client, Brand = Mentor (ALWAYS)
2. Every story needs CONFLICT (no conflict = no story)
3. Specific > Generic (details create believability)
4. Show, don't tell (action > description)
5. One story = one message (don't overload)
6. The ending must earn its emotion (setup pays off)
