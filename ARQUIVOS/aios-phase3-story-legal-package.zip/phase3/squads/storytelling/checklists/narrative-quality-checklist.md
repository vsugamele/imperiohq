# Checklist: Narrative Quality

## Structure (obrigatório)
- [ ] 5 Commandments present (Inciting Incident, Complications, Crisis, Climax, Resolution)
- [ ] Clear value shift (state A → state B)
- [ ] Genre promise fulfilled
- [ ] Appropriate framework for context + duration

## Character
- [ ] Hero is the CLIENT (not the brand)
- [ ] Hero's want is clear and specific
- [ ] Hero faces real obstacles (not trivial)
- [ ] Hero is changed by the end

## Emotion
- [ ] Opens with empathy or curiosity
- [ ] Has at least 1 moment of tension/conflict
- [ ] Has at least 1 moment of hope/possibility
- [ ] Closes with clear emotion (inspiration, determination, relief)

## Clarity
- [ ] One core message (not 3 ideas fighting)
- [ ] Jargon-free (or jargon explained)
- [ ] Passes the "tell a friend" test (could they retell in 30 seconds?)
- [ ] Call to action is clear and specific

## Authenticity
- [ ] Based on real experience (not fabricated)
- [ ] Vulnerability present (not all-hero narrative)
- [ ] Specific details (not generic)
- [ ] Honest about difficulty (not sugar-coated)

## Score
```
Structure: ___/4
Character: ___/4
Emotion: ___/4
Clarity: ___/4
Authenticity: ___/4

≥16: Excellent — ready to deliver
12-15: Good — minor refinements
8-11: Needs work — structural issues
<8: Rewrite — fundamental problems
```
