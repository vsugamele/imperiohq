# Task: Craft Public Narrative — Self/Us/Now

## Metadata
- **Agent:** @marshall-ganz
- **Tier:** 2

## Input
```yaml
required:
  - cause: "A causa/missão/movimento"
  - personal_connection: "Por que VOCÊ se importa com isso"
  - community: "Quem é o 'nós'"
  - urgency: "Por que agir AGORA"
```

## Instruções

### Step 1 — Story of Self
O momento pessoal onde ESCOLHEU se importar com isso.
Não autobiografia — o momento de DECISÃO.

### Step 2 — Story of Us
Os valores COMPARTILHADOS que unem o grupo.
"Nós somos pessoas que [valor]. Nós acreditamos que [crença]."

### Step 3 — Story of Now
A urgência real (não fabricada).
"Se não agirmos agora, [consequência]. Mas se agirmos, [possibilidade]."

### Step 4 — Weave
Conectar Self → Us → Now em narrativa fluida.
Do pessoal ao coletivo ao urgente.

## Output Schema
```yaml
public_narrative:
  self: {moment: "", choice: "", value: ""}
  us: {identity: "", shared_values: [], bond: ""}
  now: {urgency: "", stakes: "", action: ""}
  full_narrative: "script completo"
```
