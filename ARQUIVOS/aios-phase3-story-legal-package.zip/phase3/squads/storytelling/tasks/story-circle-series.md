# Task: Story Circle Series — Conteúdo Serial

## Metadata
- **Agent:** @dan-harmon
- **Tier:** 1

## Input
```yaml
required:
  - series_type: "course | podcast | youtube | email | social"
  - total_episodes: "Quantidade de episódios/aulas/posts"
  - theme: "Tema geral da série"
  - transformation: "Transformação total (início → fim)"
```

## Instruções

### Step 1 — Series Circle (macro)
Definir 8 beats da série completa:
1. YOU: Onde o público está no episódio 1
2. NEED: O que precisa mudar
3. GO: Decisão de embarcar
4-5-6: SEARCH/FIND/TAKE: Os módulos centrais
7. RETURN: Volta ao mundo real com novo conhecimento
8. CHANGED: Transformação completa

### Step 2 — Episode Circles (micro)
Cada episódio é um mini Story Circle:
- YOU: Recap + onde estamos
- NEED: Problema do episódio
- GO: Embarcando na solução
- SEARCH/FIND: Aprendizado
- TAKE: Exercício/aplicação
- RETURN: Resumo
- CHANGED: Insight do episódio
- CLIFFHANGER: Loop open pro próximo

### Step 3 — Arc Map
Mapear episódios nos beats do macro circle.

## Output Schema
```yaml
series:
  macro_circle: [{beat: 1-8, label: "", episode_range: ""}]
  episodes: [{number: X, title: "", micro_circle: {you: "", need: "", go: "", find: "", take: "", changed: ""}, cliffhanger: ""}]
  transformation: {start: "", end: ""}
```
