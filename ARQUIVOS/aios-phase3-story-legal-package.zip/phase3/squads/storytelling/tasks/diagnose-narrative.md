# Task: Diagnose Narrative — Diagnóstico de Narrativa

## Metadata
- **Agent:** @shawn-coyne (Story Grid) + @joseph-campbell (Archetype)
- **Tier:** 0 (OBRIGATÓRIO antes de qualquer narrativa)

## Input
```yaml
required:
  - context: "brand | pitch | keynote | personal | course | launch | content"
  - audience: "Quem vai ouvir/ler"
  - duration: "30s | 2min | 5min | 15min | 45min+"
  - objective: "O que quer que a audiência FAÇA depois"
optional:
  - existing_narrative: "Se já tem rascunho, colar aqui"
  - brand_positioning: "Output do HackerVerso (se disponível)"
```

## Instruções

### Step 1 — Genre Analysis (@shawn-coyne)
Identificar gênero narrativo ideal:
- Performance → Case study, resultado
- Worldview → Brand story, educação
- Status → Pitch, oportunidade
- Love/Connection → Community, founder story

### Step 2 — Archetype Check (@joseph-campbell)
Validar: quem é o herói? Quem é o mentor? Onde está o threshold?
- Herói = SEMPRE o cliente/audiência (nunca a marca)
- Mentor = marca/apresentador
- Threshold = momento de decisão

### Step 3 — Framework Match
Baseado em duração + contexto, recomendar agent + framework:
| Duração | Contexto | Agent | Framework |
|---------|----------|-------|-----------|
| 30s | Quick pitch | @park-howell | ABT |
| 2min | Brand intro | @donald-miller | SB7 |
| 5min | Business story | @kindra-hall | 4 Stories |
| 5min | Personal | @matthew-dicks | 5-Second Moment |
| 15min | Keynote | @nancy-duarte | Sparkline |
| 15min | Mobilização | @marshall-ganz | Self/Us/Now |
| 20min | Investor pitch | @oren-klaff | STRONG |
| 45min+ | Full presentation | @nancy-duarte + @joseph-campbell | Sparkline + Journey |
| Serial | Content series | @dan-harmon | Story Circle |
| Script | Video/course | @blake-snyder | Save the Cat |

### Step 4 — 5 Commandments Check (se narrativa existente)
Validar presença de:
1. Inciting Incident ✅/❌
2. Progressive Complications ✅/❌
3. Crisis (dilema real) ✅/❌
4. Climax (decisão/ação) ✅/❌
5. Resolution ✅/❌

## Output Schema
```yaml
narrative_diagnosis:
  genre: {primary: "", promise: ""}
  archetype: {hero: "", mentor: "", villain: "", threshold: ""}
  recommended_agent: ""
  recommended_framework: ""
  five_commandments: {present: X/5, missing: []}
  value_shift: {from: "", to: ""}
  action_plan: ""
```
