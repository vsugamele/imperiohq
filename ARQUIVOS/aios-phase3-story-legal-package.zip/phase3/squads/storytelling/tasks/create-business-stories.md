# Task: Create Business Stories — 4 Stories Framework

## Metadata
- **Agent:** @kindra-hall
- **Tier:** 2

## Input
```yaml
required:
  - business: "Nome/tipo do negócio"
  - product: "Produto/serviço"
  - founder_background: "Background do fundador"
  - customer_examples: "1-3 exemplos de clientes com resultados"
```

## Instruções

### Step 1 — Value Story
"Por que isso importa?" → Cliente + problema + solução + resultado.

### Step 2 — Founder Story
"Por que você?" → Origem + catalyst + decisão + missão.

### Step 3 — Purpose Story
"Por que isso existe?" → Problema sistêmico + crença + ação.

### Step 4 — Customer Story
"E se fosse eu?" → Nome + dor + produto + resultado + bônus inesperado.

### Step 5 — Usage Map
Onde usar cada história:
- Value → Sales page, pitch, ads
- Founder → About page, interviews, keynotes
- Purpose → Brand messaging, culture
- Customer → Testimonials, social proof, email

## Output Schema
```yaml
business_stories:
  value: {script: "", duration: "", usage: []}
  founder: {script: "", duration: "", usage: []}
  purpose: {script: "", duration: "", usage: []}
  customer: {script: "", duration: "", usage: []}
```
