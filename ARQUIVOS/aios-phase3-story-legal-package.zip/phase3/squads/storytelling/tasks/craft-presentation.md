# Task: Craft Presentation — Sparkline + Slides

## Metadata
- **Agent:** @nancy-duarte
- **Tier:** 1
- **depends_on:** diagnose-narrative

## Input
```yaml
required:
  - topic: "Tema da apresentação"
  - audience: "Quem vai assistir"
  - duration: "15min | 30min | 45min"
  - call_to_action: "O que quer que façam depois"
```

## Instruções

### Step 1 — Sparkline Map
Criar alternância What IS ↔ What COULD BE:
- Abrir com "What IS" (realidade atual, problema)
- Alternar com "What COULD BE" (visão, possibilidade)
- Mínimo 4 alternâncias para 15min
- Final: "New Bliss" (a visão adotada)

### Step 2 — The Torchbearer
Posicionar apresentador como guia:
- Likeable (vulnerability moment)
- Credible (prova, não ego)
- Connected (shared experience com audiência)

### Step 3 — Slide Narrative
1 slide = 1 ideia. Glance Test (3 segundos).
- Mais imagens, menos texto
- Dados em gráficos simples
- Transições são narrativas, não decorativas

### Step 4 — Call to Adventure
O momento final onde a audiência é convidada a agir.
Específico, viável, imediato.

## Output Schema
```yaml
presentation:
  sparkline: [{type: "what_is|what_could_be", content: "", slide_ref: X}]
  new_bliss: ""
  slides: [{number: X, idea: "", visual_direction: "", speaker_notes: ""}]
  call_to_adventure: ""
  duration: ""
```
