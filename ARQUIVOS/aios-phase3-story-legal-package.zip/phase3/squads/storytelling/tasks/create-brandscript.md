# Task: Create BrandScript — SB7 Framework

## Metadata
- **Agent:** @donald-miller
- **Tier:** 1
- **depends_on:** diagnose-narrative OU avatar profile (HackerVerso)

## Input
```yaml
required:
  - brand_name: "Nome da marca"
  - product: "Produto/serviço principal"
  - avatar: "Perfil do cliente ideal"
  - transformation: "De onde → Para onde"
```

## Instruções

### Step 1 — Character (Herói = Cliente)
"O que meu cliente QUER?" → Definir desejo em 1 frase.

### Step 2 — Problem (3 Níveis)
- External: problema prático
- Internal: sentimento que causa
- Philosophical: por que é injusto
- Villain: a CAUSA do problema

### Step 3 — Guide (Marca = Mentor)
- Empatia: "Entendemos porque [vivemos/vimos/ajudamos]..."
- Autoridade: "[X] clientes, [Y] anos, [Z] resultado"

### Step 4 — Plan (3 Passos)
3 passos simples que removem confusão.

### Step 5 — CTA
- Direct: ação principal de conversão
- Transitional: ação de baixo compromisso

### Step 6 — Failure
O que acontece se NÃO agir (stakes reais, não manipulação).

### Step 7 — Success
Como a vida fica DEPOIS (status, completude, auto-realização).

### Step 8 — Sintetizar
BrandScript completo + One-Liner + Website wireframe.

## Output Schema
```yaml
brandscript:
  sb7:
    character: {want: ""}
    problem: {external: "", internal: "", philosophical: "", villain: ""}
    guide: {empathy: "", authority: ""}
    plan: ["", "", ""]
    cta: {direct: "", transitional: ""}
    failure: ""
    success: ""
  one_liner: ""
  brandscript_paragraph: ""
  website_sections: ["hero", "stakes", "value_prop", "guide", "plan", "cta", "junk_drawer"]
```

## Quality Gate
- [ ] Herói é o CLIENTE (não a marca)
- [ ] Problema tem 3 níveis (external + internal + philosophical)
- [ ] Plano tem exatamente 3 passos simples
- [ ] 2 CTAs (direct + transitional)
- [ ] One-liner cabe em 1 tweet
