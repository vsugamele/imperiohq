# Task: Craft Pitch — STRONG Method

## Metadata
- **Agent:** @oren-klaff
- **Tier:** 2

## Input
```yaml
required:
  - pitch_type: "investor | client | partner | internal"
  - audience: "Quem vai ouvir"
  - ask: "O que quer conseguir"
  - duration: "5min | 10min | 20min"
```

## Instruções

### Step 1 — Set the Frame
Definir frame dominante: Power, Time, Intrigue, ou Prize.
"Eu tenho algo que [audiência] precisa. A questão é se [audiência] é a parceria certa."

### Step 2 — Tell the Story
Narrativa que MOSTRA (não conta) o valor.
Big Idea → Why Now → Why You → How It Works.

### Step 3 — Reveal the Intrigue
Elemento de curiosidade que mantém atenção.
"Mas aqui é onde fica interessante..."

### Step 4 — Offer the Prize
Posicionar como o PRÊMIO (não o pedinte).
"Estamos selecionando [X] parceiros para..."

### Step 5 — Nail the Hook Point
O momento "aha" onde eles se inclinam pra frente.
Geralmente: o insight não-óbvio, o dado surpreendente, a demonstração impactante.

### Step 6 — Get the Decision
Não sair com "vamos pensar." Sair com next step concreto.
"O próximo passo é [ação específica] até [data]."

## Output Schema
```yaml
pitch:
  frame: {type: "", setup: ""}
  story: {big_idea: "", why_now: "", why_you: "", how: ""}
  intrigue: ""
  prize: ""
  hook_point: ""
  close: {decision: "", next_step: "", deadline: ""}
  script: "roteiro completo"
  duration: ""
```
