# Task: Create ABT — Quick Narrative

## Metadata
- **Agent:** @park-howell
- **Tier:** 2 (quick wins)

## Input
```yaml
required:
  - subject: "Sobre o que é"
  - context: "elevator pitch | social post | email opener | meeting intro"
```

## Instruções

### Step 1 — AND (Setup)
Estabelecer o mundo normal. Status quo. Contexto.
"[Situação A] AND [situação B]..."

### Step 2 — BUT (Complicação)
O conflito. O que está errado. A tensão.
"BUT [problema/mudança/obstáculo]..."

### Step 3 — THEREFORE (Resolução)
A consequência. A ação. A solução.
"THEREFORE [o que fazer/como resolver/resultado]..."

### Step 4 — Polish
Versões em 3 durações: 30 segundos, 1 minuto, 2 minutos.

## Output Schema
```yaml
abt:
  and: ""
  but: ""
  therefore: ""
  versions:
    - duration: "30s"
      text: ""
    - duration: "1min"
      text: ""
    - duration: "2min"
      text: ""
```
