# Task: Craft Personal Story — 5-Second Moment

## Metadata
- **Agent:** @matthew-dicks
- **Tier:** 2

## Input
```yaml
required:
  - raw_experience: "Experiência bruta (o que aconteceu)"
  - purpose: "Por que contar essa história (objetivo)"
  - audience: "Quem vai ouvir"
```

## Instruções

### Step 1 — Find the 5-Second Moment
O momento exato de transformação. "Quando tudo mudou."
Não é o evento dramático — é o instante de PERCEPÇÃO.

### Step 2 — Begin at the End
Com o momento definido, construir backwards:
"O que preciso contar para que esse momento faça sentido?"

### Step 3 — Opening (Location + Action)
Começar com local específico e ação concreta.
"Eu estava sentado no chão do escritório, às 3 da manhã..."
NUNCA: "Então, tipo, um dia..."

### Step 4 — Build Stakes
- Start with a problem
- Use "But/Therefore" (não "And then")
- Plant seeds (setup que paga depois)
- Create contrast

### Step 5 — The Moment
Entregar o 5-Second Moment com peso.
Desacelerar aqui. Detalhar. Deixar a audiência SENTIR.

### Step 6 — Landing
Resolução curta. Não explicar demais.
A audiência sabe o que significa. Confie nela.

## Output Schema
```yaml
personal_story:
  moment: ""
  opening: {location: "", action: "", first_line: ""}
  arc: [{beat: "", content: ""}]
  transformation: {before: "", moment: "", after: ""}
  duration: "X min"
  script: "roteiro completo"
```
