# Template: Sparkline — Presentation Narrative

## Structure

### Opening — What IS (Current Reality)
{Describe the current state. The problem. The pain point.}

### Beat 1 — What COULD BE
{Paint the vision. The possibility. What if...}

### Beat 2 — What IS (Back to reality)
{But here's what's actually happening. The gap.}

### Beat 3 — What COULD BE
{Imagine this instead. Evidence it's possible.}

### Beat 4 — What IS
{The obstacle. Why we haven't gotten there yet.}

### Beat 5 — What COULD BE
{The breakthrough. The solution. The method.}

### Beat 6 — What IS (Final tension)
{The choice we face. The stakes.}

### NEW BLISS — The Future We Choose
{The vision adopted. The call to adventure.}

---

**Rules:**
- Minimum 4 alternations for 15min talk
- Each "What IS" grounds in reality (data, stories, evidence)
- Each "What COULD BE" inspires (vision, possibility, examples)
- NEW BLISS is not aspirational — it's COMMITTED
