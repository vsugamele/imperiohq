# Template: StoryBrand BrandScript (SB7)

## 1. CHARACTER (Hero = Client)
**What does the hero want?**
{One clear, specific desire}

## 2. PROBLEM
**External:** {The practical problem}
**Internal:** {How it makes them FEEL}
**Philosophical:** {Why it's WRONG that this problem exists}
**Villain:** {The root cause / enemy}

## 3. GUIDE (Brand = Mentor)
**Empathy:** "We understand {feeling} because {reason}."
**Authority:** "{X} clients helped | {Y} years | {Z} result"

## 4. PLAN
1. {Simple step 1}
2. {Simple step 2}
3. {Simple step 3}

## 5. CALL TO ACTION
**Direct CTA:** {Primary conversion action}
**Transitional CTA:** {Low-commitment action}

## 6. FAILURE
**What happens if they DON'T act:**
{Paint the negative outcome — honest, not manipulative}

## 7. SUCCESS
**What life looks like AFTER:**
{Status | Completeness | Self-realization}

---

## ONE-LINER
"{Problem}. {Solution}. {Result}."

## BRANDSCRIPT (1 paragraph)
"{HERO} has {PROBLEM}. {BRAND} understands {EMPATHY} and has {AUTHORITY}. The plan: {3 STEPS}. {CTA}. Without action, {FAILURE}. With action, {SUCCESS}."
