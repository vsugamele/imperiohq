# Template: Story Brief

## Story Info
- **Title:** {title}
- **Type:** {brand | pitch | personal | keynote | content}
- **Framework:** {SB7 | STRONG | Sparkline | Story Circle | ABT | 5-Second | Save the Cat}
- **Duration:** {duration}
- **Audience:** {who}

## Narrative Core
- **Hero:** {who is the hero — usually the CLIENT}
- **Want:** {what does the hero want}
- **Problem:** {what stands in the way}
- **Guide:** {who helps — usually the BRAND}
- **Transformation:** {from_state} → {to_state}

## 5 Commandments Check
- [ ] Inciting Incident: {event}
- [ ] Progressive Complications: {complications}
- [ ] Crisis: {dilemma}
- [ ] Climax: {decision/action}
- [ ] Resolution: {outcome}

## Value Shift
- **Start:** {value_state_A}
- **End:** {value_state_B}

## Call to Action
- **What to DO:** {specific action}
- **What to FEEL:** {emotion}
- **What to THINK:** {belief}
