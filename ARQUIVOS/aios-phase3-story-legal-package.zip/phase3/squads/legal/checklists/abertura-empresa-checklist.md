# Checklist: Abertura de Empresa (Brasil)

## Pré-Abertura
- [ ] Definir tipo societário (MEI, LTDA, SLU, SA)
- [ ] Definir regime tributário (Simples, LP, LR)
- [ ] Acordo de sócios redigido (se 2+ sócios)
- [ ] CNAE(s) definido(s)
- [ ] Capital social definido
- [ ] Endereço definido (comercial ou virtual)
- [ ] Contador contratado

## Abertura
- [ ] Contrato social / Requerimento de empresário
- [ ] Registro na Junta Comercial
- [ ] CNPJ na Receita Federal
- [ ] Inscrição Estadual (se comércio/indústria)
- [ ] Inscrição Municipal
- [ ] Alvará de funcionamento
- [ ] Certificado digital (e-CNPJ)

## Pós-Abertura
- [ ] Conta bancária PJ
- [ ] Emissor de nota fiscal configurado
- [ ] Regime tributário formalizado (opção Simples se aplicável)
- [ ] Domínio e email corporativo
- [ ] Política de privacidade e termos de uso
- [ ] Marca registrada no INPI (recomendado)
