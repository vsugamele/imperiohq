# Checklist: Compliance para Negócio Digital (Brasil)

## LGPD (Dados)
- [ ] Política de privacidade publicada e acessível
- [ ] Cookie banner com consentimento opt-in
- [ ] Formulários com link para política de privacidade
- [ ] Email marketing com opção de unsubscribe
- [ ] Dados armazenados com criptografia
- [ ] DPO (encarregado) designado
- [ ] Registro de atividades de tratamento
- [ ] Plano de resposta a incidentes (data breach)
- [ ] Contratos com processadores de dados

## Consumidor (CDC + E-commerce)
- [ ] Direito de arrependimento 7 dias (Art. 49 CDC)
- [ ] Política de reembolso clara e acessível
- [ ] Informações do produto/serviço completas
- [ ] Preço total visível (sem taxas ocultas)
- [ ] Canal de atendimento funcional (SAC)
- [ ] Termos de uso publicados
- [ ] CNPJ visível no site

## Tributário
- [ ] Regime tributário adequado ao faturamento
- [ ] Notas fiscais emitidas para todas as vendas
- [ ] Obrigações acessórias em dia (DCTF, DEFIS, etc.)
- [ ] ISS/ICMS recolhido conforme atividade
- [ ] Contador responsável definido

## Marketing
- [ ] Claims de resultado com evidência/disclaimer
- [ ] Depoimentos reais (não fabricados)
- [ ] Antes/depois com disclaimer quando aplicável
- [ ] Não configura propaganda enganosa (Art. 37 CDC)
- [ ] Não configura pirâmide financeira

## Contratos
- [ ] Contrato com clientes/alunos
- [ ] Contrato com fornecedores
- [ ] Contrato com prestadores de serviço
- [ ] NDA com equipe e parceiros
- [ ] Acordo de sócios (se aplicável)

## Score
```
LGPD: ___/9
Consumidor: ___/7
Tributário: ___/5
Marketing: ___/4
Contratos: ___/5

≥25: Conformo (manter monitoramento)
18-24: Parcialmente (priorizar gaps)
<18: Não conformo (ação urgente)
```
