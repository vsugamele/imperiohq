# Task: Compliance Check — Verificação de Conformidade

## Metadata
- **Agent:** @pierpaolo-bottini + @lgpd-specialist
- **Tier:** 2

## Input
```yaml
required:
  - business_type: "infoproduto | e-commerce | SaaS | serviço"
  - revenue_range: "faixa de faturamento"
  - data_collected: "Que dados pessoais coleta"
  - team_size: "Quantas pessoas no time"
```

## Instruções

### Step 1 — LGPD Check (@lgpd-specialist)
- Mapeamento de dados pessoais
- Base legal para cada tratamento
- Política de privacidade publicada?
- Consentimento implementado?
- DPO designado?
- Plano de resposta a incidentes?

### Step 2 — Consumer Protection Check
- Direito de arrependimento (7 dias) respeitado?
- Política de reembolso clara?
- Publicidade não enganosa?
- Termos de uso publicados?
- Canal de atendimento acessível?

### Step 3 — Criminal Compliance (@pierpaolo-bottini)
- Marketing não configura propaganda enganosa?
- Claims de resultado com evidência?
- Operação não configura pirâmide?
- Pagamentos rastreáveis (anti-lavagem)?

### Step 4 — Risk Matrix

## Output Schema
```yaml
compliance:
  lgpd: {status: "adequado|parcial|inadequado", gaps: [], priority_actions: []}
  consumer: {status: "", gaps: [], actions: []}
  criminal: {status: "", risks: [], mitigations: []}
  overall: "conformo | parcialmente conformo | não conformo"
  action_plan: [{item: "", priority: "alta|média|baixa", deadline: ""}]
```
