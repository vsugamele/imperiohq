# Task: Acordo de Sócios

## Metadata
- **Agent:** @societarista
- **Tier:** 2

## Input
```yaml
required:
  - socios: [{nome: "", pct: "", papel: "", dedicacao: "full|part"}]
  - tipo_societario: "LTDA | SLU | SA"
  - investimento_inicial: "Quanto cada um investiu"
```

## Instruções

### Step 1 — 10 Cláusulas Essenciais
1. Distribuição de equity + justificativa
2. Vesting (4 anos, 1 ano cliff)
3. Dedicação e exclusividade
4. Pro-labore
5. Decisões (unanimidade vs maioria)
6. Saída (valuation, ROFR)
7. Deadlock resolution
8. Non-compete
9. IP assignment
10. Tag-along / Drag-along

### Step 2 — Cenários de Saída
Simular: sócio quer sair, sócio quer vender, empresa recebe oferta de compra.

### Step 3 — Cap Table Projeção
Atual → com options pool → com investimento futuro.

## Output Schema
```yaml
acordo:
  clausulas: [{numero: 1-10, titulo: "", conteudo: "", negociavel: true/false}]
  cenarios_saida: [{cenario: "", processo: "", valuation_method: ""}]
  cap_table: [{socio: "", pct_atual: "", pct_pos_pool: "", pct_pos_series_a: ""}]
```
