# Task: Planejamento Tributário

## Metadata
- **Agent:** @tributarista
- **Tier:** 2

## Input
```yaml
required:
  - faturamento_anual: "Faturamento anual (ou projeção)"
  - tipo_atividade: "serviço | comércio | indústria | digital"
  - margem_lucro: "Margem de lucro estimada"
  - regime_atual: "MEI | Simples | LP | LR | nenhum"
  - despesas_dedutiveis: "Estimativa de despesas"
```

## Instruções

### Step 1 — Comparativo de Regimes
Calcular imposto em cada regime aplicável:
| Regime | Faturamento | Alíquota | Imposto Anual | Economia vs Atual |
|--------|------------|----------|---------------|-------------------|
| Simples | | | | |
| Lucro Presumido | | | | |
| Lucro Real | | | | |

### Step 2 — Otimização
- Pro-labore vs distribuição de lucros
- Estrutura com holding?
- Split de atividades (se aplicável)

### Step 3 — Recomendação
Regime ideal + estrutura + próximos passos.

## Output Schema
```yaml
tributario:
  comparativo: [{regime: "", imposto_anual: "", aliquota_efetiva: ""}]
  regime_recomendado: ""
  economia_anual: ""
  estrutura: {holding: true/false, operacionais: X, obs: ""}
  proximos_passos: []
```
