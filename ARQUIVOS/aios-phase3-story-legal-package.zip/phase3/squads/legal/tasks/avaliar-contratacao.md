# Task: Avaliar Contratação — CLT vs PJ

## Metadata
- **Agent:** @trabalhista
- **Tier:** 2

## Input
```yaml
required:
  - funcao: "Função a ser exercida"
  - dedicacao: "full-time | part-time | projeto"
  - exclusividade: "sim | não"
  - subordinacao: "recebe ordens diretas | trabalha por resultado"
  - local: "remoto | presencial | híbrido"
```

## Instruções

### Step 1 — Análise dos 5 Elementos de Vínculo
1. Pessoalidade: ___/10
2. Habitualidade: ___/10
3. Subordinação: ___/10
4. Onerosidade: ___/10
5. Pessoa física: ___/10

Score ≥ 35: ALTO risco de vínculo CLT
Score 20-34: MÉDIO risco
Score < 20: BAIXO risco

### Step 2 — Comparativo de Custos
| Item | CLT | PJ |
|------|-----|-----|
| Salário/Fee mensal | | |
| INSS patronal | | |
| FGTS | | |
| 13º + férias | | |
| Custo total anual | | |

### Step 3 — Recomendação
CLT | PJ | Híbrido + como estruturar para minimizar riscos.

## Output Schema
```yaml
contratacao:
  vinculo_score: X/50
  risco: "alto | médio | baixo"
  comparativo: {clt_anual: "", pj_anual: "", diferenca: ""}
  recomendacao: "CLT | PJ | Híbrido"
  estruturacao: "como configurar para minimizar risco"
```
