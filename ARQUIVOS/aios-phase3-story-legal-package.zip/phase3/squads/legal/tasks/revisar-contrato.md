# Task: Revisar Contrato — Risk-Based Review

## Metadata
- **Agent:** @ken-adams
- **Tier:** 1

## Input
```yaml
required:
  - contract_text: "Texto do contrato OU resumo das cláusulas"
  - contract_type: "prestação de serviço | sociedade | investimento | licença | NDA | outros"
  - your_role: "contratante | contratado | sócio | investidor"
```

## Instruções

### Step 1 — Risk Triage
Avaliar por ordem de risco (não linear):
1. Liability & Indemnification (0-10)
2. Termination & Exit (0-10)
3. IP & Ownership (0-10)
4. Payment Terms (0-10)
5. Confidentiality & Non-Compete (0-10)
6. Governance & Dispute Resolution (0-10)

### Step 2 — Red Flags
Identificar cláusulas problemáticas:
- Renovação automática sem opt-out
- Non-compete excessivo
- Liability ilimitada
- IP assignment sem compensação
- Foro desfavorável
- Penalidades desproporcionais
- Cláusulas ambíguas

### Step 3 — Plain Language Summary
Resumir em linguagem simples: o que esse contrato DIZ e o que SIGNIFICA pra você.

### Step 4 — Recommendation
Assinar | Negociar (quais pontos) | Rejeitar

## Output Schema
```yaml
contract_review:
  type: ""
  overall_risk: "alto | médio | baixo"
  risk_areas: [{area: "", score: 0-10, finding: "", recommendation: ""}]
  red_flags: [{clause: "", issue: "", severity: "", fix: ""}]
  plain_summary: ""
  action: "assinar | negociar | rejeitar"
  negotiation_points: []
```

## Quality Gate
- [ ] 6 áreas de risco avaliadas
- [ ] Red flags identificados
- [ ] Resumo em plain language
- [ ] Recomendação clara com justificativa
- [ ] Disclaimer: orientação geral, consulte advogado
