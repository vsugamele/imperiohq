# Task: Adequação LGPD

## Metadata
- **Agent:** @lgpd-specialist
- **Tier:** 2

## Input
```yaml
required:
  - business_type: "tipo de negócio"
  - data_types: "Que dados pessoais coleta (nome, email, CPF, etc.)"
  - collection_points: "Onde coleta (forms, checkout, analytics)"
  - storage: "Onde armazena (servidor, cloud, terceiros)"
```

## Instruções

### Step 1 — Mapeamento de Dados
| Dado | Onde Coleta | Base Legal | Finalidade | Armazenamento | Compartilha? |
|------|-----------|-----------|-----------|---------------|-------------|

### Step 2 — Gap Analysis
Para cada requisito LGPD, avaliar status:
- Política de privacidade ✅/❌
- Cookie banner ✅/❌
- Consentimento opt-in ✅/❌
- Direitos do titular (portal) ✅/❌
- DPO designado ✅/❌
- Registro de tratamentos ✅/❌
- Plano de resposta a incidentes ✅/❌
- Contratos com processadores ✅/❌

### Step 3 — Plano de Adequação
Priorizar por risco e implementar.

## Output Schema
```yaml
lgpd:
  mapeamento: [{dado: "", coleta: "", base_legal: "", finalidade: "", storage: "", compartilha: ""}]
  gap_analysis: [{requisito: "", status: "ok|gap", risco: "alto|medio|baixo"}]
  plano: [{acao: "", prioridade: "", responsavel: "", prazo: ""}]
```
