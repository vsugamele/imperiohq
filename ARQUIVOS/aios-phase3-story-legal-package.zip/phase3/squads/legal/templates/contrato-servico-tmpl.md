# Template: Contrato de Prestação de Serviço

## CONTRATO DE PRESTAÇÃO DE SERVIÇOS

**CONTRATANTE:** {nome_contratante}, inscrito no CNPJ/CPF {cnpj_cpf}, com sede em {endereco}.

**CONTRATADA:** {nome_contratada}, inscrita no CNPJ {cnpj}, com sede em {endereco}.

### 1. OBJETO
A CONTRATADA prestará os seguintes serviços: {descricao_servicos}.

### 2. PRAZO
Início: {data_inicio}. Término: {data_fim}.
Renovação: {automática com aviso de X dias | não automática}.

### 3. REMUNERAÇÃO
Valor: R${valor} ({extenso}).
Pagamento: {forma_pagamento} até o dia {dia} de cada mês.
Nota fiscal: obrigatória para cada pagamento.

### 4. OBRIGAÇÕES DA CONTRATADA
- Entregar {deliverables} nos prazos acordados
- Manter sigilo sobre informações confidenciais
- Emitir nota fiscal para cada pagamento

### 5. OBRIGAÇÕES DO CONTRATANTE
- Fornecer informações necessárias para a execução
- Efetuar pagamentos nos prazos acordados
- Dar feedback em até {X} dias úteis

### 6. PROPRIEDADE INTELECTUAL
Todo material produzido no escopo deste contrato é de propriedade {do contratante | da contratada | compartilhada}.

### 7. CONFIDENCIALIDADE
Ambas as partes se comprometem a manter sigilo sobre informações recebidas durante a vigência deste contrato e por {X} meses após o término.

### 8. RESCISÃO
Qualquer parte pode rescindir com aviso prévio de {X} dias.
Em caso de rescisão, pagamentos devidos até a data serão honrados.

### 9. FORO
Fica eleito o foro da comarca de {cidade}/{estado} para dirimir quaisquer questões.

---
**⚠️ AVISO:** Template de orientação geral. Consulte advogado para adequar ao seu caso específico.
