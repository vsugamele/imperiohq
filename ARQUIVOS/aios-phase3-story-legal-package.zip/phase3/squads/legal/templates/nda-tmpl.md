# Template: NDA (Non-Disclosure Agreement)

## ACORDO DE CONFIDENCIALIDADE

**PARTE REVELADORA:** {nome}, CNPJ/CPF {doc}.
**PARTE RECEPTORA:** {nome}, CNPJ/CPF {doc}.

### 1. DEFINIÇÃO DE INFORMAÇÃO CONFIDENCIAL
Toda informação técnica, comercial, financeira, estratégica, de clientes, fornecedores, processos, métodos, know-how, propriedade intelectual, e qualquer outra informação não pública revelada por qualquer meio.

### 2. OBRIGAÇÕES
A Parte Receptora se compromete a:
- Não divulgar informações confidenciais a terceiros
- Usar exclusivamente para a finalidade de {finalidade}
- Proteger com o mesmo cuidado que suas próprias informações
- Limitar acesso a colaboradores que necessitem (need-to-know)
- Devolver ou destruir materiais quando solicitado

### 3. EXCEÇÕES
Não são confidenciais informações que:
- Já são públicas (sem culpa da Parte Receptora)
- Foram obtidas legitimamente de terceiros
- Foram desenvolvidas independentemente
- Devem ser reveladas por ordem judicial

### 4. PRAZO
Vigência: {X} anos a partir da assinatura.
Obrigação de sigilo: {Y} anos após o término.

### 5. PENALIDADE
Violação sujeita a indenização por perdas e danos, sem prejuízo de medidas judiciais cabíveis.

### 6. FORO
Comarca de {cidade}/{estado}.

---
**⚠️ AVISO:** Template de orientação geral. Consulte advogado.
