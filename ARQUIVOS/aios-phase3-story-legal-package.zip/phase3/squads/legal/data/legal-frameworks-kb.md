# Knowledge Base: Legal Frameworks — Brasil

## Legislação Chave para Negócios Digitais

### LGPD (Lei 13.709/2018)
- Lei Geral de Proteção de Dados Pessoais
- 10 bases legais para tratamento
- Direitos do titular (Art. 18)
- ANPD (Autoridade Nacional de Proteção de Dados)
- Multas: até 2% do faturamento (teto R$50M por infração)

### CDC (Lei 8.078/1990) — Código de Defesa do Consumidor
- Art. 37: Publicidade enganosa ou abusiva
- Art. 49: Arrependimento em 7 dias (compras fora do estabelecimento)
- Art. 51: Cláusulas abusivas
- Inversão do ônus da prova a favor do consumidor

### Marco Civil da Internet (Lei 12.965/2014)
- Neutralidade de rede
- Privacidade de comunicações
- Responsabilidade de provedores
- Remoção de conteúdo por ordem judicial

### Lei Anticorrupção (Lei 12.846/2013)
- Responsabilidade objetiva de empresas
- Programa de integridade como atenuante
- Acordo de leniência

### CLT + Reforma Trabalhista
- 5 elementos de vínculo empregatício
- Pejotização: riscos e consequências
- Teletrabalho (Art. 75-A a 75-E)

## Regimes Tributários
| Regime | Faturamento Max | Alíquota Range |
|--------|----------------|----------------|
| MEI | R$81k/ano | ~5% fixo |
| Simples Nacional | R$4.8M/ano | 6-33% |
| Lucro Presumido | Sem limite | 11.33-16.33% |
| Lucro Real | Sem limite | ~34% sobre lucro |

## Tipos Societários
| Tipo | Sócios | Responsabilidade | Quando |
|------|--------|-----------------|--------|
| MEI | 1 | Ilimitada | Início, faturamento baixo |
| SLU | 1 | Limitada | Solo, proteção patrimonial |
| LTDA | 2+ | Limitada | Sociedade padrão |
| S.A. | 2+ | Limitada | Investimento, IPO |

## Red Flags Comuns
1. Pejotização (PJ com subordinação)
2. Publicidade enganosa (claims sem evidência)
3. Dados pessoais sem base legal
4. Sonegação fiscal (não emitir NF)
5. Acordo de sócios inexistente
6. Marca não registrada (risco de perder)
7. Contrato de serviço sem IP clause

## Disclaimer
Orientação geral para fins educacionais. NÃO constitui aconselhamento jurídico. Consulte advogado habilitado para decisões legais.
