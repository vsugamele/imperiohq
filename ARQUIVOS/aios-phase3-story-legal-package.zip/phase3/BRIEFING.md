# BRIEFING: Phase 3 — Story-Chief + Legal-Chief

## O Que Este Pacote Contém

**46 arquivos** completando os chiefs de storytelling e jurídico.

### Story-Chief (27 arquivos)

| Categoria | Qtd | Descrição |
|---|---|---|
| Agents | 13 | Chief + 12 storytellers |
| Tasks | 9 | Diagnóstico narrativo, BrandScript SB7, Pitch STRONG, Personal Story, Presentation Sparkline, Public Narrative, ABT, Story Circle Series, Business Stories |
| Templates | 3 | Story Brief, Sparkline, SB7 BrandScript |
| Checklists | 1 | Narrative Quality (20 pontos, 5 dimensões) |
| Data | 1 | Storytelling Frameworks KB |

**Tier System:**
- T0 Diagnóstico: @joseph-campbell (Hero's Journey, 12 estágios, Monomito) + @shawn-coyne (Story Grid, 5 Commandments, Genre = Promise)
- T1 Masters: @donald-miller (SB7 StoryBrand) + @nancy-duarte (Sparkline, Presentations) + @dan-harmon (Story Circle 8 beats, séries) + @blake-snyder (Save the Cat 15 beats, scripts)
- T2 Specialists: @oren-klaff (STRONG Pitch) + @kindra-hall (4 Business Stories) + @matthew-dicks (5-Second Moment) + @marshall-ganz (Self/Us/Now) + @park-howell (ABT) + @keith-johnstone (Improv, Status Games)

**Seleção por Duração:**
| 30s → ABT | 2min → SB7 | 5min → 4 Stories / 5-Second | 15min → Sparkline | 20min → STRONG | 45min+ → Hero's Journey | Serial → Story Circle |

### Legal-Chief (19 arquivos)

| Categoria | Qtd | Descrição |
|---|---|---|
| Agents | 8 | Chief + 2 global + 5 Brasil |
| Tasks | 6 | Revisar contrato, Compliance check, Planejamento tributário, Acordo de sócios, Adequação LGPD, Avaliar contratação CLT/PJ |
| Templates | 2 | Contrato de serviço, NDA |
| Checklists | 2 | Compliance digital BR, Abertura de empresa |
| Data | 1 | Legal Frameworks KB (LGPD, CDC, CLT, regimes tributários) |

**Tier System:**
- T1 Global: @ken-adams (Contract Drafting, Risk-Based Review) + @brad-feld (Venture Deals, Term Sheets, SAFE)
- T2 Brasil: @pierpaolo-bottini (Compliance Criminal) + @tributarista (Regimes Fiscais, Holdings) + @trabalhista (CLT vs PJ, Vesting) + @societarista (Acordo de Sócios, Cap Table) + @lgpd-specialist (LGPD, Privacy)

**⚠️ Disclaimer em todos os agents:** Orientação geral, NÃO substitui advogado.

## Deploy

```bash
# No repo aios-core

# Story agents
mkdir -p .claude/commands/Storytelling/agents/
cp commands/Storytelling/agents/*.md .claude/commands/Storytelling/agents/

# Legal agents
mkdir -p .claude/commands/Legal/agents/
cp commands/Legal/agents/*.md .claude/commands/Legal/agents/

# Story squad
cp -r squads/storytelling/ squads/storytelling/

# Legal squad
cp -r squads/legal/ squads/legal/
```

## Testar

```bash
# Story
@story-chief diagnose → @joseph-campbell + @shawn-coyne (T0 obrigatório)
@story-chief brand-story → @donald-miller (SB7)
@story-chief pitch → @oren-klaff (STRONG)
@story-chief ted-talk → @nancy-duarte (Sparkline)
@story-chief quick-narrative → @park-howell (ABT)

# Legal
@legal-chief contrato → @ken-adams (Risk-Based Review)
@legal-chief lgpd → @lgpd-specialist
@legal-chief tributário → @tributarista
@legal-chief acordo-sócios → @societarista
@legal-chief clt-pj → @trabalhista
```

## Integração Completa

```
HackerVerso (avatar + positioning)
    ↓
Story-Chief (narrativa)  →  Copy-Chief (copy de vendas)
    ↓                            ↓
    ↓                     Traffic-Masters (distribuição)
    ↓                            ↓
    ↓                     Data-Chief (métricas)
    ↓
Legal-Chief (compliance + proteção)
```

## Status AIOS Acumulado

| Chief | Status | Arquivos |
|---|---|---|
| HackerVerso | ✅ | 41 |
| Copy-Chief | ✅ | 55 |
| Traffic-Masters | ✅ | 22 |
| Data-Chief | ✅ | 18 |
| Story-Chief | ✅ | 27 |
| Legal-Chief | ✅ | 19 |
| **Subtotal** | **6/11** | **182** |
| Design-Chief | ❌ Fase 4 | ~25 |
| Cyber-Chief | ❌ Fase 4 | ~25 |
| DB-Sage | ❌ Fase 5 | ~45 |
| Design-System | ❌ Fase 5 | ~35 |
| Tools-Orchestrator | ❌ Fase 5 | ~20 |
