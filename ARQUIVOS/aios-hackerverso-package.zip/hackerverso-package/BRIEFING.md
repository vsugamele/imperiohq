# BRIEFING: Implementar Squad HackerVerso + Agents Standalone

## Decisão Arquitetural: Opção C
- **HackerVerso** = Squad formal em `squads/hackerverso/` → Faz estratégia (avatar, lago, mecanismo, oferta)
- **copy-chief** = Mantém como está → Executa copy com seus 24 copywriters
- **Handoff**: HackerVerso output → copy-chief input (via Task tool)
- **10 agents standalone** = Em `.claude/agents/` → Disponíveis cross-squad

## Ordem de Execução

### FASE 1: Criar Squad HackerVerso
1. Usar `@squad-creator` / squad-generator para criar estrutura em `squads/hackerverso/`
2. Copiar os 7 agents HV de `agents/` deste package para `squads/hackerverso/agents/`
3. Copiar as 14 tasks de `tasks/` para `squads/hackerverso/tasks/`
4. Copiar workflow de `workflows/` para `squads/hackerverso/workflows/`
5. Copiar checklists de `checklists/` para `squads/hackerverso/checklists/`
6. Copiar data de `data/` para `squads/hackerverso/data/`
7. Criar `.synapse/manifest` usando `config/synapse-manifest`

### FASE 2: Instalar Agents Standalone
1. Copiar cada .md de `standalone-agents/` para `.claude/agents/`
2. Esses agents ficam disponíveis cross-squad (qualquer squad pode chamar)

### FASE 3: Testar Integração
1. Ativar squad HackerVerso
2. Rodar pipeline com nicho de teste
3. Validar que output do HV alimenta copy-chief corretamente

## Referências no Repo Existente
- `.claude/agents/copy-chief.md` → Formato de referência para agents
- `.claude/skills/clone-mind.md` → Pipeline DNA Mental™
- `.claude/skills/squad.md` → Squad creation skill
- `.aios-core/development/scripts/squad/squad-generator.js` → Gerador de estrutura
- `.aios-core/core/synapse/layers/l5-squad.js` → Como squads são descobertos

## Conteúdo deste Package
```
hackerverso-package/
├── BRIEFING.md              ← ESTE ARQUIVO
├── agents/                  ← 7 agents HV (formato AIOS)
│   ├── yoshitani.md
│   ├── fascinations.md
│   ├── kennedy.md
│   ├── halbert.md
│   ├── carlton.md
│   ├── sugarman.md
│   └── makepeace.md
├── tasks/                   ← 14 tasks do pipeline
│   ├── 00-avatar-study.md
│   ├── 00b-trauma-analysis.md
│   ├── 01-hungry-crowd.md
│   ├── 02-problem-discovery.md
│   ├── 03-the-lake.md
│   ├── 04-competitor-flaws.md
│   ├── 05-unique-mechanism.md
│   ├── 06-value-ladder.md
│   ├── 07-irresistible-offer.md
│   ├── 08-lowticket.md
│   ├── 09-vsl-script.md
│   ├── 10-sales-page.md
│   ├── 11-upsell-script.md
│   └── 12-orderbump.md
├── workflows/
│   └── wf-foundation-pipeline.yaml
├── checklists/
│   ├── gate-avatar-validated.md
│   ├── gate-lake-found.md
│   ├── gate-mechanism-unique.md
│   ├── gate-offer-irresistible.md
│   └── gate-copy-converts.md
├── data/
│   └── hackerverso-kb.md
├── config/
│   └── synapse-manifest
└── schemas/
    └── pipeline-io.yaml

standalone-agents/           ← 10 agents cross-squad
├── hormozi-clone.md
├── voss-clone.md
├── ohno-clone.md
├── murphy-clone.md
├── brunson-clone.md
├── suby-clone.md
├── cagan-clone.md
├── ross-clone.md
├── frost-clone.md
└── ellis-clone.md
```
