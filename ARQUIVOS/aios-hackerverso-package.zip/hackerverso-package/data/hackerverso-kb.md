# HackerVerso Knowledge Base

## O que é o HackerVerso

Squad de fundação estratégica do AIOS. Transforma "nicho definido" em "oferta validada com copy pronta" usando pipeline de 14 etapas com 7 clones cognitivos de copywriters lendários.

## Princípio Core

> HackerVerso faz ESTRATÉGIA. Copy-chief faz EXECUÇÃO.

O output do HackerVerso alimenta o copy-chief e outros squads. Ele não duplica o trabalho do copy-chief — ele cria a FUNDAÇÃO que o copy-chief precisa para executar copy de alta conversão.

## Pipeline Overview

```
FASE 1: FUNDAÇÃO (Steps 00-02)
  Avatar profundo → Trauma → Multidão faminta → Problemas rankeados
  Gate 1: Avatar validado?

FASE 2: DIFERENCIAÇÃO (Steps 03-06)
  Lago → Falhas concorrente → Mecanismo único → Escada de valor
  Gate 2: Lago encontrado?
  Gate 3: Mecanismo incomparável?

FASE 3: MONETIZAÇÃO (Steps 07-08)
  Oferta irresistível → Lowticket
  Gate 4: Oferta irresistível?

FASE 4: CONVERSÃO (Steps 09-12)
  VSL → Página vendas → Upsell → Order bump
  Gate 5: Copy converte?
  → Handoff ao copy-chief
```

## Clones e Responsabilidades

| Clone | Steps | Especialidade |
|-------|-------|---------------|
| @yoshitani | 00 | Etnografia digital, pesquisa de avatar |
| @fascinations | 00b, 12 | Psicologia profunda, fascinations |
| @kennedy | 01, 08, 10 | Direct response, urgência, lowticket |
| @halbert | 02 | Dor emocional, pesquisa profunda |
| @carlton | 03, 04, 09 | Posicionamento, VSL, SFC |
| @sugarman | 05 | Mecanismo único, naming proprietário |
| @makepeace | 11 | Upsell, amplificação emocional |
| @hormozi-clone | 06, 07 | Escada valor, Grand Slam Offer (standalone agent) |

## Handoff para copy-chief

Na Phase 4 (Conversão), o HackerVerso produz drafts de VSL, página de vendas, upsell e order bump. Esses drafts são entregues ao copy-chief, que:
1. Seleciona o copywriter ideal (dos 24) para polish
2. Aplica Tier system de diagnóstico (awareness + sophistication)
3. Produz copy final pronta para publicação

## Frameworks Referência

### Grand Slam Offer (Hormozi)
Valor = (Resultado Sonhado × Probabilidade) / (Tempo × Esforço)

### 5 Níveis de Consciência (Schwartz)
1. Unaware → 2. Problem Aware → 3. Solution Aware → 4. Product Aware → 5. Most Aware

### SFC - Simple Fucking Clarity (Carlton)
Se criança de 10 anos não entende, reescreva.

### Slippery Slide (Sugarman)
Cada frase existe para fazer ler a próxima.

### A-pile vs B-pile (Halbert)
Sua comunicação parece pessoal (A-pile) ou lixo comercial (B-pile)?
