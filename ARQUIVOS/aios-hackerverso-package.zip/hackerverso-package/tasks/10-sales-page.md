# Task: Página de Vendas

## Metadata
- **Step:** 10
- **Agent:** @kennedy
- **Phase:** 4 — Conversão
- **depends_on:** [step-09]
- **elicit:** false
- **handoff:** copy-chief

## Input
```yaml
required:
  - vsl_script: "Output Step 09"
  - grand_slam_offer: "Output Step 07"
  - unique_mechanism: "Output Step 05"
```

## Instructions

### 1. Estruturar Página Completa
Hero → Identificação → Vilão → Mecanismo → Prova → Stack → Garantia → FAQ → CTA Final → P.S.

### 2. Adaptar VSL para Texto
O VSL (Step 09) é a base. Adaptar para formato de leitura:
- Headlines mais impactantes (leitura é scanner, vídeo é linear)
- Bullets como fascinations independentes
- Sub-headlines que contam a história sozinhas

### 3. FAQ como Objeção Killer
5-7 perguntas = 5-7 objeções respondidas. Cada FAQ mata 1 razão de não comprar.

### 4. Handoff para copy-chief
Entregar output ao **copy-chief** para execução da copy final.
O copy-chief seleciona o copywriter ideal (dos 24) para polish.

## Output Schema
Seguir `agents/kennedy.md` → "Output: Página de Vendas"

## Next Step
→ Step 11 (@makepeace: Upsell Script)
