# Task: O Lago (Sub-mercado)

## Metadata
- **Step:** 03
- **Agent:** @carlton
- **Phase:** 2 — Diferenciação
- **depends_on:** [step-02]
- **elicit:** true

## Input
```yaml
required:
  - problem_discovery: "Output Step 02"
  - hungry_crowd: "Output Step 01"
optional:
  - competitor_urls: "URLs dos principais concorrentes"
```

## Instructions

### 1. Mapear Consenso do Mercado
O que TODOS os concorrentes dizem? Qual a "verdade aceita"?

### 2. Encontrar a Falha Lógica
Por que essa verdade aceita FALHA para o sub-avatar vencedor?

### 3. Identificar o Lago
O espaço vazio onde ninguém está olhando.
Usar pesquisa real (WebSearch): reviews, reclamações, fóruns.

### 4. Definir Posicionamento
Ângulo contraintuitivo que diferencia de TODOS os concorrentes.
Testar com SFC (Simple Fucking Clarity).

## Output Schema
Seguir `agents/carlton.md` → "Output: O Lago"

## Quality Gate (Gate 2: Lago Encontrado)
Executar `checklists/gate-lake-found.md`
Se FALHAR: pesquisar mais concorrentes, refinar ângulo.

## Next Step
Após Gate 2 → Step 04 (@carlton: Falhas do Concorrente)
