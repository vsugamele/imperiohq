# Task: Multidão Faminta

## Metadata
- **Step:** 01
- **Agent:** @kennedy
- **Phase:** 1 — Fundação
- **depends_on:** [step-00, step-00b]
- **elicit:** true

## Input
```yaml
required:
  - avatar_study: "Output Step 00"
  - trauma_analysis: "Output Step 00b"
```

## Instructions

### 1. Identificar Sub-Avatares
A partir do avatar principal, identificar 3-5 sub-avatares:
- Mesmo nicho, mas com urgências diferentes
- Mesmo problema, mas em fases diferentes
- Mesmo desejo, mas com poder aquisitivo diferente

### 2. Ranquear por Urgência × Dinheiro
Para cada sub-avatar, score 1-10 em:
- **Urgência:** Quão desesperado está para resolver AGORA?
- **Dinheiro:** Tem capacidade de pagar pela solução?
- **Combined:** Urgência × Dinheiro = score final

### 3. Eleger o Vencedor
O sub-avatar com maior score combinado é a "multidão mais faminta".
Toda a copy e oferta serão direcionadas para ELE.

### 4. Definir Messaging Angle
Como falar com esse sub-avatar específico:
- Tom de voz
- Nível de sofisticação
- Urgência vs aspiração

## Output Schema
Seguir `agents/kennedy.md` → "Output: Multidão Faminta"

## Quality Gate
- [ ] Mínimo 3 sub-avatares identificados
- [ ] Score urgência × dinheiro calculado para todos
- [ ] Vencedor eleito com justificativa

## Next Step
Após aprovação do usuário → Step 02 (@halbert: Descobridor de Problemas)
