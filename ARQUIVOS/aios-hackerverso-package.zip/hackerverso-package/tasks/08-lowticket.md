# Task: Oferta Lowticket (Tripwire)

## Metadata
- **Step:** 08
- **Agent:** @kennedy
- **Phase:** 3 — Monetização
- **depends_on:** [step-07]
- **elicit:** true

## Input
```yaml
required:
  - grand_slam_offer: "Output Step 07"
  - value_ladder: "Output Step 06"
  - hungry_crowd: "Output Step 01"
```

## Instructions

### 1. Definir Easy Yes
Produto de R$7-47 que resolve DOR AGUDA (não causa raiz).
Causa raiz é pro produto Core.

### 2. Formato
Escolher formato de entrega rápida: e-book, mini-curso, template, checklist, workshop gravado.

### 3. OTO (One-Time Offer)
Definir oferta pós-compra do tripwire (3-5x preço do tripwire).
É o bridge entre tripwire e produto Core.

### 4. Perceived Value
O valor percebido deve ser 10x+ do preço cobrado.

## Output Schema
Seguir `agents/kennedy.md` → "Output: Lowticket"

## Next Step
→ Step 09 (@carlton: VSL Script)
