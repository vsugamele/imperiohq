# Task: Descobridor de Problemas

## Metadata
- **Step:** 02
- **Agent:** @halbert
- **Phase:** 1 — Fundação
- **depends_on:** [step-01]
- **elicit:** false

## Input
```yaml
required:
  - avatar_study: "Output Step 00"
  - trauma_analysis: "Output Step 00b"
  - hungry_crowd: "Output Step 01 (sub-avatar vencedor)"
```

## Instructions

### 1. Separar Dor Lógica vs Emocional
Usando dados dos steps anteriores, categorizar cada problema do avatar.

### 2. Separar Consciente vs Inconsciente
Problemas que ele admite vs problemas que ele nega/não percebe.

### 3. Criar Hierarquia de Urgência
Ranquear todos os problemas por urgência × impacto emocional.
Os problemas no topo guiam toda a copy.

### 4. Mapear The Gap
Estado atual → Estado desejado → Obstáculo percebido → Obstáculo real.

## Output Schema
Seguir `agents/halbert.md` → "Output: Descoberta de Problemas"

## Quality Gate (Gate 1: Avatar Validado)
Executar `checklists/gate-avatar-validated.md` — este é o primeiro quality gate formal.
Se FALHAR: voltar ao Step 00 com feedback específico.

## Next Step
Após Gate 1 aprovado → Step 03 (@carlton: O Lago)
