# Task: Order Bump

## Metadata
- **Step:** 12
- **Agent:** @fascinations
- **Phase:** 4 — Conversão
- **depends_on:** [step-07]
- **elicit:** false

## Input
```yaml
required:
  - grand_slam_offer: "Output Step 07"
  - trauma_analysis: "Output Step 00b"
```

## Instructions

### 1. Definir Add-On de Impulso
Produto complementar de 15-25% do preço principal.
Aparece no checkout como checkbox — zero fricção.

### 2. Fascination como Headline
O nome e headline do order bump devem ser fascinations irresistíveis.

### 3. Conexão com Produto Principal
Deve complementar (não repetir) o que o produto principal entrega.

## Output Schema
Seguir `agents/fascinations.md` → "Output: Order Bump"

## Pipeline Complete
Após Step 12, o pipeline HackerVerso está completo.
Output consolidado é entregue ao copy-chief para polish final.
