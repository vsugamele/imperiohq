# Task: Resumo Psicológico (Trauma)

## Metadata
- **Step:** 00b
- **Agent:** @fascinations
- **Phase:** 1 — Fundação
- **depends_on:** [step-00]
- **elicit:** false

## Input
```yaml
required:
  - avatar_study: "Output completo do Step 00 (@yoshitani)"
```

## Instructions

### 1. Análise das 3 Camadas
A partir dos dados do @yoshitani, ir além da superfície:
- **Camada 1 (Diz):** O que o avatar expressa publicamente
- **Camada 2 (Sente):** A emoção por trás da expressão
- **Camada 3 (Teme):** O medo raiz que ele não admite

### 2. Mapeamento de Trauma de Origem
Identificar a experiência passada que criou o padrão de medo/auto-sabotagem atual.
Usar as tentativas frustradas (Step 00) como pista.

### 3. Identificação do Sabotador Interno
Nomear o padrão de auto-sabotagem: "O Perfeccionista", "O Desconfiado", "O Procrastinador".
Esse nome será usado em copy para criar conexão ("Eu sei que o [Sabotador] está dizendo que não vai funcionar...")

### 4. Trigger Words
Compilar 5-10 palavras/frases que ativam a ferida emocional.
Essas palavras serão usadas em headlines e hooks.

### 5. Entrega
Preencher output schema do @fascinations → "Output: Trauma Analysis"

## Output Schema
Seguir `agents/fascinations.md` → seção "Output: Trauma Analysis"

## Next Step
Após conclusão → Step 01 (@kennedy: Multidão Faminta)
