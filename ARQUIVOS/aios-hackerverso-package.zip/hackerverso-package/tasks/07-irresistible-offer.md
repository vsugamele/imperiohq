# Task: Oferta Irresistível (Grand Slam)

## Metadata
- **Step:** 07
- **Agent:** @hormozi-clone (standalone agent)
- **Phase:** 3 — Monetização
- **depends_on:** [step-06]
- **elicit:** true

## Input
```yaml
required:
  - value_ladder: "Output Step 06"
  - unique_mechanism: "Output Step 05"
  - problem_discovery: "Output Step 02"
```

## Instructions

### 1. Grand Slam Offer Framework
Aplicar a fórmula: Resultado Sonhado × Probabilidade Percebida / Tempo × Esforço
Maximizar numerador, minimizar denominador.

### 2. Montar Value Stack
Para o produto Core da escada, empilhar componentes:
- Produto principal
- Bônus que matam objeções específicas (1 bônus por objeção)
- Bônus de velocidade (acelera resultado)
- Bônus de facilidade (reduz esforço)

### 3. Pricing com Anchor
- Calcular valor individual de cada componente
- Somar valor total do stack
- Aplicar desconto com justificativa lógica (não "promoção")

### 4. Garantia
Definir tipo: condicional ("Faça X e se não funcionar...") > incondicional.
Garantia condicional demonstra confiança E protege contra abusadores.

## Output Schema
```yaml
grand_slam_offer:
  name: ""
  target: "Sub-avatar vencedor do Step 01"
  promise: "Resultado específico em timeframe"
  components:
    - name: ""
      value: "R$XX"
      solves: "Qual objeção/problema"
    # ... 5-8 componentes
  total_value: "R$XXXX"
  price: "R$XXX"
  discount_logic: "Por que esse preço (não 'promoção')"
  guarantee:
    type: "conditional|unconditional"
    duration: "X dias"
    condition: "Se aplicável"
  scarcity:
    type: "time|quantity|bonus"
    is_real: true
    justification: ""
```

## Quality Gate (Gate 4: Oferta Irresistível)
Executar `checklists/gate-offer-irresistible.md`
Se FALHAR: reempilhar bônus, ajustar pricing.

## Next Step
Após Gate 4 → Step 08 (@kennedy: Lowticket)
