# Task: VSL Script (Video Sales Letter)

## Metadata
- **Step:** 09
- **Agent:** @carlton
- **Phase:** 4 — Conversão
- **depends_on:** [step-05, step-07]
- **elicit:** false

## Input
```yaml
required:
  - unique_mechanism: "Output Step 05"
  - grand_slam_offer: "Output Step 07"
  - competitor_flaws: "Output Step 04"
  - trauma_analysis: "Output Step 00b"
```

## Instructions

### 1. Construir 8 Blocos do VSL
Seguir estrutura @carlton: Hook → Identificação → Vilão → Mecanismo → Prova → Stack → Urgência → CTA.

### 2. Para Cada Bloco
- Escrever copy completa (não outline)
- Cada bloco deve funcionar como mini-argumento independente
- Timing estimado: ~19 minutos total

### 3. Integrar Dados dos Steps Anteriores
- Identificação usa dados do @halbert (Step 02) e @fascinations (Step 00b)
- Vilão usa @carlton (Step 04)
- Mecanismo usa @sugarman (Step 05)
- Stack usa @hormozi-clone (Step 07)

### 4. Handoff
Output final deste step é entregue ao **copy-chief** para refinamento.
O copy-chief tem os copywriters especializados em produção de VSL.

## Output Schema
Seguir `agents/carlton.md` → "Output: VSL Script"

## Quality Gate (Gate 5: Copy Converte)
Executar `checklists/gate-copy-converts.md`

## Next Step
→ Step 10 (@kennedy: Página de Vendas)
