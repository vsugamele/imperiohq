# Task: Estudo Avançado do Avatar

## Metadata
- **Step:** 00
- **Agent:** @yoshitani
- **Phase:** 1 — Fundação
- **elicit:** true

## Input
```yaml
required:
  - niche: "Nicho/mercado do produto"
  - product_description: "Descrição do produto/serviço"
optional:
  - existing_avatar: "Dados existentes do avatar (se houver)"
  - competitors: "URLs de concorrentes conhecidos"
```

## Instructions

### 1. Pesquisa Etnográfica Digital
Pesquisar no mínimo 5 fontes reais onde o avatar convive:
- Grupos Facebook/Reddit/Discord do nicho
- Reviews de produtos concorrentes (Amazon, Reclame Aqui, Trustpilot)
- Comentários em vídeos YouTube do nicho
- Fóruns especializados
- Posts e threads em redes sociais

### 2. Coleta de Linguagem Real
Compilar **swipe file** com mínimo 30 frases EXATAS do avatar:
- Reclamações (como ele descreve a dor)
- Desejos (como ele descreve o que quer)
- Tentativas frustradas (como ele descreve o que já tentou)
- Expressões de identidade (como ele se define)

### 3. Mapeamento de Jornada
Documentar a jornada do avatar ANTES do seu produto:
- O que ele tentou (mínimo 2 tentativas anteriores)
- Quanto gastou
- Por que falhou
- Como se sentiu após cada falha

### 4. Identificação do Trigger Event
Descobrir o que fez o avatar buscar solução AGORA:
- Evento específico (diagnóstico, vergonha pública, prazo)
- Mudança de contexto (novo emprego, filho, separação)
- Acúmulo gradual (gota d'água)

### 5. Entrega
Preencher output schema completo do @yoshitani e apresentar ao usuário para validação.

## Output Schema
Seguir output schema definido em `agents/yoshitani.md` → seção "Output Obrigatório"

## Quality Gate
Executar checklist `checklists/gate-avatar-validated.md` antes de prosseguir.

## Next Step
Após aprovação → Step 00b (@fascinations: Trauma Analysis)
