# Task: Falhas do Concorrente

## Metadata
- **Step:** 04
- **Agent:** @carlton
- **Phase:** 2 — Diferenciação
- **depends_on:** [step-03]
- **elicit:** false

## Input
```yaml
required:
  - the_lake: "Output Step 03"
  - problem_discovery: "Output Step 02"
```

## Instructions

### 1. Listar Métodos que o Avatar Já Tentou
Cada método = uma alternativa/concorrente que falhou.

### 2. Para Cada Método: Mechanism Flaw
Por que esse método falha? Qual o defeito estrutural?

### 3. Montar Ammunition
Para cada falha, definir a promessa oposta que seu produto faz.

### 4. Criar Killer Argument
A frase que mata o concorrente em 1 linha. Será usada em VSL e copy.

## Output Schema
Seguir `agents/carlton.md` → "Output: Falhas do Concorrente"

## Next Step
→ Step 05 (@sugarman: Mecanismo Único)
