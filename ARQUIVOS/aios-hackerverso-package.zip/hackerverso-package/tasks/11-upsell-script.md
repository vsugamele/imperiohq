# Task: Upsell Script

## Metadata
- **Step:** 11
- **Agent:** @makepeace
- **Phase:** 4 — Conversão
- **depends_on:** [step-07, step-10]
- **elicit:** false

## Input
```yaml
required:
  - grand_slam_offer: "Output Step 07"
  - value_ladder: "Output Step 06"
```

## Instructions

### 1. Identificar Próximo Passo Lógico
O upsell é o degrau seguinte na escada de valor.
Não um produto aleatório — o complemento NATURAL.

### 2. Construir Bridge
Produto principal → Gap → Upsell resolve o gap.

### 3. Escrever Script Completo
Hook → Bridge → Offer → Urgência → CTA (sim/não) → Downsell.

### 4. Criar Downsell
Se recusar upsell: versão menor a 40-60% do preço.

## Output Schema
Seguir `agents/makepeace.md` → "Output: Upsell Script"

## Next Step
→ Step 12 (@fascinations: Order Bump)
