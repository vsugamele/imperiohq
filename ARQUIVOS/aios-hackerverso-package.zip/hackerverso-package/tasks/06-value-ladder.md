# Task: Escada de Valor

## Metadata
- **Step:** 06
- **Agent:** @hormozi-clone (standalone agent)
- **Phase:** 2 — Diferenciação
- **depends_on:** [step-05]
- **elicit:** true

## Input
```yaml
required:
  - unique_mechanism: "Output Step 05"
  - hungry_crowd: "Output Step 01"
  - problem_discovery: "Output Step 02"
```

## Instructions

### 1. Mapear Progressão Natural
O que o avatar precisa em SEQUÊNCIA para resolver o problema completo?
Cada degrau = 1 produto/serviço.

### 2. Definir 4-5 Degraus
```
Lead Magnet (R$0) → Tripwire (R$7-47) → Core (R$197-997) → Premium (R$2k-10k) → High-Ticket (R$10k+)
```
Nem todos precisam existir agora. Defina a visão completa.

### 3. Para Cada Degrau
- O que entrega
- Que problema específico resolve
- Como conecta com o próximo degrau
- Preço e justificativa

### 4. Identificar Entry Point
Qual degrau será construído PRIMEIRO? Normalmente Tripwire + Core.

## Output Schema
```yaml
value_ladder:
  degraus:
    - level: 0
      type: "lead_magnet"
      name: ""
      price: "R$0"
      delivers: ""
      problem_solved: ""
      next_step_hook: "O que faz querer o próximo"
    - level: 1
      type: "tripwire"
      name: ""
      price: "R$XX"
      delivers: ""
      problem_solved: ""
      next_step_hook: ""
    # ... até level 4
  entry_point: "Qual construir primeiro"
  total_ltv_estimate: "LTV estimado se percorrer toda escada"
```

## Next Step
→ Step 07 (@hormozi-clone: Oferta Irresistível)
