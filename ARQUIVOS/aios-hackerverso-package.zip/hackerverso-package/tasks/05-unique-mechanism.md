# Task: Mecanismo Único

## Metadata
- **Step:** 05
- **Agent:** @sugarman
- **Phase:** 2 — Diferenciação
- **depends_on:** [step-04]
- **elicit:** true

## Input
```yaml
required:
  - competitor_flaws: "Output Step 04"
  - the_lake: "Output Step 03"
  - product_description: "Do Step 00 input original"
```

## Instructions

### 1. Identificar Verdade Contraintuitiva
O que é verdade sobre o problema que contradiz o senso comum?

### 2. Construir Mecanismo de 3 Passos
Passo 1 (Limpa/Prepara) → Passo 2 (Ativa/Instala) → Passo 3 (Acelera/Escala)

### 3. Naming Proprietário
Gerar mínimo 5 nomes para o mecanismo. Testar com critérios:
- Soa NOVO? Soa ESPECÍFICO? Desperta curiosidade?
- Alguém google isso e não encontra nada? (= proprietário)

### 4. Criar Analogia
Explicar o mecanismo para uma criança de 5 anos. Se não conseguir, simplificar.

## Output Schema
Seguir `agents/sugarman.md` → "Output: Mecanismo Único"

## Quality Gate (Gate 3: Mecanismo Incomparável)
Executar `checklists/gate-mechanism-unique.md`
Se FALHAR: refinar naming e diferenciação.

## Next Step
Após Gate 3 → Step 06 (@hormozi-clone: Escada de Valor)
