# Quality Gate 5: Copy Converte

## Quando Executar
Após Step 12 (Order Bump), fim do pipeline. Validação final antes de handoff ao copy-chief.

## Checklist

### VSL (MUST)
- [ ] 8 blocos presentes (Hook→Identificação→Vilão→Mecanismo→Prova→Stack→Urgência→CTA)
- [ ] Cada bloco funciona como mini-argumento independente
- [ ] Timing ~19 minutos estimado
- [ ] Linguagem simples (teste SFC)

### Página de Vendas (MUST)
- [ ] Headlines específicas (números, timeframe, resultado)
- [ ] Mínimo 3 CTAs distribuídos
- [ ] FAQ com 5-7 objeções respondidas
- [ ] P.S. presente e impactante

### Upsell (MUST)
- [ ] É o próximo passo LÓGICO do produto principal
- [ ] Bridge clara: principal → gap → upsell
- [ ] Downsell presente (40-60% do preço do upsell)
- [ ] Escassez real

### Order Bump (MUST)
- [ ] Preço 15-25% do produto principal
- [ ] Headline é fascination irresistível
- [ ] Complementa (não repete) o produto principal

### Consistência Cross-Step (MUST)
- [ ] Linguagem do avatar consistente em toda copy
- [ ] Mecanismo único referenciado em VSL, página e upsell
- [ ] Posicionamento contraintuitivo mantido
- [ ] Stack de valor idêntico em VSL e página

## Verdict
- **PASS:** Entregar pacote completo ao copy-chief para polish e produção
- **FAIL:** Identificar steps inconsistentes e reprocessar
