# Quality Gate 2: Lago Encontrado

## Quando Executar
Após Step 03 (O Lago), antes de Step 04.

## Checklist

### Pesquisa Competitiva (MUST)
- [ ] Mínimo 3 concorrentes/alternativas mapeados
- [ ] Consenso do mercado identificado (o que todos dizem)
- [ ] Falha lógica do consenso articulada

### Posicionamento (MUST)
- [ ] Ângulo contraintuitivo definido (não é "melhor" — é DIFERENTE)
- [ ] Statement de posicionamento em 1 frase
- [ ] Passa no teste SFC (criança de 10 anos entende?)

### Lago (MUST)
- [ ] Espaço vazio identificado (onde ninguém está)
- [ ] Justificativa de por que está vazio (oportunidade vs armadilha)
- [ ] Onde o avatar JÁ gasta dinheiro mapeado

## Verdict
- **PASS:** → Step 04
- **FAIL:** Pesquisar mais concorrentes, refinar ângulo
