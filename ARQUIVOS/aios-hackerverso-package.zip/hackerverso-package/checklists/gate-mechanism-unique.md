# Quality Gate 3: Mecanismo Incomparável

## Quando Executar
Após Step 05 (Mecanismo Único), antes de Phase 3.

## Checklist

### Naming (MUST)
- [ ] Nome proprietário definido (não genérico)
- [ ] Google search do nome retorna 0 resultados relevantes
- [ ] Mínimo 5 alternativas geradas
- [ ] Nome escolhido desperta curiosidade

### Mecanismo (MUST)
- [ ] Insight contraintuitivo articulado
- [ ] 3 passos claros e sequenciais (Limpa → Ativa → Acelera)
- [ ] Diferenciação explícita dos métodos que falharam (Step 04)
- [ ] Analogia clara (criança de 5 anos entende)

### Conexão (MUST)
- [ ] Mecanismo resolve o problema #1 da hierarquia (Step 02)
- [ ] Mecanismo explica POR QUE os concorrentes falham
- [ ] "Why now" articulado (por que esse método é novo/recente)

## Verdict
- **PASS:** → Phase 3 (Monetização)
- **FAIL:** Refinar naming, fortalecer diferenciação
