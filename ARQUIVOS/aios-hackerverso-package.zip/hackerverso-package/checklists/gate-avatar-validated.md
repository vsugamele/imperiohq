# Quality Gate 1: Avatar Validado

## Quando Executar
Após Step 02 (Descobridor de Problemas), antes de Phase 2.

## Checklist

### Pesquisa (MUST)
- [ ] Mínimo 5 fontes reais pesquisadas (fóruns, reviews, grupos)
- [ ] Sources listadas com URLs
- [ ] Linguagem do avatar é CITAÇÃO, não paráfrase

### Avatar (MUST)
- [ ] Desejo EXTERNO identificado (o que diz que quer)
- [ ] Desejo INTERNO identificado (o que realmente quer — diferente do externo)
- [ ] Trigger event identificado (por que agora?)
- [ ] Fase de consciência definida

### Psicologia (MUST)
- [ ] 3 camadas mapeadas: diz/sente/teme
- [ ] Trauma de origem com evento específico
- [ ] Sabotador interno nomeado
- [ ] Mínimo 5 trigger words

### Problemas (MUST)
- [ ] Separação dor lógica vs emocional
- [ ] Problemas conscientes E inconscientes
- [ ] Hierarquia com score de urgência × emoção
- [ ] Mínimo 10 problemas mapeados

### Multidão (MUST)
- [ ] 3+ sub-avatares rankeados
- [ ] Vencedor eleito com justificativa

## Verdict
- **PASS:** Todos MUST atendidos → Prosseguir para Phase 2
- **FAIL:** Qualquer MUST faltando → Voltar ao step que falhou com feedback
