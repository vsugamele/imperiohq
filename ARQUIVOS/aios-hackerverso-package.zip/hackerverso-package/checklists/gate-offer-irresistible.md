# Quality Gate 4: Oferta Irresistível

## Quando Executar
Após Step 08 (Lowticket), antes de Phase 4.

## Checklist

### Grand Slam Offer (MUST)
- [ ] Fórmula aplicada: (Resultado × Probabilidade) / (Tempo × Esforço)
- [ ] Value stack com 5-8 componentes
- [ ] Cada bônus mata 1 objeção específica (não é "mais conteúdo")
- [ ] Preço justificado com lógica (não desconto)

### Garantia (MUST)
- [ ] Tipo definido (condicional ou incondicional)
- [ ] Duração definida
- [ ] Se condicional: condição é razoável e demonstra confiança

### Escada de Valor (MUST)
- [ ] Mínimo 3 degraus definidos
- [ ] Cada degrau conecta com o próximo
- [ ] Entry point definido

### Lowticket (MUST)
- [ ] Preço R$7-47
- [ ] Resolve dor AGUDA (não causa raiz)
- [ ] OTO definido (3-5x preço do tripwire)
- [ ] Valor percebido 10x+ do preço

## Verdict
- **PASS:** → Phase 4 (Conversão)
- **FAIL:** Reempilhar bônus, ajustar pricing, refinar lowticket
