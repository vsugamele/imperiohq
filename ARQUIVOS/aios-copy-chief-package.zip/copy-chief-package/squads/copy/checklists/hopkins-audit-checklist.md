# Checklist: Hopkins Audit — Scientific Advertising

## Pré-Auditoria
- [ ] Copy completo recebido (não fragmentos)
- [ ] Tipo de copy identificado (sales page, email, ad, etc.)
- [ ] Awareness level do público definido
- [ ] Market sophistication level definido
- [ ] Unique mechanism documentado (se existir)

## 10 Dimensões (0-10 cada, mínimo 85/100)

### D1. Headline / Abertura
- [ ] Interrompe atenção
- [ ] Filtra público certo
- [ ] Promessa clara OU curiosidade irresistível
- [ ] Conecta com conversa mental do prospect
- ❌ Red flag: genérica, clickbait, impossível

### D2. Lead / Gancho
- [ ] Primeiros 3 parágrafos prendem
- [ ] Relevância pessoal estabelecida
- [ ] Curiosidade para continuar
- [ ] Match com awareness level
- ❌ Red flag: fala do produto antes do problema

### D3. Problema / Dor
- [ ] Palavras do prospect (mirror words)
- [ ] Camadas: lógica + emocional + identidade
- [ ] Agitação adequada (nem demais, nem de menos)
- [ ] "Essa pessoa me entende"
- ❌ Red flag: dor genérica, manipulação

### D4. Mecanismo / Solução
- [ ] Único e diferenciado
- [ ] "Por que funciona" explicado
- [ ] Credibilidade (lógica ou científica)
- [ ] Naming proprietário
- ❌ Red flag: "meu método de 7 passos"

### D5. Prova / Credibilidade
- [ ] Social proof específico
- [ ] Números, nomes, timeframes
- [ ] Credenciais relevantes
- [ ] Prova adequada ao claim
- ❌ Red flag: depoimentos vagos

### D6. Oferta / Valor
- [ ] Valor >> preço (irresistível)
- [ ] Value stack claro
- [ ] Garantia remove risco
- [ ] Urgência/escassez REAL
- ❌ Red flag: bônus aleatórios, urgência falsa

### D7. CTA / Fechamento
- [ ] Claro e específico
- [ ] Últimas objeções removidas
- [ ] Linguagem de ação
- [ ] Alinhado com awareness level
- ❌ Red flag: CTA fraco, CTAs conflitantes

### D8. Flow / Slippery Slide
- [ ] Cada seção → próxima (natural)
- [ ] Sem pontos de abandono
- [ ] Ritmo varia
- [ ] Transições presentes
- ❌ Red flag: blocos enormes, saltos lógicos

### D9. Voz / Tom
- [ ] Consistente com marca
- [ ] Match com público
- [ ] Autêntico (não genérico/AI)
- [ ] Personalidade presente
- ❌ Red flag: tom muda no meio

### D10. Adequação Estratégica
- [ ] Match awareness level
- [ ] Match sophistication level
- [ ] Posição correta na value ladder
- [ ] Consistente com narrativa do funil
- ❌ Red flag: copy wrong-awareness

## Score Final
```
Total: ___/100

≥90: EXCELENTE → Aprovar
85-89: BOM → Aprovar + notes
70-84: MÉDIO → Revisão obrigatória
50-69: FRACO → Rewrite significativo
<50: REPROVADO → Rewrite completo
```

## Ações Pós-Auditoria
- [ ] Feedback para cada dimensão < 8
- [ ] Rewrite sugerido para dimensão < 6
- [ ] Copywriter atribuído para revisão
- [ ] Se ≥85: enviar para Sugarman 30 Triggers Check
