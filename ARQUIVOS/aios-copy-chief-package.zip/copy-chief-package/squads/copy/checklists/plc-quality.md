# Checklist: PLC Quality — Validação de Pre-Launch Content

## PLC 1: "A Oportunidade"
- [ ] Hook nos primeiros 30 segundos
- [ ] Ensina algo REAL e aplicável
- [ ] Framework actionable com resultado parcial
- [ ] Reframe de crença limitante
- [ ] NÃO vende nada (zero pitch)
- [ ] Loop aberto para PLC 2
- [ ] Pede engajamento (comentário)
- [ ] Mirror words do avatar presentes
- [ ] Duração: 15-25 minutos
- [ ] Mental triggers: Autoridade + Reciprocidade + Curiosidade

## PLC 2: "A Transformação"
- [ ] Recap do PLC 1 (< 2 minutos)
- [ ] Social proof dos comentários do PLC 1
- [ ] Case study completo (Before → After)
- [ ] Números específicos (tempo, resultado, valores)
- [ ] Framework mais profundo que PLC 1
- [ ] 2-3 objeções endereçadas explicitamente
- [ ] Loop aberto para PLC 3
- [ ] Duração: 20-30 minutos
- [ ] Mental triggers: Prova Social + Autoridade + Antecipação

## PLC 3: "A Experiência"
- [ ] Community celebration (comentários/resultados)
- [ ] Sistema completo revelado (high-level)
- [ ] Future pacing emocional e específico
- [ ] Value stack com valores percebidos
- [ ] Soft pitch (convite, não pressão)
- [ ] Data/hora de abertura do carrinho mencionada
- [ ] CTA de engajamento ("EU QUERO")
- [ ] Duração: 25-40 minutos
- [ ] Mental triggers: Antecipação + Escassez + Propriedade

## Sequência Geral
- [ ] Progressão lógica (Why → What → How)
- [ ] Cada PLC standalone = valor (não depende dos outros)
- [ ] Cada PLC cria anticipação para o próximo
- [ ] Valor real entregue (não teaser vazio)
- [ ] Tom consistente entre PLCs
- [ ] Cadência definida (dias entre PLCs)

## Gate Final
```
Todos ✅ por PLC: PLC aprovado
Todos 3 PLCs aprovados: Prosseguir para Open Cart
Algum ❌: Corrigir antes de publicar
```
