# Checklist: Copy Quality — Validação Geral

## Estrutura
- [ ] Headline presente e forte
- [ ] Lead prende nos primeiros 3 parágrafos
- [ ] Problema/dor articulado nas palavras do avatar
- [ ] Solução/mecanismo apresentado com credibilidade
- [ ] Prova social presente e específica
- [ ] Oferta clara com value stack
- [ ] CTA presente e acionável
- [ ] P.S. reinforça mensagem principal

## Persuasão
- [ ] Awareness level correto (Schwartz scale)
- [ ] Market sophistication adequada
- [ ] Objeções endereçadas (mínimo top 3)
- [ ] Urgência real (não fabricada)
- [ ] Garantia presente (se aplicável)
- [ ] Risk reversal claro

## Técnica
- [ ] Slippery slide (cada seção leva à próxima)
- [ ] Bucket brigades entre seções
- [ ] Parágrafos curtos (3-4 linhas máximo)
- [ ] Sem jargão desnecessário
- [ ] Tom consistente do início ao fim
- [ ] Sem repetição de argumentos

## Ética
- [ ] Claims são verdadeiros e verificáveis
- [ ] Depoimentos são reais
- [ ] Urgência/escassez é genuína
- [ ] Garantia será honrada
- [ ] Sem manipulação emocional excessiva

## Formatação
- [ ] Mobile-friendly (parágrafos curtos)
- [ ] Headlines/subheadlines scanáveis
- [ ] Bold/italic usado com propósito
- [ ] Links funcionais
- [ ] Sem erros de português

## Gate Final
```
Todos ✅ acima: APROVADO para Hopkins Audit
Algum ❌: CORRIGIR antes de auditar
```
