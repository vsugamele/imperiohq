# Template: Subject Lines por Fase do Lançamento

## Pre-Prelaunch
| Tipo | Subject A | Subject B |
|------|-----------|-----------|
| Whisper | "Posso te contar uma coisa?" | "Algo que estou planejando..." |
| Survey | "Preciso da sua opinião (1 min)" | "Me ajuda com isso?" |
| Tease | "Baseado no que vocês disseram..." | "Vocês pediram, eu ouvi" |
| Waitlist | "Quer ser o primeiro a saber?" | "Lista VIP: {product}" |

## PLC Delivery
| PLC | Subject A | Subject B |
|-----|-----------|-----------|
| PLC 1 | "Está no ar: {title}" | "Assista agora: {promise}" |
| PLC 1 Reminder | "Você viu isso?" | "Não perde: {result}" |
| PLC 2 | "O próximo passo: {title}" | "Como {name} conseguiu {result}" |
| PLC 2 Reminder | "Importante: vídeo 2 de 3" | "A transformação de {name}" |
| PLC 3 | "O sistema completo" | "Última peça do quebra-cabeça" |
| Bridge | "Amanhã acontece." | "Fique atento ao seu email amanhã" |

## Cart Open
| Dia | Subject A | Subject B |
|-----|-----------|-----------|
| D1 AM | "Está aberto!" | "Inscrições abertas para {product}" |
| D1 PM | "Bônus para quem agir agora" | "24h: bônus exclusivo" |
| D2 | "A história de {name}" | "De {before} para {after}" |
| D3 | "Suas perguntas respondidas" | "FAQ: tudo sobre {product}" |
| D4 | "Isso NÃO é para todo mundo" | "Será que é para você?" |
| D5 | "Bônus {name} expira hoje" | "Última chance: {bonus}" |

## Cart Close
| Timing | Subject A | Subject B |
|--------|-----------|-----------|
| D-1 | "24 horas." | "Amanhã fecha." |
| Last Day AM | "Últimas horas" | "Hoje é o último dia" |
| Last Day PM | "Fechando em X horas" | "Última chamada" |
| Final | "É agora ou..." | "Última chance: {product}" |

## Post-Cart
| Tipo | Subject A | Subject B |
|------|-----------|-----------|
| Buyers | "Bem-vindo! Próximos passos" | "Parabéns! Comece aqui" |
| Non-buyers | "As portas fecharam" | "Obrigado por acompanhar" |

## Regras
- Máximo 50 caracteres
- Nunca ALL CAPS
- Emojis: máximo 1, no início
- Personalizar com nome quando possível
- Testar A/B em cada envio
