# Template: PLC 1 Script — "A Oportunidade"

## Variáveis
- `{PRODUCT_NAME}` — Nome do produto
- `{TRANSFORMATION}` — Transformação prometida
- `{AVATAR_PAIN}` — Dor principal do avatar
- `{MIRROR_WORDS}` — Frases do avatar (pesquisa)
- `{FRAMEWORK_NAME}` — Nome do framework ensinado
- `{RESULT_PREVIEW}` — Resultado parcial que o framework entrega
- `{PLC2_TEASER}` — Teaser do PLC 2

---

## Script Structure

### [0:00-0:30] HOOK
> "Se você está {AVATAR_PAIN}, nos próximos [XX] minutos vou te mostrar {TRANSFORMATION}. E a melhor parte: vou te dar um framework que você pode aplicar HOJE."

### [0:30-4:00] STORY OF OPPORTUNITY
> "Eu sei como é {MIRROR_WORDS}..."
> [Contar história de como descobriu a oportunidade]
> "O que mudou foi [evento/insight]. E isso abriu uma janela que..."
> [Explicar por que AGORA é diferente]

### [4:00-14:00] TEACHING SECTION
> "Deixa eu te mostrar o {FRAMEWORK_NAME}..."
> [Ensinar framework actionable]
> "Se você aplicar APENAS isso, já vai conseguir {RESULT_PREVIEW}."
> [Demonstrar com exemplo prático]

### [14:00-17:00] REFRAME
> "Provavelmente você acredita que [crença limitante]. Eu também acreditava."
> "Mas o que descobri é que [nova perspectiva]..."
> [NÃO revelar mecanismo completo — loop aberto]

### [17:00-19:00] CTA
> "No próximo vídeo, vou revelar {PLC2_TEASER}. Vai mudar como você pensa sobre [tema]."
> "Comenta aqui embaixo: qual foi o maior insight desse vídeo?"
> "Te vejo no PLC 2."

---

## Checklist Pós-Escrita
- [ ] Hook nos primeiros 30 segundos
- [ ] Ensina algo REAL e aplicável
- [ ] NÃO vende nada
- [ ] Loop aberto para PLC 2
- [ ] Pede engajamento (comentário)
- [ ] Mirror words do avatar presentes
- [ ] Duração: 15-25 minutos
