# Template: PLC 2 Script — "A Transformação"

## Variáveis
- `{PLC1_RECAP}` — Recap breve do PLC 1
- `{CASE_STUDY_NAME}` — Nome do case study
- `{BEFORE_STATE}` — Situação antes
- `{AFTER_STATE}` — Resultado alcançado
- `{TIMELINE}` — Em quanto tempo
- `{MECHANISM_HINT}` — Hint do mecanismo único
- `{OBJECTION_1}`, `{OBJECTION_2}` — Objeções principais
- `{PLC3_TEASER}` — Teaser do PLC 3

---

## Script Structure

### [0:00-2:00] RECAP + SOCIAL PROOF
> "No PLC 1, eu mostrei {PLC1_RECAP}."
> "E a resposta de vocês foi incrível..."
> [Ler 2-3 comentários reais do PLC 1]

### [2:00-9:00] CASE STUDY
> "Quero te apresentar {CASE_STUDY_NAME}."
> "Quando [ele/ela] começou, estava {BEFORE_STATE}."
> [Detalhar a jornada com momentos específicos]
> "Em {TIMELINE}, [ele/ela] alcançou {AFTER_STATE}."
> "E o que possibilitou isso foi {MECHANISM_HINT}."

### [9:00-21:00] DEEPER TEACHING
> "Agora vou aprofundar..."
> [Framework 2 — mais profundo que PLC 1]
> [Conectar com o mecanismo único]
> "A razão pela qual a maioria não consegue é..."
> [Revelar gap de conhecimento que o produto preenche]

### [21:00-26:00] OBJECTION HANDLING
> "Talvez você esteja pensando: '{OBJECTION_1}'"
> [Responder com lógica + emoção + prova]
> "Ou talvez: '{OBJECTION_2}'"
> [Responder]

### [26:00-28:00] CTA
> "No próximo vídeo, {PLC3_TEASER}."
> "Vou revelar o sistema completo."
> "Comenta: o que mais te surpreendeu hoje?"

---

## Checklist Pós-Escrita
- [ ] Recap do PLC 1 (< 2 minutos)
- [ ] Case study com Before → After específico
- [ ] Framework mais profundo que PLC 1
- [ ] 2-3 objeções endereçadas
- [ ] Loop aberto para PLC 3
- [ ] Duração: 20-30 minutos
