# Template: Sales Page Blueprint (PLF)

## Estrutura de Página PLF

### Section 1: Hero
```
[HEADLINE]: {main_promise} em {timeframe}
[SUB-HEADLINE]: {mechanism} que já ajudou {X} pessoas a {result}
[VIDEO ou RECAP]: 2-3min resumindo a jornada dos PLCs
[CTA]: {cta_text} →→→ [botão]
```

### Section 2: Journey Recap
```
Nos últimos {X} dias, você descobriu:
✓ PLC 1: {key_insight_1}
✓ PLC 2: {key_insight_2}  
✓ PLC 3: {key_insight_3}

Agora é hora de dar o próximo passo.
```

### Section 3: Offer Stack
```
Tudo que está incluído:

▸ {CORE_PRODUCT}: {benefit} — Valor: R${X}
▸ {MODULE_2}: {benefit} — Valor: R${X}
▸ {MODULE_3}: {benefit} — Valor: R${X}

BÔNUS #1: {name} — {benefit} — Valor: R${X}
BÔNUS #2: {name} — {benefit} — Valor: R${X}
BÔNUS #3: {name} — {benefit} — Valor: R${X}

━━━━━━━━━━━━━━━━━━━━
VALOR TOTAL: R${total}
SEU INVESTIMENTO: R${price}
━━━━━━━━━━━━━━━━━━━━
```

### Section 4: Guarantee
```
GARANTIA DE {X} DIAS

Se em {X} dias você {condition}, devolvemos 100% do seu investimento.
Sem perguntas. Sem burocracia. O risco é TODO nosso.
```

### Section 5: Social Proof
```
[DEPOIMENTO 1]: {name} — "{quote}" — Resultado: {result}
[DEPOIMENTO 2]: {name} — "{quote}" — Resultado: {result}
[DEPOIMENTO 3]: {name} — "{quote}" — Resultado: {result}
[SCREENSHOTS de comentários dos PLCs]
```

### Section 6: FAQ
```
P: {question_1}
R: {answer_1}

P: {question_2}
R: {answer_2}
... (5-8 FAQs)
```

### Section 7: Final CTA + P.S.
```
[CTA FINAL]: {cta_text} →→→ [botão]

P.S. — {recap_transformation}
P.S.2 — {guarantee_reminder}
P.S.3 — {urgency_reminder}
```
