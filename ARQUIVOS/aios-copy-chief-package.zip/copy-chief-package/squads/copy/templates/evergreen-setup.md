# Template: Evergreen Funnel Setup

## Step 1: Converter PLCs
Para cada PLC gravado:
- [ ] Remover referências a datas específicas
- [ ] Remover "esta semana", "ontem", "amanhã"
- [ ] Substituir por linguagem atemporal
- [ ] Manter urgência via linguagem de oportunidade
- [ ] Adicionar captions/legendas

## Step 2: Configurar Automação
```
TRIGGER: Opt-in na landing page
├── D+0: Welcome email + PLC 1
├── D+1: Reminder PLC 1 (se não assistiu)
├── D+2: PLC 2 delivery
├── D+3: Reminder PLC 2 + social proof email
├── D+4: PLC 3 delivery
├── D+5: Bridge email ("amanhã abre")
├── D+6: Cart open email (deadline = D+12)
├── D+7: Case study email
├── D+8: FAQ email
├── D+9: Objection crusher email
├── D+10: Last bonus email
├── D+11: 24h warning
├── D+12: Cart close (3 emails: AM, PM, 23h)
└── D+42: Re-engagement (30 dias depois)
```

## Step 3: Deadline Dinâmico
- [ ] Deadline Funnel (ou similar) instalado
- [ ] Cookie configurado (7 dias de acesso ao cart)
- [ ] Página expirada configurada ("Inscrições fecharam")
- [ ] Redirect após deadline para waitlist
- [ ] Teste: verificar que deadline é real (testar expiração)

## Step 4: Páginas Necessárias
- [ ] Landing page (opt-in)
- [ ] PLC 1 page (vídeo + comentários)
- [ ] PLC 2 page (vídeo + comentários)
- [ ] PLC 3 page (vídeo + CTA suave)
- [ ] Sales page (com timer dinâmico)
- [ ] Checkout page
- [ ] Thank you page
- [ ] Expired page (deadline passou)
- [ ] Waitlist page (pós-expiração)

## Step 5: Métricas de Monitoramento
| Métrica | Target | Frequência |
|---------|--------|------------|
| Opt-in rate | >30% | Diário |
| PLC 1 view rate | >60% | Semanal |
| PLC retention (1→3) | >40% | Semanal |
| Cart page visit | >25% de PLC 3 views | Semanal |
| Conversion rate | >2% de leads | Semanal |
| Revenue per lead | >R$X | Mensal |
| Refund rate | <10% | Mensal |

## Step 6: Split Tests (prioridade)
1. Landing page headline (maior impacto)
2. PLC 1 hook (primeiros 30 seg)
3. Sales page headline
4. Email subject: cart open
5. Email subject: cart close
