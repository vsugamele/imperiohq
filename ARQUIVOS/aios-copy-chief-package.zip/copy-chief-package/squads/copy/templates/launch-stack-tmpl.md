# Template: Launch Stack Visual

## Stack Structure

```
┌─────────────────────────────────────────┐
│        {PRODUCT_NAME}                    │
│        A transformação completa          │
├─────────────────────────────────────────┤
│                                         │
│  📦 CORE: {core_product}               │
│     {core_benefit}                      │
│     Valor: R${core_value}              │
│                                         │
│  📦 {module_2_name}                     │
│     {module_2_benefit}                  │
│     Valor: R${module_2_value}          │
│                                         │
│  📦 {module_3_name}                     │
│     {module_3_benefit}                  │
│     Valor: R${module_3_value}          │
│                                         │
├─────────────────────────────────────────┤
│  🎁 BÔNUS #1: {bonus_1_name}           │
│     {bonus_1_benefit}                   │
│     Valor: R${bonus_1_value}           │
│                                         │
│  🎁 BÔNUS #2: {bonus_2_name}           │
│     {bonus_2_benefit}                   │
│     Valor: R${bonus_2_value}           │
│                                         │
│  🎁 BÔNUS #3: {bonus_3_name}           │
│     {bonus_3_benefit}                   │
│     Valor: R${bonus_3_value}           │
│                                         │
├─────────────────────────────────────────┤
│                                         │
│  VALOR TOTAL: R${total_value}          │
│                                         │
│  ✨ SEU INVESTIMENTO: R${price}         │
│     ({installments}x de R${monthly})   │
│                                         │
│  🛡️ GARANTIA: {guarantee_days} dias     │
│     {guarantee_text}                    │
│                                         │
│         [ {CTA_TEXT} ]                  │
│                                         │
└─────────────────────────────────────────┘
```

## Script de Apresentação do Stack
```
"Vamos recapitular tudo que você recebe ao se inscrever hoje:

Primeiro, o {core_product}. Isso sozinho já vale R${core_value} porque 
{core_benefit}.

Além disso, você recebe {module_2_name}, que {module_2_benefit}. 
Valor: R${module_2_value}.

E {module_3_name}: {module_3_benefit}. Valor: R${module_3_value}.

Mas eu quero ir além. Preparei 3 bônus exclusivos:

Bônus 1: {bonus_1_name} — {bonus_1_benefit}. Sozinho vale R${bonus_1_value}.
Bônus 2: {bonus_2_name} — {bonus_2_benefit}. Valor: R${bonus_2_value}.
Bônus 3: {bonus_3_name} — {bonus_3_benefit}. Valor: R${bonus_3_value}.

O valor total de tudo isso é R${total_value}.

Mas seu investimento hoje não é isso. Nem metade.

Seu investimento é apenas R${price}. 
Isso dá {installments}x de R${monthly}.

E se em {guarantee_days} dias você não {guarantee_condition}, 
eu devolvo 100% do seu investimento. O risco é TODO meu.

Então: R${total_value} de valor. R${price} de investimento. 
E garantia total de {guarantee_days} dias.

{CTA_TEXT}."
```

## Regras do Stack
- Valor percebido total ≥ 10x o preço
- Cada valor individual é justificável
- Bônus complementam (não são filler)
- Garantia é a última camada (reduz risco a zero)
- CTA imediatamente após o stack
