# Template: PLC 3 Script — "A Experiência"

## Variáveis
- `{COMMUNITY_COMMENTS}` — Comentários da comunidade
- `{SYSTEM_STEPS}` — Passos do sistema (high-level)
- `{FUTURE_DATE}` — Data futura para future pacing
- `{FUTURE_RESULT}` — Resultado no future pacing
- `{VALUE_STACK}` — Lista de itens com valor
- `{OPEN_DATE}` — Data de abertura do carrinho
- `{OPEN_TIME}` — Hora de abertura

---

## Script Structure

### [0:00-3:00] COMMUNITY CELEBRATION
> "Antes de tudo, olhem o que está acontecendo..."
> [Ler comentários/resultados dos PLCs anteriores]
> "Vocês estão aplicando e tendo resultado ANTES de eu oferecer qualquer coisa."

### [3:00-15:00] FULL SYSTEM REVEAL
> "Hoje vou revelar o sistema completo."
> "São {X} passos: {SYSTEM_STEPS}"
> [Explicar cada passo (high-level, sem entregar implementação)]
> "Quando você conecta esses passos, o resultado é [transformação]."

### [15:00-23:00] FUTURE PACING
> "Imagine que é {FUTURE_DATE}."
> "Você acorda e [descrever dia ideal com resultado]."
> "{FUTURE_RESULT} não é mais um sonho — é terça-feira."
> [Detalhar 3-4 cenários específicos da vida transformada]

### [23:00-33:00] VALUE STACK REVEAL
> "Agora, se você está pronto para essa transformação..."
> "Deixa eu te mostrar tudo que preparei:"
> [Revelar cada item do stack com valor]
> {VALUE_STACK}
> "O valor total é R$XX.XXX."

### [33:00-38:00] SOFT PITCH
> "Amanhã, {OPEN_DATE} às {OPEN_TIME}, vou abrir as inscrições."
> "As vagas são limitadas a [X] pessoas nessa turma."
> "Se você quer [transformação], fique atento ao seu email."

### [38:00-40:00] CLOSE
> "Comenta aqui: 'EU QUERO' se você está pronto."
> "Te vejo amanhã quando o carrinho abrir."
> "Valeu por estar nessa jornada comigo."

---

## Checklist Pós-Escrita
- [ ] Community proof nos primeiros 3 minutos
- [ ] Sistema revelado (high-level, não entrega tudo)
- [ ] Future pacing emocional e específico
- [ ] Value stack com valores percebidos
- [ ] NÃO revela preço (ou revela no final se estratégico)
- [ ] Soft pitch empático (convite, não pressão)
- [ ] CTA de engajamento ("EU QUERO")
- [ ] Duração: 25-40 minutos
