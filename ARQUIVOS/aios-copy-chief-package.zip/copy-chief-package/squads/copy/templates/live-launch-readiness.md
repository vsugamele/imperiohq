# Checklist: Live Launch Readiness

## Tech Stack
- [ ] Plataforma de live definida (Zoom/YouTube Live/StreamYard)
- [ ] Teste de áudio e vídeo realizado
- [ ] Backup de internet configurado (4G)
- [ ] Landing page de registro pronta
- [ ] Email automático de confirmação configurado
- [ ] Replay automático configurado

## Conteúdo
- [ ] PLC 1 script completo e ensaiado
- [ ] PLC 2 script completo e ensaiado
- [ ] PLC 3 script completo e ensaiado
- [ ] Slides/suporte visual prontos
- [ ] Q&A planted questions preparadas

## Equipe
- [ ] Moderador de chat briefado
- [ ] Suporte técnico on-standby
- [ ] Links e CTAs prontos para chat

## Email Sequences
- [ ] Pre-live warmup emails (4 por PLC = 12 total)
- [ ] Replay emails configurados
- [ ] Reminder automáticos programados

## Página de Vendas
- [ ] Sales page pronta e testada
- [ ] Checkout funcional (testar compra real)
- [ ] Payment gateway ativo
- [ ] Garantia configurada no sistema
- [ ] Thank you page pronta

## Open Cart Event
- [ ] Script do evento de abertura
- [ ] Timer/countdown configurado
- [ ] Early bird bonus pronto
- [ ] Email de cart open agendado

## Go/No-Go (72h antes)
- [ ] ✅ Todos PLCs prontos e ensaiados
- [ ] ✅ Tech testada com live de teste
- [ ] ✅ Emails agendados
- [ ] ✅ Sales page + checkout testados
- [ ] ✅ Equipe briefada
→ Se 5/5: GO
