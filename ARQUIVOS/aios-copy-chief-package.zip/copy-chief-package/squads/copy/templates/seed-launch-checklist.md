# Checklist: Seed Launch Readiness

## Pré-Requisitos
- [ ] Ideia de produto validada (conversas com 10+ pessoas)
- [ ] Avatar profile básico definido
- [ ] Lista de email existente (mínimo 50 pessoas)
- [ ] Plataforma de email configurada
- [ ] Método de pagamento configurado
- [ ] Plataforma de entrega (Zoom, Google Meet)

## Oferta Semente
- [ ] Preço semente definido (50-70% desconto vs futuro)
- [ ] Número máximo de vagas definido (10-50)
- [ ] Formato definido (live sessions semanais)
- [ ] Duração definida (4-8 semanas)
- [ ] Bônus de founding member definido

## Sequência de Emails
- [ ] Email 1: Pesquisa (escrito e testado)
- [ ] Email 2: Insights da pesquisa (template pronto)
- [ ] Email 3: Convite exclusivo (escrito)
- [ ] Email 4: Últimas vagas (escrito)
- [ ] Email 5: Fechamento (escrito)
- [ ] Subject lines A/B para cada email

## Pós-Venda
- [ ] Welcome email automático
- [ ] Calendário de sessões definido
- [ ] Framework de coleta de feedback
- [ ] Template para depoimentos
- [ ] Plano de gravação das sessões

## Go/No-Go
- [ ] ✅ 5/5 emails prontos
- [ ] ✅ Página de pagamento testada
- [ ] ✅ Email de boas-vindas configurado
- [ ] ✅ Calendário das sessões definido
→ Se todos ✅: LAUNCH
