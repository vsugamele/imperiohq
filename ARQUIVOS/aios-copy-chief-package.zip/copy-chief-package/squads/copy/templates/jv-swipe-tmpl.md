# Template: JV Swipe Files — Emails para Afiliados

## Email 1: PLC 1 Promo
```
Subject: {personalize} — {product_hook}

Oi {subscriber_name},

{affiliate_name} aqui.

Acabei de assistir algo que preciso compartilhar com você.

{creator_name} está fazendo uma série gratuita sobre {topic} e o primeiro vídeo é {adjective}.

Em {duration}, ele/ela mostra {key_insight}.

Assista aqui: {affiliate_link}

É de graça e vale cada minuto.

{affiliate_name}

P.S. — São 3 vídeos no total. O primeiro já está no ar.
```

## Email 2: PLC 2 Promo
```
Subject: {case_study_hook}

Lembra do vídeo que te mandei sobre {topic}?

O segundo acabou de sair e é ainda melhor.

{creator_name} mostra como {case_study_name} {result} em {timeline}.

Assista: {affiliate_link}

{affiliate_name}
```

## Email 3: Cart Open
```
Subject: Inscrições abertas ({product_name})

{subscriber_name},

Lembra da série sobre {topic}?

{creator_name} acabou de abrir inscrições para {product_name}.

É {product_description_1_line}.

Eu recomendo porque {personal_reason}.

Veja os detalhes: {affiliate_link}

{affiliate_name}

P.S. — {urgency_element}
```

## Email 4: Cart Close
```
Subject: Última chance ({product_name})

{subscriber_name}, rápido:

{product_name} fecha hoje à meia-noite.

Se você quer {transformation}, essa é a hora.

{affiliate_link}

{affiliate_name}
```

## Regras para Afiliados
- Personalizar com sua voz (não copiar literal)
- Incluir motivo pessoal de recomendação
- Respeitar cadência (não bombardear)
- Usar APENAS link de afiliado fornecido
