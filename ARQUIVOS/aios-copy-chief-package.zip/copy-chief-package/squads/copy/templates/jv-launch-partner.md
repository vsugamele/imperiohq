# Template: JV Partner Onboarding — Guia do Afiliado

## Bem-vindo ao Lançamento de {PRODUCT_NAME}

### Informações do Lançamento
- **Produto:** {product_name}
- **Preço:** R${price}
- **Comissão:** {X}% (R${commission_per_sale})
- **Cookie:** {X} dias
- **Cart Open:** {date}
- **Cart Close:** {date}

### Seu Link de Afiliado
```
{affiliate_link}
```

### Materiais Disponíveis
1. **Swipe emails** (4 emails prontos para personalizar)
2. **Banners** (3 tamanhos: 300x250, 728x90, 1080x1080)
3. **Stories templates** (3 designs)
4. **Posts templates** (2 formatos)
5. **Headlines sugeridas** (10 opções)

### Calendário Sugerido
| Data | Ação |
|------|------|
| {D-3} | Teaser (story ou post) |
| {D-1} | Email PLC 1 |
| {D+2} | Email PLC 2 |
| {D+4} | Email PLC 3 |
| {Cart Open} | Email Cart Open |
| {Cart Close -1} | Email urgência |
| {Cart Close} | Email final |

### EPC Histórico
- **EPC médio:** R${X}
- **Conversão média:** {X}%
- **Revenue por lead médio:** R${X}

### Suporte
- Grupo exclusivo de afiliados: {link}
- Contato direto: {email}
- Lives semanais durante lançamento: {schedule}

### Regras
- ✅ Personalizar swipe files com sua voz
- ✅ Usar link de afiliado em toda promoção
- ❌ NÃO fazer claims não autorizados
- ❌ NÃO usar spam ou compra de lista
- ❌ NÃO modificar a oferta ou preço
