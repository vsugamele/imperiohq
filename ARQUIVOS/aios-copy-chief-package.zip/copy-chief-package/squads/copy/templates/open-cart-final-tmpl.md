# Template: Open Cart Final Day Emails

## Email 1: 24h Warning (Dia anterior ao fechamento)

```
Subject A: 24 horas.
Subject B: Amanhã fecha.

{name},

Vou ser direto: as inscrições para {product_name} fecham amanhã, 
{close_date}, à meia-noite.

Depois disso, não sei quando (ou se) vou reabrir.

Se nos últimos dias você pensou "quero isso mas vou esperar"
— esse é o momento de agir.

Porque amanhã à meia-noite, a decisão será tomada POR você.

👉 {CTA_LINK}

{name_creator}

P.S. — Lembre: {guarantee_text}. O risco é zero.
```

## Email 2: Últimas Horas (Manhã do último dia)

```
Subject A: Últimas horas
Subject B: Hoje é o último dia

{name},

Hoje é o último dia para se inscrever em {product_name}.

{X} pessoas já se inscreveram e estão começando {transformation}.

Se você quer {result}:

👉 {CTA_LINK}

O carrinho fecha hoje às 23:59.

{name_creator}
```

## Email 3: Countdown (Tarde do último dia)

```
Subject A: Fechando em {X} horas
Subject B: Última chamada: {product_name}

{name},

Faltam {X} horas.

{product_name} fecha hoje à meia-noite e não quero que você 
se arrependa amanhã.

{quick_testimonial}

Se você está pronto para {transformation}:

👉 {CTA_LINK}

{name_creator}
```

## Email 4: Final Call (23h)

```
Subject A: É agora.
Subject B: 1 hora.

{name},

Último lembrete.

{product_name} fecha em 1 hora.

👉 {CTA_LINK}

{name_creator}
```
