# Template: Open Cart Day 1 Emails

## Email 1: Cart Open (Manhã)

```
Subject A: Está aberto!
Subject B: Inscrições abertas para {product_name}

Oi {name},

É HOJE.

Depois de {X} dias de conteúdo, o momento chegou.

As inscrições para {product_name} estão oficialmente abertas.

Se você assistiu os 3 vídeos, você já sabe:
- {PLC1_key_insight}
- {PLC2_key_insight}  
- {PLC3_key_insight}

Agora é hora de ir além do conhecimento e partir para a AÇÃO.

👉 {CTA_LINK}

Você terá acesso a:
{quick_stack_summary}

E tudo com garantia de {X} dias.

{CTA_LINK}

{name_creator}

P.S. — Quem se inscrever nas primeiras 24h ganha {early_bird_bonus}.
Esse bônus desaparece amanhã à meia-noite.
```

## Email 2: Early Bird (Tarde/Noite)

```
Subject A: Bônus para quem agir agora
Subject B: 24h: {early_bird_bonus}

{name},

Hoje de manhã abri as inscrições para {product_name}.

E a resposta está sendo incrível — {X} pessoas já garantiram suas vagas.

Se você ainda não se inscreveu, quero lembrar:

Quem se inscrever nas primeiras 24 horas ganha {early_bird_bonus}
— que normalmente custa R${bonus_value}.

Esse bônus desaparece amanhã, {date} à meia-noite.

👉 {CTA_LINK}

{name_creator}

P.S. — {quick_testimonial_or_result}
```
