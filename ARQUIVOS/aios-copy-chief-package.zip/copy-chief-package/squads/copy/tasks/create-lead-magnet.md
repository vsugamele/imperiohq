# Task: Create Lead Magnet Copy

## Metadata
- **ID:** create-lead-magnet
- **Agent:** Auto-selected based on type
- **Tier:** 1-2

## Input
```yaml
required:
  - magnet_type: "ebook | checklist | template | mini-course | quiz | swipe-file"
  - avatar_profile: "Perfil do avatar"
  - main_problem: "Problema que o lead magnet resolve"
  - product_bridge: "Como o lead magnet conecta ao produto pago"
```

## Instructions

### Step 1: Define the Quick Win
Lead magnet must deliver a QUICK WIN — um resultado pequeno mas real que:
- Prova que o expert sabe do que fala
- Cria reciprocidade
- Abre o apetite para mais (sem saciar completamente)

### Step 2: Write Landing Page Copy
Short format (300-500 words):
- Headline com benefício específico
- 3-5 bullets (fascinations) do que o prospect vai aprender
- Social proof (número de downloads, testimonial)
- Form: nome + email (mínimo de fricção)

### Step 3: Write Thank You / Delivery Page
- Confirmar entrega
- Set expectation ("verifique seu email em 5 minutos")
- Optional: soft CTA para próximo passo (tripwire, webinar, etc.)

## Output Schema
```yaml
lead_magnet:
  type: "..."
  quick_win: "O resultado que entrega"
  landing_page:
    headline: "..."
    bullets: ["...", "...", "..."]
    cta: "Texto do botão"
  thank_you_page:
    message: "..."
    next_step: "..."
```

## Quality Gate
- [ ] Quick win é REAL e alcançável
- [ ] Landing page tem ≤5 bullets
- [ ] Bridge para produto pago é natural (não forçado)
- [ ] Fricção mínima no form
