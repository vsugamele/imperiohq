# Task: Create Webinar Script

## Metadata
- **ID:** create-webinar-script
- **Agent:** @todd-brown (mechanism) or @jeff-walker (PLF-style)
- **Tier:** 2

## Input
```yaml
required:
  - diagnosis: "Output do @eugene-schwartz"
  - avatar_profile: "Perfil do avatar"
  - product: "O que será oferecido ao final"
  - webinar_length: "45 | 60 | 90 minutos"
optional:
  - mechanism: "Unique mechanism se já definido"
```

## Instructions

### Structure: The Teaching Webinar (Todd Brown E5)

**Part 1: Engage (5 min)**
- Hook (pattern interrupt)
- Promise of the webinar ("Ao final, você vai saber...")
- Quick credibility (30s max)
- Agenda teaser

**Part 2: Educate (20-30 min)**
- Teach 3 content pillars (real value, not fluff)
- Each pillar: concept → example → implication
- Weave in mechanism naturally
- Each pillar creates "aha moment" that points to product

**Part 3: Transition (5 min)**
- "Now here's where it gets interesting..."
- Bridge from education to offer
- Restate the problem + show gap remaining

**Part 4: Offer (10-15 min)**
- Full value stack with perceived values
- Bonuses (3-5)
- Guarantee
- Price reveal with comparison
- Money math (ROI)

**Part 5: Close (5-10 min)**
- Urgency (deadline for webinar attendees)
- FAQ / objection handling
- Final CTA

## Output Schema
```yaml
webinar_script:
  total_duration: "XX min"
  sections:
    engage: "Script completo"
    educate:
      pillar_1: "Conceito + exemplo"
      pillar_2: "Conceito + exemplo"
      pillar_3: "Conceito + exemplo"
    transition: "Script da transição"
    offer: "Script completo da oferta"
    close: "Script do fechamento"
  slides_outline: ["Slide 1: ...", "Slide 2: ..."]
```

## Quality Gate
- [ ] Education section delivers REAL value
- [ ] Transition is natural (not jarring)
- [ ] Offer section is complete (stack + guarantee + CTA)
- [ ] Total within target duration
