# Task: Create Email Sequence

## Metadata
- **ID:** create-email-sequence
- **Agent:** @dan-kennedy (DR) or @gary-halbert (story-driven)
- **Tier:** 1-2

## Input
```yaml
required:
  - sequence_type: "welcome | nurture | soap-opera | launch | cart-close | reengagement"
  - diagnosis: "Output do @eugene-schwartz"
  - avatar_profile: "Perfil do avatar"
  - num_emails: "Quantidade de emails na sequência"
optional:
  - product_info: "Se for sequência de venda"
  - offer_details: "Preço, bônus, deadline"
```

## Instructions

### Step 1: Define Sequence Arc
Map the emotional journey across all emails:
- Email 1: Hook + establish relationship
- Emails 2-N-2: Build value, story, proof
- Email N-1: Present offer (or soft CTA)
- Email N: Close with urgency

### Step 2: Write Each Email
For each email:
1. **Subject Line** — Must be A-pile worthy. Test: would you open this from a friend?
2. **Opening Line** — Visible in preview. Hook immediately.
3. **Body** — ONE main idea per email. Story OR proof OR teaching.
4. **CTA** — ONE action. Max 2 mentions of same link.
5. **P.S.** — Always. Reinforces CTA or adds curiosity for next email.

### Sequence Types

**Welcome Sequence (5-7 emails):**
1. Deliver promised asset + personal intro
2. Origin story (vulnerability + credibility)
3. Biggest lesson learned
4. Common mistake + solution
5. Social proof + soft CTA
6. "The truth about..." (damaging admission)
7. Direct CTA with value recap

**Soap Opera Sequence (5 emails):**
1. Set the stage (character + setting)
2. High drama (conflict + struggle)
3. Epiphany (the discovery)
4. Hidden benefit (unexpected win)
5. Urgency + CTA

**Cart Close (3-5 emails, sent in 24-48h):**
1. "Cart is open" + full pitch
2. Case study + objection handling
3. FAQ + "last chance" warning
4. "Hours remaining" + scarcity
5. "Final email" + consequence of not acting

### Step 3: Audit
Each email: Hopkins Audit (adapted for email format). Focus on Subject Line Power, A-pile test, single CTA clarity.

## Output Schema
```yaml
email_sequence:
  type: "welcome | soap-opera | cart-close | etc"
  emails:
    - number: 1
      subject: "..."
      preview_text: "First line visible"
      body: "Full email"
      cta: "Link/action"
      ps: "..."
      send_timing: "Day X or Trigger"
```

## Quality Gate
- [ ] Subject lines pass A-pile test
- [ ] ONE CTA per email
- [ ] P.S. in every email
- [ ] Emotional arc across sequence
- [ ] No email exceeds 500 words (unless story-driven)
