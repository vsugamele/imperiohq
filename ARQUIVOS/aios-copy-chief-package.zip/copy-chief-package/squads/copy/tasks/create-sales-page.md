# Task: Create Sales Page

## Metadata
- **ID:** create-sales-page
- **Agent:** Auto-selected based on diagnosis
- **Tier:** 1-3 (depends on copywriter)
- **Prereq:** Tier 0 diagnosis completed (Schwartz + Collier)

## Input
```yaml
required:
  - diagnosis: "Output do @eugene-schwartz (awareness + sophistication)"
  - avatar_profile: "Perfil completo do avatar"
  - product_description: "O que está vendendo"
  - offer_details: "Preço, bônus, garantia"
optional:
  - mental_conversation: "Output do @robert-collier"
  - swipe_file: "Frases reais do avatar"
  - competitor_analysis: "Copy de concorrentes"
  - testimonials: "Depoimentos reais"
```

## Instructions

### Step 1: Select Copywriter
Based on Schwartz diagnosis:
- Unaware/Problem Aware → @gary-halbert (story-driven)
- Solution Aware (saturated) → @todd-brown (mechanism-first)
- Product Aware → @gary-bencivenga (proof + fascinations)
- Most Aware → @dan-kennedy (direct offer + urgency)
- Premium market → @david-ogilvy (elegant persuasion)

### Step 2: Write the Lead (MOST CRITICAL)
The lead determines 80% of conversion. Match to awareness level:
- Unaware → Story Lead (Halbert style)
- Problem Aware → Problem-Agitation Lead
- Solution Aware → Solution + Mechanism Lead
- Product Aware → Offer Lead + Proof
- Most Aware → Direct Offer Lead

### Step 3: Build the Body
Follow selected copywriter's structure (see agent file).
Must include:
- [ ] Problem amplification with AVATAR'S words
- [ ] Mechanism reveal (why THIS works)
- [ ] Proof stack (min 3 different types)
- [ ] Future pace (visualize result)

### Step 4: Construct the Offer Section
- [ ] Value stack with perceived value per item
- [ ] Price comparison (value vs price = savings)
- [ ] Money math (ROI calculation)
- [ ] Guarantee (risk reversal)
- [ ] CTA (specific, urgent, one action)

### Step 5: Write P.S. Lines
- P.S. 1: Restate main benefit
- P.S. 2: Reinforce deadline/urgency
- P.S. 3: (optional) Surprise bonus or fear of missing out

### Step 6: Hopkins Audit
Submit to @claude-hopkins for 12-pillar audit. Minimum 85/100.

### Step 7: Sugarman 30 Triggers Check
Run through 30 triggers checklist. Minimum 80% (24/30).

## Output Schema
```yaml
sales_page:
  headline: "..."
  subheadline: "..."
  lead: "Full lead section"
  body: "Full body copy"
  offer: "Complete offer section"
  guarantee: "..."
  cta: "..."
  ps_lines: ["P.S. 1", "P.S. 2"]
  word_count: N
  
audit:
  hopkins_score: "/100"
  sugarman_coverage: "XX%"
  verdict: "APPROVED | REWRITE"
```

## Quality Gate
- [ ] Lead matches awareness level from diagnosis
- [ ] Copywriter selection justified
- [ ] Hopkins ≥85
- [ ] Sugarman ≥80%
- [ ] CTA has one clear action with urgency
