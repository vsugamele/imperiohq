# Task: Create Landing Page

## Metadata
- **ID:** create-landing-page
- **Agent:** Auto-selected based on diagnosis
- **Tier:** 1-2

## Input
```yaml
required:
  - purpose: "lead-capture | webinar-registration | waitlist | tripwire"
  - diagnosis: "Output do @eugene-schwartz"
  - avatar_profile: "Perfil do avatar"
  - main_offer: "O que a pessoa recebe"
```

## Instructions

### Landing Page Principles
1. **ONE goal** — One page, one offer, one CTA
2. **Zero distractions** — No nav menu, no external links
3. **Above the fold** — Headline + benefit + CTA visible without scrolling
4. **Social proof** — Even minimal (number of signups, one testimonial)

### Structure (300-800 words max)
1. **Headline** — Benefit-driven, specific
2. **Subheadline** — Expand or qualify the headline
3. **3-5 Bullet points** — Key benefits/deliverables
4. **Social proof** — Testimonial, number, or logo
5. **CTA** — Button with action-oriented text
6. **(Optional) Urgency** — If applicable

### By Purpose
- **Lead Capture:** Focus on quick win value
- **Webinar Reg:** Focus on what they'll learn + time commitment
- **Waitlist:** Focus on FOMO + anticipation
- **Tripwire:** Focus on irresistible low price + value

## Output Schema
```yaml
landing_page:
  headline: "..."
  subheadline: "..."
  bullets: ["...", "...", "..."]
  social_proof: "..."
  cta_button_text: "..."
  urgency: "if applicable"
  word_count: N
```

## Quality Gate
- [ ] ONE CTA only
- [ ] Above the fold: headline + CTA visible
- [ ] Under 800 words
- [ ] Social proof present
- [ ] Zero distractions (no nav, no external links)
