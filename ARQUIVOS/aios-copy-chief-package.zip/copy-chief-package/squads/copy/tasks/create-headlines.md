# Task: Create Headlines

## Metadata
- **ID:** create-headlines
- **Agent:** @gary-bencivenga (primary) or @eugene-schwartz (for low awareness)
- **Tier:** 1

## Input
```yaml
required:
  - diagnosis: "Output do @eugene-schwartz"
  - context: "sales-page | email-subject | ad | landing | vsl"
  - avatar_profile: "Perfil do avatar"
  - main_benefit: "Benefício principal do produto"
```

## Instructions

### Step 1: Bencivenga's 50 Headlines Method
1. Write 50 headlines without judgment (braindump)
2. Filter: remove any without benefit OR curiosity
3. Specificity pass: add numbers, details to survivors
4. Select top 10
5. Create 3 variations of each top 10
6. Final selection: 5 headlines for testing

### Step 2: Format Check
Ensure headlines match awareness level:
- Unaware → Indirect (story, curiosity, question)
- Problem Aware → Pain-based ("If you suffer from...")
- Solution Aware → Mechanism-based ("The new method that...")
- Product Aware → Proof-based ("47,823 people already...")
- Most Aware → Offer-based ("50% off today only")

## Output Schema
```yaml
headlines:
  braindump_count: 50
  filtered_count: N
  top_10:
    - headline: "..."
      type: "how-to | number | question | warning | testimonial"
      variations:
        - "Variation A"
        - "Variation B"
        - "Variation C"
  final_5_for_testing:
    - "Headline 1"
    - "Headline 2"
    - "Headline 3"
    - "Headline 4"
    - "Headline 5"
```

## Quality Gate
- [ ] 50+ headlines generated before selection
- [ ] Each headline has benefit OR curiosity
- [ ] Specificity present (numbers, not vague)
- [ ] Headlines match diagnosis awareness level
