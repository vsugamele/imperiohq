# Task: Sugarman 30 Triggers Check — Validação Psicológica

## Metadata
- **Agent:** Copy Chief (Tool, não copywriter)
- **Tier:** Quality Control (pós-execução)
- **Trigger:** Após Hopkins Audit ≥ 85/100
- **Mínimo para aprovação:** 80% cobertura (24/30 triggers)
- **Referência:** `squads/copy/data/sugarman-30-triggers.md`

## Input
```yaml
required:
  - copy_text: "O copy aprovado pelo Hopkins Audit"
  - copy_type: "sales-page | email | ad | vsl | headline | upsell | landing"
  - hopkins_score: "Score da auditoria Hopkins"
```

## Instruções

### Step 1 — Carregar Referência
Ler `squads/copy/data/sugarman-30-triggers.md` para os 30 triggers completos.

### Step 2 — Scan do Copy
Para CADA um dos 30 triggers, marcar:
- ✅ **PRESENTE** — O trigger está ativo no copy (citar trecho)
- ⚠️ **PARCIAL** — Presente mas fraco (explicar por quê)
- ❌ **AUSENTE** — Não encontrado

### Step 3 — Análise de Cobertura

**Os 30 Triggers:**

| # | Trigger | Status | Trecho/Nota |
|---|---------|--------|-------------|
| 1 | Feeling of Involvement/Ownership | | |
| 2 | Honesty | | |
| 3 | Integrity | | |
| 4 | Credibility | | |
| 5 | Value & Proof of Value | | |
| 6 | Justify the Purchase | | |
| 7 | Greed | | |
| 8 | Establish Authority | | |
| 9 | Satisfaction Conviction | | |
| 10 | Nature of Product | | |
| 11 | Current Fads | | |
| 12 | Timing | | |
| 13 | Desire to Belong | | |
| 14 | Desire to Collect | | |
| 15 | Curiosity | | |
| 16 | Sense of Urgency | | |
| 17 | Fear | | |
| 18 | Instant Gratification | | |
| 19 | Exclusivity/Scarcity | | |
| 20 | Simplicity | | |
| 21 | Human Relationships | | |
| 22 | Storytelling | | |
| 23 | Mental Engagement | | |
| 24 | Guilt | | |
| 25 | Specificity | | |
| 26 | Familiarity | | |
| 27 | Hope | | |
| 28 | Pattern Interrupt | | |
| 29 | Linking | | |
| 30 | Consistency | | |

### Step 4 — Score de Cobertura

```
Total ✅: X
Total ⚠️: Y (conta como 0.5)
Total ❌: Z

Cobertura = (X + Y*0.5) / 30 * 100 = __%
```

**Classificação:**
- 90-100%: EXCEPCIONAL — Copy altamente persuasivo
- 80-89%: BOM — Aprovado, minor improvements
- 70-79%: MÉDIO — Requer adição de triggers críticos
- <70%: INSUFICIENTE — Copy precisa de mais camadas persuasivas

### Step 5 — Recomendações de Melhoria

Para cada trigger ❌ AUSENTE que deveria estar presente:
1. Onde inserir no copy
2. Exemplo de como ativar o trigger
3. Qual copywriter do squad melhor integra esse trigger

**Triggers OBRIGATÓRIOS (se ausente = flag):**
- #5 Value & Proof of Value
- #15 Curiosity
- #16 Sense of Urgency
- #22 Storytelling
- #25 Specificity

## Output Schema
```yaml
sugarman_check:
  total_present: 0-30
  total_partial: 0-30
  total_absent: 0-30
  coverage_percent: 0-100
  classification: "EXCEPCIONAL | BOM | MÉDIO | INSUFICIENTE"
  approved: true/false
  missing_critical:
    - trigger: "Nome"
      suggestion: "Como integrar"
      insert_at: "Onde no copy"
  top_3_improvements:
    - trigger: "Nome"
      impact: "alto | médio"
      implementation: "Como implementar"
```

## Quality Gate
- [ ] Todos 30 triggers avaliados individualmente
- [ ] Trechos citados para cada ✅
- [ ] Justificativa para cada ❌
- [ ] Score calculado corretamente
- [ ] 5 triggers obrigatórios verificados com flag se ausentes
- [ ] Recomendações específicas para triggers ausentes
