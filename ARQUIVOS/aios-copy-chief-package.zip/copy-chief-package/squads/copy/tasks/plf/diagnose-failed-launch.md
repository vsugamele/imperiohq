# Task: Diagnose Failed Launch — Autópsia de Lançamento

## Metadata
- **Agent:** @jeff-walker
- **PLF Phase:** Pós-lançamento (resultado abaixo do esperado)
- **depends_on:** Dados do lançamento que falhou

## Input
```yaml
required:
  - launch_data:
      emails_sent: X
      open_rates: []
      click_rates: []
      plc_views: [plc1, plc2, plc3]
      cart_visits: X
      conversions: X
      revenue: X
  - expected_vs_actual:
      expected_revenue: X
      actual_revenue: X
      expected_conversions: X
      actual_conversions: X
```

## Instruções

### Step 1 — Diagnóstico por Funil

Analisar cada estágio para encontrar onde quebrou:

**Estágio 1: Lista → PLC 1 Views**
- Open rate dos emails de delivery < 25%? → Problema de LISTA
- PLC 1 view rate < 30% de quem abriu? → Problema de HOOK/SUBJECT

**Estágio 2: PLC 1 → PLC 2 → PLC 3 (Retenção)**
- Drop > 50% entre PLCs? → Problema de CONTEÚDO
- Drop > 70% entre PLC 1 e PLC 3? → Problema de RELEVÂNCIA

**Estágio 3: PLC 3 → Cart Page (Intenção)**
- < 20% de quem viu PLC 3 visitou cart? → Problema de OFERTA/CTA
- Cart visit ok mas conversão baixa? → Problema de PÁGINA

**Estágio 4: Cart Page → Compra (Conversão)**
- Cart abandonment > 80%? → Problema de PREÇO/OBJEÇÕES
- Checkout drop > 50%? → Problema TÉCNICO ou PAGAMENTO

### Step 2 — Análise por Dimensão

| Dimensão | Indicador | Diagnóstico |
|----------|-----------|-------------|
| Lista | Open rate, size, engagement | Qualidade vs quantidade |
| Copy | Click rate, scroll depth | Hook, promessa, relevância |
| Conteúdo | PLC retention, comments | Valor entregue, teaching |
| Oferta | Cart visits, conversion | Preço, value stack, garantia |
| Urgência | Last day spike | Deadline, escassez |
| Técnico | Checkout drop, errors | Página, pagamento, mobile |

### Step 3 — Prescrição

Para cada problema identificado:
1. **Diagnóstico** — O que está errado
2. **Causa raiz** — Por que está errado
3. **Prescrição** — O que mudar no próximo lançamento
4. **Prioridade** — CRITICAL / HIGH / MEDIUM / LOW

### Step 4 — Relaunch Plan
Baseado no diagnóstico, criar plano de relançamento:
- O que manter (o que funcionou)
- O que mudar (fixes prioritários)
- O que testar (hipóteses)
- Timeline para próximo lançamento

## Output Schema
```yaml
launch_diagnosis:
  summary: "O lançamento falhou em [estágio] por [razão]"
  funnel_analysis:
    stage: "list | plc_retention | cart_intent | conversion"
    bottleneck: ""
    data: {}
  dimension_analysis:
    - dimension: ""
      indicator: ""
      status: "ok | warning | critical"
      diagnosis: ""
  prescriptions:
    - priority: "CRITICAL | HIGH | MEDIUM | LOW"
      problem: ""
      root_cause: ""
      fix: ""
  relaunch_plan:
    keep: []
    change: []
    test: []
    timeline: ""
```

## Quality Gate
- [ ] Análise de CADA estágio do funil com dados
- [ ] Causa raiz identificada (não sintoma)
- [ ] Prescrições priorizadas (CRITICAL primeiro)
- [ ] Plano de relançamento com timeline
- [ ] Mantém o que funcionou (não joga tudo fora)
