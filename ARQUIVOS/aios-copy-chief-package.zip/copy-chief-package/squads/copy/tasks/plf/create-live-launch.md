# Task: Live Launch — Lançamento ao Vivo

## Metadata
- **Agent:** @jeff-walker
- **PLF Phase:** Advanced
- **depends_on:** `create-plc-sequence.md`
- **Template:** `live-launch-readiness.md`

## Input
```yaml
required:
  - plc_sequence: "PLCs prontos"
  - launch_date: "Data de abertura do carrinho"
  - offer_details: "Produto, preço, garantia, bônus"
  - webinar_platform: "Zoom | YouTube Live | StreamYard"
```

## Instruções

### O Live Launch Advantage
PLCs ao vivo geram 2-5x mais engajamento que gravados porque:
- Interação real-time (chat, Q&A)
- Urgência natural (assista agora ou perca)
- Energy transfer (emoção ao vivo é contagiosa)
- Social proof instantâneo (chat ativo)

### Step 1 — Pre-Live Warmup (3 dias antes de cada PLC)
- Email D-3: "Marque na agenda: [data] às [hora]"
- Email D-1: "Amanhã ao vivo: [teaser do conteúdo]"
- Email D-0 AM: "Hoje às [hora] — esteja lá"
- Email D-0 -30min: "Começando em 30 minutos!"

### Step 2 — Estrutura do Live PLC
Cada PLC ao vivo segue:
1. **Pre-show (10min):** Música, chat aquecendo, countdown
2. **Welcome (5min):** Saudação, definir expectativas, "fiquem até o final"
3. **Content (20-40min):** PLC conforme script
4. **Q&A (15-20min):** Responder perguntas ao vivo
5. **Close (5min):** Teaser próximo PLC, CTA de engajamento
6. **Post-live:** Email replay + highlights

### Step 3 — Chat Management
- Moderador designado para:
  - Destacar perguntas relevantes
  - Remover spam
  - Postar links nos momentos certos
  - Criar "momentos" de engagement
- Plantar perguntas estratégicas se necessário

### Step 4 — Replay Strategy
- Email de replay 2h após o live
- "Replay disponível por 48h"
- Incluir timestamps dos momentos-chave
- CTA adicional no replay

### Step 5 — Open Cart Live Event
No dia de abertura:
- Live event especial (30-60min)
- Recap dos 3 PLCs (5min)
- Q&A final
- "O carrinho está ABERTO" — live celebration
- Mostrar primeiros compradores em tempo real

## Output Schema
```yaml
live_launch:
  pre_live_emails:
    per_plc: [{timing: "D-3", subject: "", body: ""}]
  live_structure:
    pre_show: {duration: "10min", elements: []}
    welcome: {script: ""}
    content: "→ referência ao PLC script"
    qa: {duration: "15-20min", planted_questions: []}
    close: {script: ""}
  chat_management:
    moderator_instructions: ""
    strategic_moments: []
  replay:
    email_timing: "2h post"
    availability: "48h"
    timestamps: []
  open_cart_event:
    duration: "30-60min"
    structure: []
```

## Quality Gate
- [ ] 4 emails de warmup por PLC live
- [ ] Estrutura de cada live com timing
- [ ] Chat management plan com moderador
- [ ] Replay strategy com email + timestamps
- [ ] Open cart event planejado
- [ ] Planted questions preparadas para Q&A
