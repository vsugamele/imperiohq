# Task: JV Launch — Lançamento com Parceiros (Joint Venture)

## Metadata
- **Agent:** @jeff-walker
- **PLF Phase:** Advanced
- **depends_on:** Pelo menos 1 lançamento próprio completo
- **Templates:** `jv-swipe-tmpl.md`, `jv-launch-partner.md`

## Input
```yaml
required:
  - product_details: "Produto validado com resultados"
  - previous_launch_data: "Métricas do lançamento anterior"
  - commission_structure: "% de comissão, cookie period"
  - launch_calendar: "Datas planejadas"
optional:
  - dream_100_list: "Lista de parceiros ideais"
  - affiliate_assets: "Materiais prontos para afiliados"
```

## Instruções

### Step 1 — Dream 100 (Parceiros Ideais)
Identificar 100 parceiros potenciais em 4 tiers:
- **Tier A (10):** Influenciadores com lista >50k no seu nicho
- **Tier B (20):** Influenciadores com lista 10-50k alinhados
- **Tier C (30):** Micro-influenciadores com lista 1-10k engajada
- **Tier D (40):** Peers e contatos diretos com audiência alinhada

### Step 2 — JV Recruitment Sequence

**Email 1: "The Introduction" (D-60)**
- Apresentação pessoal + resultados do produto
- Números do lançamento anterior (conversão, receita)
- "Gostaria de te convidar para [lançamento]"
- NÃO pedir nada ainda — plantar semente

**Email 2: "The Proof" (D-45)**
- Case studies de alunos/clientes
- EPCs (Earnings Per Click) de lançamentos anteriores
- Comparação com média do mercado
- "Nossos afiliados ganharam em média R$X por lead"

**Email 3: "The Invitation" (D-30)**
- Link para página de afiliado
- Comissão, cookie, regras claras
- Swipe files prontos para usar
- Calendário do lançamento

**Email 4: "The Support" (D-15)**
- Preview dos PLCs
- Materiais de promoção (banners, emails, stories)
- Grupo exclusivo de afiliados
- Contato direto para suporte

### Step 3 — Swipe Files para Parceiros
Criar para cada parceiro:
- 5 emails prontos (copy+paste) para cada fase
- 3 stories templates
- 2 posts templates
- Headlines e ângulos sugeridos
- UTM links personalizados

### Step 4 — Leaderboard e Incentivos
- Leaderboard público de afiliados
- Bônus para top 3 (extra commission, mentoria, etc.)
- Prizes por milestone (10 vendas, 25 vendas, etc.)
- Live semanal com afiliados durante lançamento

## Output Schema
```yaml
jv_launch:
  dream_100:
    tier_a: [{name: "", list_size: X, contact: ""}]
    tier_b: []
    tier_c: []
    tier_d: []
  recruitment_emails:
    - email: 1-4
      subject: ""
      body: ""
      timing: "D-XX"
  swipe_files:
    emails: [{phase: "", subject: "", body: ""}]
    social: [{platform: "", template: ""}]
  commission:
    percentage: "X%"
    cookie_days: X
    payment_schedule: ""
  leaderboard:
    prizes: [{rank: "top 3", prize: ""}]
    milestones: [{sales: X, bonus: ""}]
  affiliate_page_url: ""
```

## Quality Gate
- [ ] Dream 100 segmentado em 4 tiers
- [ ] EPCs e métricas de lançamento anterior incluídos
- [ ] Swipe files prontos para copy+paste
- [ ] Comissão competitiva (mínimo 30% digital)
- [ ] Calendário de recruitment inicia D-60
- [ ] Suporte ativo para afiliados durante lançamento
