# Task: Launch Emails — Sequência de Emails do Lançamento

## Metadata
- **Agent:** @jeff-walker
- **PLF Phase:** 1-2 — Pre-Launch + Launch
- **depends_on:** `create-plc-sequence.md`
- **Template:** `email-subject-lines-tmpl.md`

## Input
```yaml
required:
  - plc_sequence: "Output dos PLCs"
  - launch_calendar: "Datas do lançamento"
  - avatar_profile: "Perfil do avatar"
  - offer_details: "Produto, preço, garantia"
```

## Instruções

### Mapa Completo de Emails

**Fase 1 — Pre-Launch (suporte aos PLCs)**

| Dia | Email | Função | Subject Line Approach |
|-----|-------|--------|----------------------|
| D1 | PLC 1 Delivery | Entregar vídeo/conteúdo | Direto: "Aqui está [promessa]" |
| D2 | PLC 1 Reminder | Quem não abriu/assistiu | Curiosidade + urgência |
| D2 | PLC 1 Social Proof | Compartilhar resultados | "Olha o que [nome] disse..." |
| D3 | PLC 2 Delivery | Entregar vídeo/conteúdo | "O próximo passo: [teaser]" |
| D4 | PLC 2 Reminder | Quem não assistiu | Re-engajamento |
| D5 | PLC 3 Delivery | Entregar vídeo/conteúdo | "O sistema completo" |
| D6 | Bridge Email | "Amanhã abre" | Antecipação máxima |

**Fase 2 — Open Cart (5-7 dias)**

| Dia | Email | Função | Trigger Mental |
|-----|-------|--------|----------------|
| D7 AM | Cart Open | "Está aberto!" | Antecipação liberada |
| D7 PM | Early Bird | Bônus para primeiros | Urgência + recompensa |
| D8 | Case Study | Resultado detalhado | Prova social |
| D9 | FAQ | Responder objeções | Lógica + confiança |
| D10 | Objection Crusher | Endereçar "não é pra mim" | Empatia + reframe |
| D11 | Last Chance Bonus | "Bônus X expira hoje" | Escassez real |
| D12 | 24h Warning | "Fecha amanhã" | Urgência final |
| D13 AM | Final Day | "Últimas horas" | FOMO |
| D13 PM | Cart Close | "Fechando em X horas" | Deadline |
| D13 11PM | Final Call | "Última chance" | Arrependimento futuro |

### Step 1 — Escrever Cada Email
Para cada email, incluir:
- Subject line (testar 2 variantes A/B)
- Preview text
- Body (seguir estrutura abaixo)
- CTA (1 único, claro)
- P.S. (opcional mas recomendado)

### Step 2 — Estrutura de Email PLF

**Formato geral:**
```
Subject: [Subject line]
Preview: [Preview text]

[Abertura pessoal — 1-2 linhas]

[Corpo — 3-8 parágrafos curtos]

[CTA — link claro]

[P.S. — reforço de urgência/valor]
```

**Regras de email PLF:**
- Parágrafos de 1-3 linhas (mobile-first)
- Tom conversacional (não corporativo)
- 1 CTA por email (máximo 2 links pro mesmo destino)
- Subject line < 50 caracteres
- NUNCA subject line em CAPS LOCK

### Step 3 — Subject Lines por Tipo

**Delivery:** direto + benefício
**Reminder:** curiosidade + urgência suave
**Social Proof:** nome + resultado
**Cart Open:** celebração + ação
**Urgência:** deadline + consequência

## Output Schema
```yaml
launch_emails:
  pre_launch:
    - day: 1
      email_name: "PLC 1 Delivery"
      subject_a: ""
      subject_b: ""
      preview_text: ""
      body: ""
      cta: ""
      ps: ""
    # ... todos emails pre-launch
  open_cart:
    - day: 7
      email_name: "Cart Open"
      subject_a: ""
      subject_b: ""
      body: ""
      cta: ""
      ps: ""
    # ... todos emails open cart
  total_emails: X
  calendar: [{day: X, time: "AM/PM", email: "nome"}]
```

## Quality Gate
- [ ] Mínimo 7 emails pre-launch + 8 emails open cart
- [ ] Cada email tem 2 subject lines (A/B test)
- [ ] Tom conversacional e pessoal
- [ ] 1 CTA por email (claro e específico)
- [ ] Urgência real com deadlines verdadeiros
- [ ] Social proof integrado na sequência
- [ ] Emails de reminder para quem não abriu
- [ ] Cadência respeita saturação (máximo 2/dia na última semana)
