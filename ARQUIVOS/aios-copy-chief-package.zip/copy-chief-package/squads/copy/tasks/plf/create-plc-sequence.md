# Task: PLC Sequence — Pre-Launch Content (O Coração do PLF)

## Metadata
- **Agent:** @jeff-walker
- **PLF Phase:** 1 — Pre-Launch
- **depends_on:** `create-preprelaunch.md`
- **Templates:** `plc1-script-tmpl.md`, `plc2-script-tmpl.md`, `plc3-script-tmpl.md`

## Input
```yaml
required:
  - pre_prelaunch_data: "Output do pre-prelaunch"
  - product_details: "O que será vendido, preço, formato"
  - unique_mechanism: "Mecanismo único (do HackerVerso Step 05)"
  - avatar_profile: "Perfil completo do avatar"
  - mirror_words: "Frases coletadas na pesquisa"
optional:
  - competitor_flaws: "Falhas da concorrência (HackerVerso Step 04)"
  - objections_map: "Mapa de objeções conhecidas"
```

## Instruções

### O Framework PLC
Jeff Walker usa 3 PLCs (Pre-Launch Content) que EDUCAM e simultaneamente VENDEM. Cada PLC tem uma função estratégica precisa:

**PLC 1 = "The Opportunity"** — Porquê
**PLC 2 = "The Transformation"** — O quê
**PLC 3 = "The Experience"** — Como

### Step 1 — PLC 1: A Oportunidade ("Why")

**Duração:** 15-25 minutos (vídeo) ou equivalente em texto
**Template:** `plc1-script-tmpl.md`

**Estrutura do PLC 1:**

1. **Hook (30s):** Promessa grande + pattern interrupt
   - "Nos próximos X minutos, vou te mostrar [resultado específico]..."
   - Usar mirror words coletados no pre-prelaunch

2. **Story of Opportunity (3-5min):**
   - A oportunidade que existe no mercado AGORA
   - Por que a maioria não vê essa oportunidade
   - O que mudou para tornar isso possível
   - Posicionar como "window of opportunity"

3. **Teach (5-10min):**
   - Entregar valor real (não teaser vazio)
   - 1 framework actionable que gera resultado parcial
   - "Se você só fizer ISSO, já terá resultado X"
   - Demonstrar expertise sem entregar tudo

4. **Reframe (2-3min):**
   - Destruir a crença limitante principal
   - "O que te ensinaram sobre [X] está errado porque..."
   - Introduzir nova perspectiva (sem revelar mecanismo completo)

5. **CTA PLC 1 (1min):**
   - NÃO vender — pedir para assistir PLC 2
   - "No próximo vídeo, vou revelar [teaser do PLC 2]..."
   - Pedir comentário/engajamento
   - Gerar reciprocidade

**Mental Triggers ativados no PLC 1:**
- Autoridade (expertise demonstrada)
- Reciprocidade (valor gratuito real)
- Curiosidade (loop aberto para PLC 2)
- Prova social (se possível, mostrar resultados)

### Step 2 — PLC 2: A Transformação ("What")

**Duração:** 20-30 minutos
**Template:** `plc2-script-tmpl.md`

**Estrutura do PLC 2:**

1. **Recap + Social Proof (2min):**
   - "No PLC 1, mostrei [recap]..."
   - Ler comentários/resultados do PLC 1
   - Mostrar que pessoas estão engajadas

2. **The Transformation (5-7min):**
   - Case study detalhado (resultado real)
   - Before → After com números específicos
   - "Como [pessoa] saiu de [dor] para [resultado] em [tempo]"

3. **Deeper Teaching (8-12min):**
   - Framework 2 — mais profundo que PLC 1
   - Conectar com o mecanismo único
   - "A razão pela qual isso funciona é [mecanismo]..."
   - Começar a revelar o sistema (sem entregar o product)

4. **Objection Handling (3-5min):**
   - Endereçar 2-3 objeções principais
   - Usar format: "Talvez você esteja pensando [objeção]..."
   - Responder com lógica + emoção + prova

5. **CTA PLC 2 (2min):**
   - Teaser do PLC 3 — "No próximo, vou mostrar [X]"
   - Urgência temporal: "Lançamento em X dias"
   - Aumentar expectativa

**Mental Triggers ativados no PLC 2:**
- Prova social (case studies)
- Autoridade (conhecimento profundo)
- Reciprocidade (mais valor)
- Antecipação (quando posso comprar?)
- Comunidade (outros estão engajados)

### Step 3 — PLC 3: A Experiência ("How")

**Duração:** 25-40 minutos
**Template:** `plc3-script-tmpl.md`

**Estrutura do PLC 3:**

1. **Community Highlight (3min):**
   - Mostrar comentários, resultados parciais
   - "Vejam o que [nome] conseguiu só com os PLCs..."
   - Criar sensação de "movimento"

2. **The Full Picture (8-12min):**
   - Revelar o sistema completo (high-level)
   - Mostrar o roadmap da transformação
   - "São X passos: [1], [2], [3]..."
   - Tornar tangível o intangível

3. **Ownership Experience (5-8min):**
   - "Imagine que é [data futura]. Você já [resultado]..."
   - Future pacing detalhado e emocional
   - Fazer o prospect se ver como owner

4. **Stack Reveal (5-10min):**
   - Revelar o que está incluído no produto
   - Value stack (não preço ainda)
   - Cada item com valor percebido
   - "Bônus 1: [nome] — Sozinho vale R$X..."

5. **Soft Pitch (3-5min):**
   - "Se você está pronto para [transformação]..."
   - Mencionar que vagas são limitadas (se verdade)
   - "Amanhã às [hora], o carrinho abre"
   - NÃO revelar preço (ou revelar no fim do PLC 3 — decision baseada no avatar)

6. **CTA PLC 3 (2min):**
   - "Fique atento ao seu email amanhã"
   - Criar urgência real (limitação de vagas, bônus early-bird)
   - Instruções claras do que fazer quando abrir

**Mental Triggers ativados no PLC 3:**
- Antecipação (está quase na hora)
- Escassez (vagas limitadas)
- Ownership (future pacing)
- Comunidade (todos estão se preparando)
- Comprometimento (investiu 3 PLCs, quer completar)

### Step 4 — Timing e Cadência

```
Dia 0:  Pre-prelaunch email final
Dia 1:  PLC 1 live + email de entrega
Dia 2:  Email reminder PLC 1
Dia 3:  PLC 2 live + email de entrega
Dia 4:  Email reminder PLC 2 + social proof
Dia 5:  PLC 3 live + email de entrega
Dia 6:  Email "amanhã abre" (bridge)
Dia 7:  OPEN CART ────→ create-open-cart-sequence.md
```

**Variação para lançamentos mais longos:**
```
Dia 1 → PLC 1
Dia 4 → PLC 2
Dia 7 → PLC 3
Dia 9 → Open Cart
```

## Output Schema
```yaml
plc_sequence:
  plc1:
    title: ""
    duration: "XX min"
    hook: ""
    teaching_framework: ""
    reframe: ""
    cta: ""
    mental_triggers: []
    script: "Full script text"
  plc2:
    title: ""
    duration: "XX min"
    case_study: {before: "", after: "", timeline: ""}
    teaching_framework: ""
    objections_handled: []
    cta: ""
    mental_triggers: []
    script: "Full script text"
  plc3:
    title: ""
    duration: "XX min"
    community_proof: []
    system_reveal: {steps: []}
    value_stack: [{item: "", perceived_value: ""}]
    soft_pitch: ""
    cta: ""
    mental_triggers: []
    script: "Full script text"
  cadence:
    format: "standard_7_days | extended_10_days"
    schedule: [{day: X, action: ""}]
  next_step: "create-open-cart-sequence"
```

## Quality Gate
- [ ] PLC 1 ensina algo REAL (não teaser vazio)
- [ ] PLC 2 tem case study com números específicos
- [ ] PLC 3 faz future pacing emocional
- [ ] Cada PLC ativa mínimo 3 mental triggers diferentes
- [ ] Loop aberto entre PLCs (curiosidade para o próximo)
- [ ] Mirror words do pre-prelaunch usados nos scripts
- [ ] Cadência definida com emails de suporte
- [ ] Value stack revelado no PLC 3 antes do preço
- [ ] NÃO vende nos PLCs 1-2 (educação pura)
- [ ] Handoff claro para open-cart sequence
