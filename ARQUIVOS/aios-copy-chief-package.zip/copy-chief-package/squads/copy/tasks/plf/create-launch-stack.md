# Task: Launch Stack — Oferta Empilhada

## Metadata
- **Agent:** @jeff-walker
- **PLF Phase:** 2 — Launch
- **depends_on:** Offer + Value Ladder definidos
- **Template:** `launch-stack-tmpl.md`

## Input
```yaml
required:
  - core_product: "Produto principal"
  - price: "Preço do produto"
  - avatar_profile: "Perfil do avatar"
  - unique_mechanism: "Mecanismo único"
```

## Instruções

### O Conceito de Stack
O Launch Stack é a apresentação VISUAL e LÓGICA de tudo que o prospect recebe. Jeff Walker diz: "O stack é onde você constrói o valor percebido que torna o preço ridículo."

### Step 1 — Mapear Componentes
Listar TUDO que está incluído:
1. **Core Product** — O que é, resultado que entrega
2. **Módulos/Pilares** — Cada parte com benefício específico
3. **Bônus 1** — Complementar e valioso
4. **Bônus 2** — Resolve objeção específica
5. **Bônus 3** — Accelerator (resultado mais rápido)
6. **Garantia** — Reduz risco a zero
7. **Suporte** — Comunidade, Q&A, acesso

### Step 2 — Calcular Valor Percebido
Para cada componente:
- Qual seria o preço se vendesse separado?
- Qual valor o resultado dele representa?
- Usar âncoras de preço reais (cursos similares, consultorias)

### Step 3 — Apresentação do Stack (Script)
```
"Vamos recapitular tudo que você recebe:

[Módulo 1]: [benefício] — Valor: R$X
[Módulo 2]: [benefício] — Valor: R$X
...
[Bônus 1]: [benefício] — Valor: R$X
[Bônus 2]: [benefício] — Valor: R$X
[Bônus 3]: [benefício] — Valor: R$X

Valor total: R$XX.XXX

Mas hoje, seu investimento é apenas R$X.XXX

E com a garantia de [X dias], o risco é ZERO."
```

### Step 4 — Stack Visual
Criar slide/imagem com:
- Cada item empilhado visualmente
- Valor de cada item ao lado
- Linha de total
- Preço real com "risco" (preço x valor = desconto percebido)
- Garantia no final (arco de proteção)

## Output Schema
```yaml
launch_stack:
  components:
    - name: ""
      type: "core | module | bonus | guarantee | support"
      benefit: ""
      perceived_value: ""
      anchor_justification: ""
  total_perceived_value: ""
  actual_price: ""
  discount_percentage: ""
  stack_script: "Texto completo"
  presentation_order: ["lista na ordem de apresentação"]
```

## Quality Gate
- [ ] Cada componente tem valor percebido justificado
- [ ] Valor total > 10x preço real
- [ ] Bônus complementam (não são filler aleatório)
- [ ] Garantia presente no final do stack
- [ ] Script de apresentação pronto para PLC 3
- [ ] Stack visual (slide) descrito/criado
