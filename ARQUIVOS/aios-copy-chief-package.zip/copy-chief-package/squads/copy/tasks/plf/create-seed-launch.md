# Task: Seed Launch — Lançamento Semente (Validação)

## Metadata
- **Agent:** @jeff-walker
- **PLF Phase:** Special — Primeiro Lançamento
- **depends_on:** Diagnosis (Tier 0)
- **Template:** `seed-launch-checklist.md`

## Input
```yaml
required:
  - product_concept: "Ideia do produto (não precisa estar pronto)"
  - audience_size: "Qualquer tamanho (até 100 pessoas funciona)"
  - avatar_profile: "Perfil básico do avatar"
```

## Conceito
O Seed Launch é o PRIMEIRO lançamento de Jeff Walker. Feito para quem:
- Não tem produto pronto
- Tem lista pequena (50-500 pessoas)
- Quer validar antes de investir em produção
- Precisa de capital inicial

**Filosofia:** "Venda primeiro, crie depois. Use o feedback dos primeiros clientes para criar o produto perfeito."

## Instruções

### Step 1 — Definir a Oferta Semente
- Produto será criado AO VIVO com os primeiros compradores
- Preço com desconto de 50-70% vs preço futuro
- Formato: live sessions semanais (4-8 semanas)
- Bônus: acesso ao criador, influência no conteúdo

### Step 2 — Sequência Simplificada (5 emails)

**Email 1: "Preciso da sua ajuda"**
- Tom: humilde, genuíno
- "Estou criando algo sobre [tema] e quero sua opinião"
- Link para pesquisa rápida (3 perguntas)

**Email 2: "O que vocês me disseram"**
- Compartilhar insights da pesquisa
- "Baseado nas respostas, decidi criar [produto]"
- Teaser do que será

**Email 3: "Convite exclusivo (founding members)"**
- Oferta para primeiros X compradores
- Preço semente (desconto significativo)
- "Você vai CONSTRUIR isso comigo"
- Vagas REALMENTE limitadas (10-50)

**Email 4: "Últimas vagas"**
- Social proof dos primeiros compradores
- "X pessoas já garantiram..."
- Urgência real (vagas fecham em 48h)

**Email 5: "Fechando"**
- Último lembrete
- "Se você queria [resultado], essa é sua chance"
- Deadline final

### Step 3 — Execução Pós-Venda
- Semana 1: Kickoff + feedback framework
- Semanas 2-7: Conteúdo ao vivo + iteração
- Semana 8: Conclusão + depoimentos
- Resultado: Produto validado + social proof + capital

### Step 4 — Coleta para Próximo Lançamento
- Gravar todas as sessões (futuro produto gravado)
- Coletar depoimentos (social proof)
- Documentar transformações (case studies)
- Refinar baseado em feedback (produto melhor)

## Output Schema
```yaml
seed_launch:
  offer:
    product_name: ""
    format: "live sessions"
    duration: "X semanas"
    seed_price: ""
    future_price: ""
    max_spots: X
  email_sequence:
    - email: 1-5
      subject: ""
      body: ""
  post_sale_plan:
    weekly_schedule: []
    feedback_collection: ""
    testimonial_strategy: ""
  next_launch_assets:
    recordings: true
    testimonials: true
    case_studies: true
    refined_product: true
```

## Quality Gate
- [ ] Preço semente é 50-70% menor que futuro
- [ ] Vagas realmente limitadas (10-50)
- [ ] Tom é humilde e genuíno (não hard sell)
- [ ] Plano de coleta de feedback e depoimentos
- [ ] Plano de gravação para produto futuro
- [ ] 5 emails na sequência
