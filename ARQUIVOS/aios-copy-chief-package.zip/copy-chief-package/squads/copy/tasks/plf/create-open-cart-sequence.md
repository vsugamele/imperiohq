# Task: Open Cart Sequence — Carrinho Aberto

## Metadata
- **Agent:** @jeff-walker
- **PLF Phase:** 2 — Launch
- **depends_on:** `create-plc-sequence.md`, `create-launch-stack.md`
- **Templates:** `open-cart-day1-tmpl.md`, `open-cart-final-tmpl.md`

## Input
```yaml
required:
  - plc_data: "Output dos 3 PLCs"
  - launch_stack: "Stack completo"
  - offer_details: "Preço, garantia, opções de pagamento"
  - cart_duration: "5 | 7 | 10 dias"
  - deadlines: "Bônus expiram, vagas limitadas"
```

## Instruções

### Step 1 — Cart Open Day (D1)

**Email 1 AM: "O Carrinho Está Aberto"**
- Subject: direto e celebratório
- Recap rápido dos PLCs (3 linhas)
- Link para página de vendas
- CTA: "Garanta sua vaga agora"

**Email 2 PM: "Early Bird Bonus"**
- Para quem comprar nas primeiras 24h
- Bônus exclusivo de ação rápida
- Deadline: "Esse bônus desaparece à meia-noite"

### Step 2 — Middle Days (D2-D5)

**D2: Case Study Email**
- História de transformação completa
- Before → After com detalhes específicos
- "Se [nome] conseguiu, você também pode"

**D3: FAQ / Objection Handler**
- Top 5 perguntas da audiência
- Formato: pergunta + resposta direta
- Incluir objeções disfarçadas

**D4: "Por Que NÃO Comprar"**
- Reverse psychology suave
- "Esse programa NÃO é para você se..."
- Qualificar o comprador (aumenta perceived value)
- Para quem É, reforçar fit

**D5: Bônus Expirando**
- "O bônus [X] expira hoje à meia-noite"
- Detalhar o valor desse bônus
- CTA com urgência real

### Step 3 — Close Sequence (D6-D7)

**D6: "24 Horas para Fechar"**
- Tom: sério mas empático
- Recap do valor total vs preço
- "Se você estava esperando um sinal, esse é o sinal"
- Endereçar a objeção "vou esperar o próximo"

**D7 AM: "Últimas Horas"**
- Countdown
- Depoimento final (o mais forte)
- CTA urgente

**D7 PM: "Fechando em X Horas"**
- Email curto e direto
- "Não quero que você se arrependa"
- Last CTA

**D7 23h: "Final Call"**
- 3-4 linhas máximo
- "Último lembrete. Fecha em 1 hora."
- Link direto

### Step 4 — Post-Cart
**Email D8: "Obrigado / Portas Fecharam"**
- Para compradores: welcome + próximos passos
- Para não-compradores: "As portas fecharam. Quando reabrir, você será o primeiro a saber."
- Plantar semente para próximo lançamento

## Output Schema
```yaml
open_cart_sequence:
  duration_days: X
  emails:
    - day: 1
      time: "AM"
      name: "Cart Open"
      subject_a: ""
      subject_b: ""
      body: ""
      cta: ""
    # ... todos os emails
  deadlines:
    early_bird: {expires: "D1 23:59", bonus: ""}
    mid_bonus: {expires: "D5 23:59", bonus: ""}
    cart_close: {date: "D7 23:59"}
  post_cart:
    buyers_email: ""
    non_buyers_email: ""
  total_emails: X
```

## Quality Gate
- [ ] Email de abertura celebra (não é hard sell)
- [ ] Case study com transformação real
- [ ] FAQ endereça objeções reais
- [ ] Urgência escalonada (suave → forte)
- [ ] Mínimo 8 emails no período
- [ ] Deadlines são reais e cumpridos
- [ ] Post-cart email para compradores E não-compradores
- [ ] Último email é curto e direto
