# Task: Pre-Prelaunch — Semente do Lançamento

## Metadata
- **Agent:** @jeff-walker
- **PLF Phase:** 0 — Pre-Prelaunch
- **depends_on:** Diagnosis (Tier 0)

## Input
```yaml
required:
  - product_concept: "O que será lançado"
  - avatar_profile: "Perfil do avatar (do HackerVerso)"
  - list_size: "Tamanho atual da lista"
  - market_temperature: "cold | warm | hot"
optional:
  - previous_launches: "Histórico de lançamentos anteriores"
  - jv_partners: "Lista de parceiros potenciais"
```

## Instruções

### Step 1 — Definir a Seed Idea
Antes de qualquer copy, definir a **semente do lançamento**:
- Qual transformação o produto entrega?
- Qual a ONE BIG PROMISE?
- Qual o mecanismo que torna possível?
- Por que AGORA é o momento certo?

### Step 2 — Mapeamento de Audiência
Segmentar a lista em 3 categorias:
- **Subscribers engajados** — abrem emails, clicam, interagem
- **Subscribers mornos** — na lista mas sem ação recente
- **Prospects frios** — novos ou inativos

### Step 3 — Pre-Prelaunch Sequence (3-5 emails)

**Email 1: "The Whisper"**
- Tone: casual, insider
- Não vender nada — plantar semente de curiosidade
- "Estou trabalhando em algo que [transformação]..."
- Pedir feedback genuíno (engagement + data)

**Email 2: "The Survey"**
- Pesquisa de 2-3 perguntas
- "Qual seu maior desafio com [tema]?"
- Usar exatamente essas palavras no copy futuro
- Framework: Mirror Words™ do Walker

**Email 3: "The Reveal Tease"**
- Revelar que algo está chegando
- "Baseado no que vocês me disseram..."
- NÃO revelar preço, formato, ou data de abertura
- Criar lista de espera (early access)

**Email 4 (opcional): "The Behind the Scenes"**
- Mostrar o processo de criação
- Vulnerabilidade controlada (humanizar)
- Screenshots, bastidores, decisões

**Email 5 (opcional): "The Commitment"**
- "Quem quer ser avisado primeiro?"
- Criar sub-lista de interesse alto (hiper-engajados)
- Estes receberão acesso antecipado

### Step 4 — Métricas de Saída

```yaml
pre_prelaunch_metrics:
  emails_sent: X
  open_rate_target: ">30%"
  click_rate_target: ">5%"
  survey_responses: "Mínimo 50 ou 5% da lista"
  waitlist_signups: "Alvo: 10-20% da lista engajada"
  mirror_words_collected: "Mínimo 30 frases do avatar"
```

### Step 5 — Handoff para PLC Sequence
Output alimenta `create-plc-sequence.md`:
- Mirror words coletados
- Segmentação de audiência
- Interest level data
- Waitlist size

## Output Schema
```yaml
pre_prelaunch:
  seed_idea:
    transformation: ""
    one_big_promise: ""
    mechanism: ""
    timing: ""
  audience_segments:
    engaged: {size: X, criteria: ""}
    warm: {size: X, criteria: ""}
    cold: {size: X, criteria: ""}
  email_sequence:
    - email_number: 1
      type: "whisper"
      subject_line: ""
      body: ""
      cta: ""
    # ... emails 2-5
  mirror_words: ["frases coletadas"]
  waitlist_size: X
  next_step: "create-plc-sequence"
```

## Quality Gate
- [ ] Seed idea clara com transformação + mecanismo
- [ ] Audiência segmentada em 3 níveis
- [ ] Mínimo 3 emails (máximo 5)
- [ ] Email 1 NÃO vende nada
- [ ] Survey inclui perguntas abertas para mirror words
- [ ] Lista de espera configurada
- [ ] Métricas alvo definidas
