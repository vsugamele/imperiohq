# Task: Sales Page PLF — Sideways Sales Letter

## Metadata
- **Agent:** @jeff-walker
- **PLF Phase:** 2 — Launch
- **depends_on:** `create-plc-sequence.md`
- **Template:** `sales-page-blueprint-tmpl.md`

## Input
```yaml
required:
  - plc_data: "Output dos 3 PLCs"
  - product_details: "Produto, preço, formato, garantia"
  - value_stack: "Stack de valor do PLC 3"
  - avatar_profile: "Perfil do avatar"
optional:
  - competitor_analysis: "Análise competitiva"
  - faq: "Perguntas frequentes"
```

## Instruções

### O Conceito: Sideways Sales Letter
Jeff Walker NÃO usa sales page tradicional (long-form scroll). Ele usa a **Sideways Sales Letter** — a combinação dos 3 PLCs + página de vendas funciona como uma sales letter dividida em 4 partes horizontais no tempo.

A página de vendas é a **última parte** dessa sequência. O prospect que chega já consumiu 3 PLCs. A página NÃO precisa recontar tudo — ela precisa FECHAR.

### Step 1 — Estrutura da Página PLF

1. **Hero Section**
   - Headline que reflete a transformação dos PLCs
   - Sub-headline com resultado específico + timeframe
   - Vídeo recap (2-3min) ou texto que resume a jornada
   - CTA primário ("Garanta sua vaga")

2. **Recap da Jornada (breve)**
   - "Nos últimos X dias, você aprendeu..."
   - PLC 1 → insight, PLC 2 → prova, PLC 3 → sistema
   - NÃO recontar tudo — apenas âncoras de memória

3. **A Oferta Completa**
   - Módulo por módulo com benefícios (não features)
   - Value stack com valores percebidos
   - Bônus com deadline (early-bird se aplicável)
   - Total de valor vs preço

4. **Garantia**
   - Tipo: incondicional, condicional, ou híbrida
   - Período: 7, 15, 30 dias
   - Linguagem: reverter risco para o vendedor
   - "Se em X dias você não [resultado], devolvo 100%"

5. **FAQ**
   - 5-8 perguntas reais (usar survey do pre-prelaunch)
   - Incluir objeções disfarçadas de perguntas
   - Formato: pergunta + resposta curta

6. **Social Proof Wall**
   - Depoimentos dos PLCs (quem teve resultado)
   - Screenshots de comentários
   - Resultados anteriores se houver
   - Mínimo 5 provas sociais

7. **Urgência Real**
   - Timer se vagas limitadas
   - "X vagas restantes" se verdade
   - Bônus expirando em data específica
   - NUNCA urgência fabricada

8. **CTA Final + P.S.**
   - CTA repetido
   - P.S. 1: Recap da transformação
   - P.S. 2: Lembrete da garantia
   - P.S. 3: Urgência final

## Output Schema
```yaml
plf_sales_page:
  hero:
    headline: ""
    sub_headline: ""
    cta_text: ""
    video: true/false
  journey_recap: "Texto breve"
  offer:
    modules: [{name: "", benefit: "", value: ""}]
    bonuses: [{name: "", value: "", deadline: ""}]
    total_value: ""
    price: ""
    payment_options: [""]
  guarantee:
    type: "incondicional | condicional | híbrida"
    period: "X dias"
    text: ""
  faq: [{question: "", answer: ""}]
  social_proof: [{type: "", content: ""}]
  urgency:
    type: "vagas | tempo | bônus"
    real: true
    details: ""
  cta_final: ""
  ps_sections: [""]
  full_page_html_or_text: "Copy completo"
```

## Quality Gate
- [ ] Página NÃO recontar PLCs (assume prospect educado)
- [ ] Value stack com valores percebidos para cada item
- [ ] Garantia clara e específica
- [ ] Mínimo 5 provas sociais
- [ ] FAQ endereça objeções reais
- [ ] Urgência é REAL (não fabricada)
- [ ] Múltiplos CTAs ao longo da página
- [ ] P.S. sections presentes
