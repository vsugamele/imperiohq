# Task: Map Mental Triggers — Mapeamento de Gatilhos Mentais

## Metadata
- **Agent:** @jeff-walker
- **PLF Phase:** Planejamento (antes dos PLCs)
- **depends_on:** Avatar profile, offer details
- **Referência:** `squads/copy/data/mental-triggers-kb.yaml`

## Input
```yaml
required:
  - avatar_profile: "Perfil completo do avatar"
  - product_details: "Produto e oferta"
  - launch_type: "seed | internal | jv | evergreen"
```

## Instruções

### Step 1 — Carregar KB
Ler `squads/copy/data/mental-triggers-kb.yaml` para lista completa de triggers.

### Step 2 — Mapear Triggers por Fase

Para cada fase do lançamento, identificar quais triggers ativar:

**Pre-Prelaunch:**
- Reciprocidade (valor gratuito)
- Curiosidade (teaser)
- Comunidade (pesquisa/feedback)

**PLC 1:**
- Autoridade (expertise)
- Reciprocidade (ensinar algo real)
- Prova social (se disponível)
- Curiosidade (loop aberto PLC 2)

**PLC 2:**
- Prova social (case studies)
- Autoridade (conhecimento profundo)
- Antecipação (quando posso comprar?)
- Comunidade (comentários, engajamento)

**PLC 3:**
- Antecipação (quase na hora)
- Escassez (vagas limitadas)
- Compromisso (investiu 3 PLCs)
- Propriedade (future pacing)

**Cart Open:**
- Urgência (deadline)
- Escassez (vagas, bônus)
- Prova social (primeiros compradores)
- Medo de perder (FOMO)

**Cart Close:**
- Urgência máxima (últimas horas)
- Arrependimento futuro (cost of inaction)
- Escassez real (deadline cumprido)

### Step 3 — Plano de Ativação
Para cada trigger mapeado:
1. ONDE ativar (email, PLC, página)
2. COMO ativar (mecanismo específico)
3. INTENSIDADE (sutil → forte)
4. MEDIÇÃO (como saber se funcionou)

## Output Schema
```yaml
mental_triggers_map:
  pre_prelaunch: [{trigger: "", activation: "", intensity: ""}]
  plc1: [{trigger: "", activation: "", intensity: ""}]
  plc2: [{trigger: "", activation: "", intensity: ""}]
  plc3: [{trigger: "", activation: "", intensity: ""}]
  cart_open: [{trigger: "", activation: "", intensity: ""}]
  cart_close: [{trigger: "", activation: "", intensity: ""}]
  total_triggers_used: X
  dominant_triggers: ["top 3 mais usados"]
```

## Quality Gate
- [ ] Mínimo 3 triggers por fase
- [ ] Triggers diferentes priorizados por fase
- [ ] Escala de intensidade respeita a jornada
- [ ] Cada trigger tem mecanismo de ativação específico
- [ ] NÃO usar manipulação (urgência falsa, escassez falsa)
