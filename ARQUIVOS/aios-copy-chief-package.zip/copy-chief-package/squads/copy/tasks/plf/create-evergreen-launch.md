# Task: Evergreen Launch — Lançamento Perpétuo

## Metadata
- **Agent:** @jeff-walker
- **PLF Phase:** Advanced (pós-live launch bem-sucedido)
- **depends_on:** Pelo menos 1 live launch com resultados
- **Template:** `evergreen-setup.md`

## Input
```yaml
required:
  - live_launch_data: "PLCs gravados, emails, métricas"
  - conversion_rate: "Taxa de conversão do live launch"
  - funnel_platform: "Plataforma de automação"
```

## Instruções

### Conceito
Transformar o lançamento live em funil perpétuo automatizado. O prospect entra e experiencia o "lançamento" como se fosse ao vivo, mas é 100% automatizado.

### Step 1 — Converter PLCs para Evergreen
- Editar PLCs removendo referências temporais ("esta semana", "ontem")
- Manter urgência via deadline dinâmico (X dias após opt-in)
- Adicionar chat simulado ou comentários reais do live
- Manter Q&A section com melhores perguntas

### Step 2 — Automação de Email Sequence
Converter calendário fixo em sequence relativa:
```
D+0: Lead entra → Welcome + PLC 1
D+1: Reminder PLC 1
D+2: PLC 2 delivery
D+3: PLC 2 reminder + social proof
D+4: PLC 3 delivery
D+5: Bridge "amanhã abre"
D+6: Cart open (deadline D+12)
D+7: Case study
D+8: FAQ
D+9: Objection crusher
D+10: Last chance bonus
D+11: 24h warning
D+12: Cart close
```

### Step 3 — Deadline Dinâmico
- Usar Deadline Funnel ou similar
- Cada pessoa tem SEU deadline (7 dias após cart open)
- Cookie-based — se voltar após deadline, oferta fechada
- Opção: re-engagement sequence após 30 dias

### Step 4 — Otimização Contínua
Métricas a monitorar:
- Opt-in rate (landing page → lead)
- PLC completion rate (quantos assistem cada PLC)
- Cart page visit rate
- Conversion rate
- Revenue per lead

Split tests prioritários:
1. Landing page headline
2. PLC 1 hook (primeiros 30s)
3. Cart page headline
4. Email subject lines (cart open + close)
5. Preço/oferta

## Output Schema
```yaml
evergreen_launch:
  plc_edits: [{plc: 1, changes: []}]
  email_sequence:
    - day: "D+X"
      email: ""
      subject: ""
      body: ""
  deadline:
    tool: ""
    days_open: X
    re_engagement_after: "30 days"
  optimization:
    metrics: [{name: "", target: ""}]
    split_tests: [{priority: 1, element: "", hypothesis: ""}]
  tech_stack:
    automation: ""
    deadline: ""
    hosting: ""
```

## Quality Gate
- [ ] Referências temporais removidas dos PLCs
- [ ] Deadline dinâmico configurado (não data fixa)
- [ ] Email sequence usa D+X (não datas absolutas)
- [ ] Métricas de monitoramento definidas
- [ ] Plano de split tests prioritizados
- [ ] Re-engagement sequence para quem não comprou
