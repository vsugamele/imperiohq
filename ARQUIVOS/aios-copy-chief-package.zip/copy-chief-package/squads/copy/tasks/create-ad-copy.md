# Task: Create Ad Copy

## Metadata
- **ID:** create-ad-copy
- **Agent:** @gary-bencivenga (headlines) + @dan-kennedy (DR)
- **Tier:** 1-2

## Input
```yaml
required:
  - platform: "facebook | instagram | google-search | google-display | youtube"
  - diagnosis: "Output do @eugene-schwartz"
  - avatar_profile: "Perfil do avatar"
  - offer: "O que está oferecendo (link para)"
optional:
  - constraints: "Character limits, format specs"
  - existing_ads: "Ads atuais (para superar)"
```

## Instructions

### Step 1: Platform Adaptation
- **Facebook/Instagram:** Hook visual + 3-5 linhas + CTA
- **Google Search:** Headline (30 chars) + Description (90 chars)
- **YouTube:** Hook em 5 segundos (skip-proof)

### Step 2: Generate 10 Variations
Create 10 ad variations using different angles:
1. Pain-focused (agitation)
2. Desire-focused (aspiration)
3. Curiosity-focused (open loop)
4. Social proof-focused (numbers)
5. Counter-intuitive (pattern interrupt)
6. Question hook
7. Testimonial-based
8. How-to promise
9. Warning/fear
10. Direct offer

### Step 3: Select Top 3
Rank by: (a) hook strength, (b) specificity, (c) alignment with diagnosis

## Output Schema
```yaml
ad_set:
  platform: "..."
  variations:
    - id: 1
      angle: "pain | desire | curiosity | etc"
      headline: "..."
      body: "..."
      cta: "..."
  recommended_top3: [1, 5, 7]
```

## Quality Gate
- [ ] 10 variations with different angles
- [ ] Hook in first 3 words
- [ ] Specificity (numbers, not vague)
- [ ] CTA is clear one-action
- [ ] Respects platform character limits
