# Task: VSL Script

## Metadata
- **ID:** vsl-script
- **Agent:** @jon-benson
- **Tier:** 3

## Input
```yaml
required:
  - diagnosis: "Output do @eugene-schwartz"
  - avatar_profile: "Perfil do avatar"
  - product: "O que está vendendo"
  - offer: "Preço, bônus, garantia"
  - target_length: "short (8-12min) | standard (15-22min)"
```

## Instructions

### Follow @jon-benson's 8-Block Structure
See agent file for complete methodology.

### Slide Rules
- Max 15 words per slide
- 3-5 seconds per slide
- Highlight keywords (bold, color, size)
- One idea per slide
- Hook every 30 seconds (no natural exit points)

### Key Decisions
- CTA appears at minute ~75% of total duration
- No progress bar
- Script reads naturally when spoken aloud

## Output Schema
```yaml
vsl:
  total_duration: "XX min"
  total_slides: N
  blocks:
    - block_num: 1
      name: "Pattern Interrupt"
      slides:
        - number: 1
          text: "..."
          highlight: "keyword"
          timing: "Xs"
  cta_appears_at: "slide N / minute X"
  narration_notes: "Speed, tone, pauses"
```

## Quality Gate
- [ ] 8 blocks complete
- [ ] No slide >15 words
- [ ] Hook every 30 seconds
- [ ] CTA delayed until after full pitch
- [ ] Read-aloud test passes naturally
