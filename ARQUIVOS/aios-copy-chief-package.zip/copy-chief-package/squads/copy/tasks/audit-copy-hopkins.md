# Task: Auditoria Hopkins — Scientific Advertising Audit

## Metadata
- **Agent:** @claude-hopkins
- **Tier:** 0 (Quality Control)
- **Trigger:** Após QUALQUER copy ser produzida por Tier 1-3
- **Mínimo para aprovação:** 85/100

## Input
```yaml
required:
  - copy_text: "O copy completo a ser auditado"
  - copy_type: "sales-page | email | ad | vsl | headline | upsell | landing"
  - target_audience: "Descrição do público-alvo"
  - awareness_level: "Unaware | Problem-Aware | Solution-Aware | Product-Aware | Most-Aware"
optional:
  - market_sophistication: "1-5 (Eugene Schwartz scale)"
  - unique_mechanism: "Mecanismo único se existir"
  - diagnosis_data: "Output do Tier 0 diagnosis"
```

## Instruções

### Step 1 — Leitura Completa
Leia o copy inteiro SEM julgamento prévio. Absorva o fluxo, a lógica, o ritmo. Depois releia marcando cada seção.

### Step 2 — Avaliação por 10 Dimensões (0-10 cada)

#### D1. Headline / Abertura (0-10)
- Interrompe o scroll/atenção?
- Filtra o público certo?
- Promessa clara ou curiosidade irresistível?
- Conecta com a conversa mental do prospect?
- **Red flag:** Headline genérica, clickbait vazio, promessa impossível

#### D2. Lead / Gancho Inicial (0-10)
- Primeiros 3 parágrafos prendem?
- Estabelece relevância pessoal?
- Cria curiosidade para continuar lendo?
- Match com awareness level?
- **Red flag:** Lead que fala do produto antes de falar do problema

#### D3. Problema / Dor (0-10)
- Dor articulada nas palavras do prospect?
- Camadas: lógica, emocional, identidade?
- Agitação adequada (sem exagero, sem superficialidade)?
- Prospect sente "essa pessoa me entende"?
- **Red flag:** Dor genérica, agitação forçada, manipulação barata

#### D4. Mecanismo / Solução (0-10)
- Mecanismo único e diferenciado?
- Explicação clara do "por que funciona"?
- Credibilidade científica ou lógica?
- Naming proprietário se aplicável?
- **Red flag:** Mecanismo é "meu método de 7 passos" (genérico)

#### D5. Prova / Credibilidade (0-10)
- Social proof específico (não genérico)?
- Resultados com números, nomes, timeframes?
- Credenciais do autor/marca?
- Prova adequada ao claim?
- **Red flag:** Depoimentos vagos, claims sem prova, autoridade forçada

#### D6. Oferta / Valor (0-10)
- Oferta é irresistível (valor >> preço)?
- Value stack claro e tangível?
- Garantia remove risco?
- Urgência/escassez real (não fabricada)?
- **Red flag:** Oferta confusa, 10 bônus aleatórios, urgência falsa

#### D7. CTA / Fechamento (0-10)
- CTA claro e específico?
- Remove últimas objeções?
- Linguagem de ação (não passiva)?
- Alinhado com awareness level?
- **Red flag:** CTA fraco ("saiba mais"), múltiplos CTAs conflitantes

#### D8. Flow / Slippery Slide (0-10)
- Cada seção leva naturalmente à próxima?
- Sem pontos de abandono?
- Ritmo varia (parágrafos curtos/longos)?
- Bucket brigades e transições?
- **Red flag:** Blocos de texto gigantes, saltos lógicos, repetição

#### D9. Voz / Tom (0-10)
- Consistente com a marca?
- Match com o público?
- Autêntico (não genérico/AI)?
- Personalidade presente?
- **Red flag:** Tom muda no meio, linguagem corporativa em copy para jovens

#### D10. Adequação Estratégica (0-10)
- Match com awareness level?
- Match com sophistication level?
- Posicionamento adequado na value ladder?
- Consistente com a narrativa do funil?
- **Red flag:** Copy de Most-Aware para público Unaware

### Step 3 — Cálculo do Score

```
Hopkins Score = (D1 + D2 + D3 + D4 + D5 + D6 + D7 + D8 + D9 + D10) = X/100
```

**Classificação:**
- 90-100: EXCELENTE → Aprovar com minor notes
- 85-89: BOM → Aprovar com recommendations
- 70-84: MÉDIO → Requer revisão antes de publicar
- 50-69: FRACO → Requer rewrite significativo
- 0-49: REPROVADO → Rewrite completo

### Step 4 — Feedback Estruturado

Para cada dimensão < 8:
1. O que está errado (diagnóstico específico)
2. O que deveria ser (padrão esperado)
3. Exemplo de como corrigir (rewrite sugerido)
4. Qual copywriter do squad deveria corrigir

### Step 5 — Veredicto Final

## Output Schema
```yaml
hopkins_audit:
  score_total: 0-100
  classification: "EXCELENTE | BOM | MÉDIO | FRACO | REPROVADO"
  approved: true/false
  dimensions:
    - name: "Headline"
      score: 0-10
      notes: "Feedback"
    # ... D2-D10
  critical_issues: ["Lista de problemas graves"]
  improvements:
    - dimension: "Nome"
      current: "O que está"
      target: "O que deveria ser"
      suggested_fix: "Como corrigir"
      assigned_to: "@copywriter"
  next_action: "approve | revise | rewrite"
  copywriter_for_revision: "@agent se necessário"
```

## Quality Gate
- [ ] Todas 10 dimensões avaliadas com justificativa
- [ ] Score calculado corretamente
- [ ] Feedback específico para dimensões < 8
- [ ] Rewrite sugerido para dimensões < 6
- [ ] Copywriter atribuído para revisão se necessário
- [ ] Veredicto final claro (approve/revise/rewrite)
