# Task: Create Upsell Page

## Metadata
- **ID:** create-upsell-page
- **Agent:** @dan-kennedy
- **Tier:** 2

## Input
```yaml
required:
  - main_product: "O que acabaram de comprar"
  - upsell_product: "O que estamos oferecendo agora"
  - upsell_price: "Preço do upsell"
  - main_price: "Preço do produto principal"
```

## Instructions

### Upsell Principles
1. **Timing:** Appear IMMEDIATELY after purchase (momentum)
2. **Logic:** Natural complement ("you just bought X, you'll also need Y")
3. **Price:** Upsell typically 30-60% of main product price
4. **Speed:** Page must be SHORT (200-500 words or 3-5 min VSL)
5. **One-click:** No re-entering payment info

### Structure
1. **Congratulations Bridge** (1 paragraph) — Validate their purchase
2. **The Gap** (1 paragraph) — What's missing / the next logical step
3. **The Upsell** (2 paragraphs) — What it is + why they need it NOW
4. **Price Anchor** — Compare to standalone price
5. **OTO (One-Time Offer)** — Available ONLY right now at this price
6. **CTA** — "Yes, add to my order" / "No thanks, I'll pass"

### Downsell
If they click "No": show downsell at 40-60% of upsell price or stripped-down version.

## Output Schema
```yaml
upsell_page:
  congratulations: "..."
  gap: "..."
  offer: "..."
  price: "R$XXX (standalone R$YYY)"
  oto_text: "One-time offer text"
  cta_yes: "Add to order"
  cta_no: "No thanks"
  downsell:
    offer: "Stripped version or lower price"
    price: "R$ZZZ"
```

## Quality Gate
- [ ] Logical complement to main product
- [ ] Price is 30-60% of main
- [ ] OTO urgency (only available now)
- [ ] Short (under 500 words)
- [ ] Downsell prepared if they say no
