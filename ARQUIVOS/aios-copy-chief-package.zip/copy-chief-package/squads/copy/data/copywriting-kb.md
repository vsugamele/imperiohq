# Copywriting Knowledge Base

## 1. Frameworks Fundamentais

### 1.1 — AIDA (Atenção → Interesse → Desejo → Ação)
O framework mais antigo e básico. Útil como checklist mínimo, não como estrutura completa.
- **Atenção:** Hook nos primeiros 3 segundos
- **Interesse:** Problema ou oportunidade que conecta
- **Desejo:** Benefícios + proof + visualização do resultado
- **Ação:** CTA claro com urgência

### 1.2 — PAS (Problem → Agitate → Solve)
Mais poderoso que AIDA para copy de resposta direta:
- **Problem:** Nomear a dor exata (palavras do avatar)
- **Agitate:** Intensificar a dor (consequências, custo, futuro sombrio)
- **Solve:** Apresentar a solução como alívio natural

### 1.3 — PASTOR (Problem, Amplify, Story, Transformation, Offer, Response)
Versão expandida do PAS para long-form:
- **P**roblem: Identificar e nomear
- **A**mplify: Intensificar com consequências
- **S**tory: História de transformação (sua ou de cliente)
- **T**ransformation: O resultado específico
- **O**ffer: O que recebe, value stack
- **R**esponse: CTA com urgência

### 1.4 — 4 Ps (Promise, Picture, Proof, Push)
Framework rápido para emails e ads:
- **Promise:** Benefício principal
- **Picture:** Visualização do resultado
- **Proof:** Evidência
- **Push:** CTA

### 1.5 — Star-Chain-Hook
Para storytelling persuasivo:
- **Star:** O protagonista (avatar ou expert)
- **Chain:** A sequência de eventos que leva ao resultado
- **Hook:** O CTA que captura a ação

## 2. Conceitos Core

### 2.1 — Slippery Slide (Joseph Sugarman)
Cada elemento do copy tem UM propósito: fazer o prospect ler o PRÓXIMO elemento. Headline → subhead → primeira frase → segunda frase. Se qualquer ponto permite "saída natural", o slide quebrou.

### 2.2 — A-Pile vs B-Pile (Gary Halbert)
- **A-Pile:** Parece carta pessoal. O prospect abre e lê.
- **B-Pile:** Parece propaganda. O prospect joga fora.
Todo copy deve ser escrito para ir pro A-pile.

### 2.3 — Big Idea (David Ogilvy)
Uma campanha sem Big Idea é um navio sem leme. A Big Idea é o conceito central que:
- Captura atenção imediata
- É memorável
- Gera conversa
- Vive além de uma peça específica

### 2.4 — The Control
A versão de copy que está performando melhor no momento. Toda nova versão compete contra o control. Se não bate, não substitui. O control é rei até ser destronado por dados.

### 2.5 — Value Stack
Listar TUDO que o prospect recebe com preço percebido de cada item:
```
Item Principal ................. R$997
Bônus 1: ...................... R$297
Bônus 2: ...................... R$197
Bônus 3: ...................... R$497
────────────────────────────────────
Valor Total: .................. R$1.988
Você paga apenas: ............. R$497
```

### 2.6 — Grand Slam Offer (Alex Hormozi)
Oferta = Dream Outcome × Perceived Likelihood ÷ Time Delay ÷ Effort & Sacrifice
- Maximizar: resultado e probabilidade percebida
- Minimizar: tempo de espera e esforço requerido

## 3. Tipos de Copy por Canal

### 3.1 — Sales Page
Formato: Long-form (2000-5000+ palavras)
Estrutura: Hook → Story → Agitation → Mechanism → Proof → Offer → Guarantee → CTA → P.S.
Copywriter ideal: @gary-halbert, @gary-bencivenga, @dan-kennedy

### 3.2 — VSL (Video Sales Letter)
Formato: Script de 15-22 minutos, texto na tela
Estrutura: 8 blocos (Pattern Interrupt → Close)
Copywriter ideal: @jon-benson

### 3.3 — Email Sequence
Formato: 5-12 emails ao longo de dias/semanas
Tipos: Welcome, Soap Opera (story-driven), nurture, launch, cart close
Copywriter ideal: @dan-kennedy, @gary-halbert

### 3.4 — Ad Copy
Formato: 3-5 frases (Facebook) ou 90-150 caracteres (Google)
Foco: Hook + benefício + CTA
Copywriter ideal: @gary-bencivenga (headlines), @dan-kennedy (DR)

### 3.5 — Landing Page
Formato: Curto (300-800 palavras)
Foco: Uma oferta, um CTA, zero distrações
Copywriter ideal: varia por diagnóstico

### 3.6 — Launch Sequence (PLF)
Formato: PLC1 → PLC2 → PLC3 → Open Cart → Close Cart
Foco: Educação progressiva + mental triggers
Copywriter ideal: @jeff-walker

### 3.7 — Webinar Script
Formato: 45-90 minutos, ensino + pitch
Foco: Entregar valor → Transição → Oferta → Close
Copywriter ideal: @todd-brown, @jeff-walker

### 3.8 — Upsell/Order Bump
Formato: Curto (200-500 palavras) ou 3-5 min VSL
Foco: Complemento lógico à compra anterior
Copywriter ideal: @dan-kennedy

## 4. Glossário Técnico

| Termo | Definição |
|-------|-----------|
| **Avatar** | Representação detalhada do cliente ideal |
| **Bridge** | Transição emocional entre seções do copy |
| **Bullet/Fascination** | Mini-hooks que criam curiosidade irresistível |
| **Control** | A versão de copy vencedora atual |
| **CTA** | Call to Action — instrução específica de próximo passo |
| **Damaging Admission** | Admitir fraqueza real para aumentar credibilidade |
| **Fascination** | Bullet point que vende pela curiosidade |
| **Future Pace** | Fazer o leitor visualizar o resultado futuro |
| **Hook** | Elemento que captura atenção nos primeiros 3 segundos |
| **Lead** | Primeira seção do copy (abertura) |
| **Mechanism** | A razão técnica/lógica por que algo funciona |
| **OTO** | One-Time Offer — oferta única pós-compra |
| **PLC** | Prelaunch Content — conteúdo pré-lançamento (PLF) |
| **Proof Stack** | Conjunto empilhado de evidências |
| **Risk Reversal** | Garantia que transfere risco para o vendedor |
| **Slippery Slide** | Princípio de que cada frase puxa a próxima |
| **Swipe File** | Coleção de copy comprovada para referência |
| **Unique Mechanism** | Diferenciação pelo COMO, não pelo O QUE |
| **Value Stack** | Lista de entregas com valor percebido |
| **VSL** | Video Sales Letter — vídeo de venda com texto na tela |

## 5. Métricas de Copy

| Métrica | O que Mede | Target |
|---------|-----------|--------|
| Hopkins Score | Qualidade científica do copy | ≥85/100 |
| Sugarman Triggers | Cobertura psicológica | ≥80% (24/30) |
| Readability | Facilidade de leitura | Flesch 60-70 |
| Conversion Rate | % de visitantes que compram | Varia por canal |
| Average Time on Page | Engajamento com o copy | >3min para sales pages |
| Scroll Depth | Quanto da página é lida | >60% para conversão |

## 6. Regras de Formatação

### Para Web/Digital
- Parágrafos de 2-4 linhas máximo
- Subheads a cada 200-300 palavras
- Bullets para listas (fascinations)
- Bold em palavras-chave (não em frases inteiras)
- Espaço em branco generoso

### Para Email
- Subject line = headline (testável)
- Primeira frase visível no preview (hook)
- 1 CTA por email (máximo 2 menções do mesmo CTA)
- Tom pessoal (A-pile)
- P.S. obrigatório

### Para VSL
- 1-2 frases por slide
- Máximo 15 palavras por slide
- Palavras-chave em destaque
- Sem barra de progresso
- CTA aparece após pitch completo
