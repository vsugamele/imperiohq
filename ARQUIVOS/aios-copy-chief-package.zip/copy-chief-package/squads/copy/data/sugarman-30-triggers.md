# Sugarman 30 Psychological Triggers

## Instruções de Uso
Esta é uma FERRAMENTA DE VALIDAÇÃO, não um copywriter. Após o copy ser produzido e aprovado no Hopkins Audit (≥85/100), passe pelos 30 triggers abaixo. Meta: ≥80% de cobertura (24 de 30 triggers ativados).

**IMPORTANTE:** São 30 triggers. Não 31, não 29. TRINTA.

---

## Os 30 Triggers

### Trigger 01: Feeling of Involvement / Ownership
**O que é:** Fazer o prospect se SENTIR dono antes de comprar.
**Como ativar:** "Imagine você usando...", "Quando você começar...", future pacing.
**Checklist:** O copy faz o prospect visualizar o produto em suas mãos/vida? [ ]

### Trigger 02: Honesty
**O que é:** Ser brutalmente honesto — inclusive sobre limitações.
**Como ativar:** Damaging admissions, "não é para todo mundo", admitir defeitos.
**Checklist:** Há pelo menos 1 admissão honesta que aumenta credibilidade? [ ]

### Trigger 03: Integrity
**O que é:** Cumprir o que promete. Consistência entre promessa e entrega.
**Como ativar:** Garantia real, track record, "fizemos X e entregamos Y".
**Checklist:** As promessas são sustentáveis por proof real? [ ]

### Trigger 04: Credibility
**O que é:** O prospect acredita no que você diz?
**Como ativar:** Credenciais, dados, autoridade, endossos, media mentions.
**Checklist:** Há elementos de autoridade/credibilidade presentes? [ ]

### Trigger 05: Value and Proof of Value
**O que é:** O prospect vê mais VALOR do que o PREÇO cobrado?
**Como ativar:** Value stack, comparação de preço, ROI math.
**Checklist:** O valor percebido é claramente maior que o preço? [ ]

### Trigger 06: Justify the Purchase
**O que é:** Dar ao prospect uma RAZÃO LÓGICA para justificar a compra emocional.
**Como ativar:** "Você merece porque...", "É um investimento, não um gasto porque...".
**Checklist:** O copy dá ao prospect argumentos para justificar para si mesmo (ou cônjuge)? [ ]

### Trigger 07: Greed
**O que é:** O desejo de obter mais por menos.
**Como ativar:** Bônus, descontos, "leve 3 pague 2", valor agregado.
**Checklist:** A oferta ativa o sentimento de "estou levando vantagem"? [ ]

### Trigger 08: Establish Authority
**O que é:** Posicionar-se como a autoridade no assunto.
**Como ativar:** Anos de experiência, resultados de clientes, publicações, media.
**Checklist:** O expert/marca é posicionado como autoridade? [ ]

### Trigger 09: Satisfaction Conviction
**O que é:** Convicção de que o prospect FICARÁ satisfeito.
**Como ativar:** Garantia forte, trial, "se não funcionar, devolvo cada centavo".
**Checklist:** Há garantia que remove risco de insatisfação? [ ]

### Trigger 10: Nature of the Product
**O que é:** Alinhar o copy com a NATUREZA do produto.
**Como ativar:** Copy de luxo para produto premium. Copy urgente para produto de necessidade.
**Checklist:** O tom/estilo do copy é consistente com o tipo de produto? [ ]

### Trigger 11: Current Fads
**O que é:** Conectar com tendências atuais do mercado.
**Como ativar:** Referências a tendências, zeitgeist, movimentos culturais relevantes.
**Checklist:** O copy se conecta com algo relevante no momento? [ ]

### Trigger 12: Timing
**O que é:** O momento certo para a mensagem certa.
**Como ativar:** Sazonalidade, eventos, momentos de vida do avatar.
**Checklist:** O timing da oferta faz sentido para o avatar? [ ]

### Trigger 13: Belonging
**O que é:** Desejo de pertencer a um grupo.
**Como ativar:** "Junte-se a [N] pessoas que...", comunidade, insider status.
**Checklist:** O copy cria senso de pertencimento/comunidade? [ ]

### Trigger 14: Collecting
**O que é:** Desejo humano de colecionar/completar.
**Como ativar:** Séries, módulos, níveis, "complete sua coleção".
**Checklist:** Há elemento de coleção ou progressão? [ ]

### Trigger 15: Curiosity
**O que é:** Gap de informação que o prospect PRECISA fechar.
**Como ativar:** Open loops, fascinations, "o que aconteceu a seguir...".
**Checklist:** Há pelo menos 3 open loops/fascinations que criam curiosidade? [ ]

### Trigger 16: Sense of Urgency
**O que é:** Razão para agir AGORA, não depois.
**Como ativar:** Deadline real, preço sobe, vagas limitadas.
**Checklist:** Há urgência com deadline real (não fake)? [ ]

### Trigger 17: Instant Gratification
**O que é:** Resultado rápido/imediato após a compra.
**Como ativar:** "Acesso imediato", "resultados em X dias", quick wins.
**Checklist:** O prospect sabe quando terá o primeiro resultado? [ ]

### Trigger 18: Exclusivity / Scarcity
**O que é:** Algo limitado, não disponível para todos.
**Como ativar:** "Apenas X vagas", "edição limitada", "convite exclusivo".
**Checklist:** Há escassez real (não fabricada)? [ ]

### Trigger 19: Simplicity
**O que é:** A solução parece simples de implementar.
**Como ativar:** "3 passos simples", "sem experiência necessária", "plug and play".
**Checklist:** O prospect acredita que CONSEGUE implementar? [ ]

### Trigger 20: Human Relationships
**O que é:** Conexão humana entre vendedor e comprador.
**Como ativar:** História pessoal, vulnerabilidade, tom conversacional.
**Checklist:** O copy cria conexão humana (não corporativa)? [ ]

### Trigger 21: Storytelling
**O que é:** Narrativa que envolve emocionalmente.
**Como ativar:** Histórias pessoais, cases de clientes, antes/depois.
**Checklist:** Há pelo menos 1 história envolvente no copy? [ ]

### Trigger 22: Mental Engagement
**O que é:** O prospect participa mentalmente (não é passivo).
**Como ativar:** Perguntas retóricas, "imagine...", exercícios mentais.
**Checklist:** O copy faz o prospect PENSAR ativamente? [ ]

### Trigger 23: Guilt
**O que é:** Senso de obrigação ou reciprocidade.
**Como ativar:** Dar valor primeiro (conteúdo grátis), "depois de tudo que compartilhei...".
**Checklist:** Há reciprocidade ativada (valor dado antes do pedido)? [ ]

### Trigger 24: Specificity
**O que é:** Claims com detalhes precisos (números, datas, nomes).
**Como ativar:** Substituir "muitos" por "47.823", "rápido" por "em 14 dias".
**Checklist:** Claims usam números/detalhes específicos (não genéricos)? [ ]

### Trigger 25: Familiarity
**O que é:** O prospect reconhece algo familiar no copy.
**Como ativar:** Referências culturais, linguagem do nicho, "você já deve ter notado que...".
**Checklist:** O copy usa referências familiares ao avatar? [ ]

### Trigger 26: Hope
**O que é:** Crença de que a situação pode melhorar.
**Como ativar:** Cases de transformação, possibilidade real, "se eles conseguiram...".
**Checklist:** O copy gera esperança realista (não falsa)? [ ]

### Trigger 27: Pattern Interrupt
**O que é:** Quebrar o padrão de pensamento do prospect.
**Como ativar:** Afirmação contraintuitiva, dado chocante, pergunta inesperada.
**Checklist:** O copy tem pelo menos 1 pattern interrupt claro? [ ]

### Trigger 28: Linking
**O que é:** Conectar produto a algo que o prospect já valoriza.
**Como ativar:** Associação com marca/pessoa/causa respeitada.
**Checklist:** O produto é associado a algo que o avatar já respeita? [ ]

### Trigger 29: Desire to Belong
**O que é:** Similar a Belonging, mas focado em ASPIRAÇÃO.
**Como ativar:** "Os top [X]% fazem isso", "profissionais de elite usam...".
**Checklist:** O copy conecta a compra com uma identidade aspiracional? [ ]

### Trigger 30: Consistency
**O que é:** As pessoas querem ser consistentes com ações anteriores.
**Como ativar:** "Você já deu o primeiro passo quando [ação anterior]...", micro-commitments.
**Checklist:** O copy usa compromissos anteriores do prospect? [ ]

---

## Scorecard de Validação

```
TRIGGER                         | ATIVADO | NOTA
01 Involvement/Ownership        | [ ]     |
02 Honesty                      | [ ]     |
03 Integrity                    | [ ]     |
04 Credibility                  | [ ]     |
05 Value/Proof of Value         | [ ]     |
06 Justify Purchase             | [ ]     |
07 Greed                        | [ ]     |
08 Authority                    | [ ]     |
09 Satisfaction Conviction      | [ ]     |
10 Nature of Product            | [ ]     |
11 Current Fads                 | [ ]     |
12 Timing                       | [ ]     |
13 Belonging                    | [ ]     |
14 Collecting                   | [ ]     |
15 Curiosity                    | [ ]     |
16 Urgency                      | [ ]     |
17 Instant Gratification        | [ ]     |
18 Exclusivity/Scarcity         | [ ]     |
19 Simplicity                   | [ ]     |
20 Human Relationships          | [ ]     |
21 Storytelling                 | [ ]     |
22 Mental Engagement            | [ ]     |
23 Guilt/Reciprocity            | [ ]     |
24 Specificity                  | [ ]     |
25 Familiarity                  | [ ]     |
26 Hope                         | [ ]     |
27 Pattern Interrupt            | [ ]     |
28 Linking                      | [ ]     |
29 Desire to Belong             | [ ]     |
30 Consistency                  | [ ]     |
─────────────────────────────────────────
TOTAL ATIVADOS: ___/30 = ___%
META: ≥24/30 (80%)
```

## Prioridade por Tipo de Copy

| Tipo | Triggers OBRIGATÓRIOS (não pode faltar) |
|------|----------------------------------------|
| Sales Page | 01, 05, 09, 15, 16, 21, 24 |
| Email | 15, 20, 21, 22, 27 |
| VSL | 01, 15, 16, 21, 22, 27 |
| Ad | 15, 16, 24, 27 |
| Landing | 05, 09, 16, 19 |
| Launch/PLF | 13, 15, 16, 18, 23 |
