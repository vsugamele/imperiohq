# BRIEFING: Deploy Copy-Chief Package no AIOS-Core

## O Que Este Pacote Contém

**55 arquivos** que completam o copy-chief — transformando-o de shell funcional em squad operacional.

### Inventário

| Categoria | Quantidade | Diretório Destino |
|---|---|---|
| Personas (chief + 11 sub-agents) | 12 | `.claude/commands/Copy/agents/` |
| Tasks (copy core) | 11 | `squads/copy/tasks/` |
| Tasks (PLF - Jeff Walker) | 12 | `squads/copy/tasks/plf/` |
| Templates | 13 | `squads/copy/templates/` |
| Checklists | 4 | `squads/copy/checklists/` |
| Knowledge Bases | 3 | `squads/copy/data/` |
| **TOTAL** | **55** | |

## Como Instalar

### Passo 1 — Copiar Personas para Commands
```bash
# Dentro do repo aios-core
mkdir -p .claude/commands/Copy/agents/
cp commands/Copy/agents/*.md .claude/commands/Copy/agents/
```

### Passo 2 — Criar Squad Copy
```bash
mkdir -p squads/copy/{tasks/plf,templates,checklists,data}
cp squads/copy/tasks/*.md squads/copy/tasks/
cp squads/copy/tasks/plf/*.md squads/copy/tasks/plf/
cp squads/copy/templates/*.md squads/copy/templates/
cp squads/copy/checklists/*.md squads/copy/checklists/
cp squads/copy/data/*.md squads/copy/data/
cp squads/copy/data/*.yaml squads/copy/data/
```

### Passo 3 — Verificar
```bash
# O copy-chief agent já existe em .claude/agents/copy-chief.md
# Ele referencia .claude/commands/Copy/agents/copy-chief.md → agora existe ✅
# Ele referencia squads/copy/tasks/ → agora existe ✅
# Ele referencia squads/copy/data/copywriting-kb.md → agora existe ✅
```

### Passo 4 — Testar
Usar Claude Code para testar:
```
@copy-chief diagnose → Deve carregar @eugene-schwartz
@copy-chief sales-page → Deve carregar task + selecionar copywriter
@copy-chief launch-plan → Deve carregar PLF pipeline completo
@copy-chief audit-copy → Deve executar Hopkins Audit 10 dimensões
@copy-chief sugarman-check → Deve validar 30 triggers
```

## Mapa de Integração

### Copy-Chief ↔ HackerVerso
```
HackerVerso Phase 4 (Steps 09-12) produz:
  → VSL script draft
  → Sales page structure
  → Upsell script
  → Order bump fascination

Copy-Chief recebe e EXECUTA:
  → @jon-benson finaliza VSL (vsl-script.md)
  → Auto-select finaliza sales page (create-sales-page.md)
  → @dan-kennedy finaliza upsell (create-upsell-page.md)
  → Hopkins Audit valida tudo (audit-copy-hopkins.md)
  → Sugarman 30 Triggers check final
```

### Copy-Chief ↔ Traffic-Masters (Fase 2 futura)
```
Copy-Chief produz:
  → Ad copy (create-ad-copy.md)
  → Headlines (create-headlines.md)
  → Landing pages (create-landing-page.md)

Traffic-Masters usa para:
  → Meta campaigns
  → Google campaigns
  → YouTube ads
```

### Copy-Chief ↔ Story-Chief (Fase 3 futura)
```
Story-Chief produz:
  → Brand story (brandscript)
  → Personal story
  → Pitch narratives

Copy-Chief integra nos:
  → Sales pages (story section)
  → VSLs (narrative arc)
  → Email sequences (soap opera)
```

## Tier System — Como Funciona

```
SEMPRE nesta ordem:

1. TIER 0 (Diagnóstico)
   @eugene-schwartz → Awareness level + Market sophistication
   @claude-hopkins → Scientific audit (score 85/100)

2. TIER 1-3 (Execução)
   Copywriter selecionado baseado no diagnóstico
   Task file executado step-by-step
   Output produzido

3. AUDIT (Tier 0 novamente)
   @claude-hopkins audita o output (Hopkins Score)
   Mínimo 85/100 para aprovar
   Se < 85 → revisão com feedback específico

4. TRIGGERS (Validação final)
   Sugarman 30 Triggers Check
   Mínimo 80% cobertura (24/30)
   Se < 80% → adicionar triggers faltando

5. APROVADO ✅
```

## Status do AIOS após este deploy

| Chief | Status |
|---|---|
| copy-chief | ✅ OPERACIONAL (55 arquivos) |
| HackerVerso (squad) | ✅ OPERACIONAL (41 arquivos) |
| traffic-masters-chief | ❌ Shell (Fase 2) |
| data-chief | ❌ Shell (Fase 2) |
| story-chief | ❌ Shell (Fase 3) |
| legal-chief | ❌ Shell (Fase 3) |
| design-chief | ❌ Shell (Fase 4) |
| cyber-chief | ❌ Shell (Fase 4) |
| db-sage | ❌ Shell (Fase 5) |
| design-system | ❌ Shell (Fase 5) |
| tools-orchestrator | ❌ Shell (Fase 5) |

**Próxima fase:** Traffic-Masters + Data-Chief
