# Knowledge Base: Metrics Frameworks

## AARRR (Pirate Metrics) — Sean Ellis
- **Acquisition:** traffic sources, CAC, impressions
- **Activation:** signup rate, onboarding completion, "aha moment" rate
- **Retention:** DAU/MAU, churn rate, cohort retention curves
- **Revenue:** ARPU, LTV, conversion rate, MRR
- **Referral:** NPS, viral coefficient, K-factor

## RFM — Peter Fader
- Recency (1-5): days since last purchase
- Frequency (1-5): total purchases in period
- Monetary (1-5): total spend in period
- Segments: Champions, Loyal, Potential, At Risk, Lost

## CLV Formulas
- Simple: (AOV × Purchase Frequency × Avg Lifespan)
- Contribution: CLV × Gross Margin %
- Predictive (BG/NBD): probabilistic model accounting for heterogeneity

## North Star Examples
| Business Type | North Star | Input Metrics |
|--------------|------------|---------------|
| Infoproduto | Aulas completadas | Enrollment, Engagement, Support |
| E-commerce | Monthly purchases per customer | Traffic, Conversion, AOV, Retention |
| SaaS | Weekly Active Users | Signup, Activation, Feature Usage |
| Community | Active Contributors | Members, Posts, Responses |
| Marketplace | Transactions completed | Supply, Demand, Match Rate |

## DMMM — Avinash Kaushik
Objective → Goals → KPIs → Targets → Segments
Every metric must pass: "So What?" and "Now What?"

## ICE Framework — Sean Ellis
Impact (1-10) × Confidence (1-10) × Ease (1-10) = ICE Score
Prioritize experiments by ICE Score (highest first).

## Health Score — Nick Mehta
Composite 0-100: Usage (30%) + Engagement (25%) + Results (25%) + Support (10%) + Payment (10%)
Green >80 | Yellow 50-79 | Red <50

## SPACES — David Spinks
Support, Product, Acquisition, Contribution, Engagement, Success

## CBC Metrics — Wes Kao
Completion Rate, Assignment Submission Rate, Outcome Achievement Rate, Applied Learning Rate (30d)
