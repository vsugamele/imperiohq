# Task: Growth Experiment — Design & Execute

## Metadata
- **Agent:** @sean-ellis
- **Tier:** 0

## Input
```yaml
required:
  - aarrr_bottleneck: "Qual estágio do AARRR é o bottleneck"
  - hypothesis: "O que acredita que vai melhorar?"
  - current_metric: "Métrica atual do bottleneck"
```

## Instruções

### Step 1 — Hypothesis
"Se fizermos [ação], então [métrica] vai [melhorar/aumentar] porque [razão]."

### Step 2 — ICE Score
| Criterio | Score (1-10) | Justificativa |
|----------|-------------|---------------|
| Impact | | |
| Confidence | | |
| Ease | | |
| **ICE** | **I×C×E** | |

### Step 3 — Experiment Design
- Control vs Treatment
- Sample size necessário
- Duration (mínimo 1-2 semanas)
- Success metric + guardrail metrics

### Step 4 — Execute
Run experiment, coletar dados.

### Step 5 — Analyze & Learn
- Resultado: Win / Lose / Inconclusive
- Learning: o que aprendemos?
- Next: o que fazemos agora?

## Output Schema
```yaml
experiment:
  hypothesis: ""
  ice: {impact: 0, confidence: 0, ease: 0, score: 0}
  design: {control: "", treatment: "", sample: "", duration: ""}
  result: {metric_before: "", metric_after: "", change: "", significant: true/false}
  learning: ""
  next_action: ""
```
