# Task: RFM Segmentation

## Metadata
- **Agent:** @peter-fader
- **Tier:** 0

## Input
```yaml
required:
  - transaction_data: "customer_id, date, amount (mínimo 6 meses)"
```

## Instruções

### Step 1 — Calcular R, F, M
- Recency: dias desde última compra
- Frequency: total de compras no período
- Monetary: valor total gasto

### Step 2 — Scoring (1-5 cada dimensão)
Quintis: dividir base em 5 grupos iguais por cada dimensão.

### Step 3 — Segmentos
| Segmento | RFM Pattern | Ação |
|----------|-------------|------|
| Champions | 555, 554, 545 | Recompensar, VIP |
| Loyal | x5x, x4x | Upsell, cross-sell |
| Potential | x3x, 3xx | Nurture, educar |
| At Risk | 2xx, x2x | Win-back campaign |
| Lost | 1xx, x1x | Reengajamento ou let go |

### Step 4 — Action Plan por Segmento

## Output Schema
```yaml
rfm:
  total_customers: X
  segments:
    - name: ""
      rfm_range: ""
      count: X
      pct: ""
      avg_clv: ""
      revenue_pct: ""
      action: ""
```
