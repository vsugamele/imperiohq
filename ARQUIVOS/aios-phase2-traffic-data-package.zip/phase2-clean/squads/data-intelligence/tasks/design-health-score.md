# Task: Design Health Score

## Metadata
- **Agent:** @nick-mehta
- **Tier:** 1

## Input
```yaml
required:
  - business_type: "infoproduto | SaaS | community | e-commerce"
  - available_data: "Quais dados estão disponíveis (usage, engagement, support, payment)"
```

## Instruções

### Step 1 — Definir Componentes
| Componente | Peso | Métrica | Scoring |
|-----------|------|---------|---------|
| Usage | 30% | Acesso/uso do produto | 0-100 |
| Engagement | 25% | Interação com marca | 0-100 |
| Results | 25% | Outcomes alcançados | 0-100 |
| Support | 10% | Tickets e resolução | 0-100 |
| Payment | 10% | Pagamento em dia | 0-100 |

### Step 2 — Definir Thresholds
- Green (80-100): Saudável
- Yellow (50-79): Atenção
- Red (0-49): Risco

### Step 3 — Mapear Churn Signals
Leading indicators que precedem churn em 30-60 dias.

### Step 4 — Definir Intervenções por Score

### Step 5 — Automation
Configurar alertas automáticos para score changes.

## Output Schema
```yaml
health_score:
  components: [{name: "", weight: "", metric: "", scoring_rules: ""}]
  thresholds: {green: ">80", yellow: "50-79", red: "<50"}
  churn_signals: [{signal: "", weight: "", lookback: ""}]
  interventions: [{score: "", action: "", owner: "", sla: ""}]
  automation: [{trigger: "", action: "", channel: ""}]
```
