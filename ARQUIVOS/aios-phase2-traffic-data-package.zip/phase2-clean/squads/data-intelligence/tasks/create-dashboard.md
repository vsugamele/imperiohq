# Task: Create Dashboard — DMMM Framework

## Metadata
- **Agent:** @avinash-kaushik
- **Tier:** 2

## Input
```yaml
required:
  - business_objectives: "Objetivos do negócio"
  - audience: "Quem vai usar o dashboard?"
  - available_tools: "Google Analytics, Mixpanel, custom, etc."
```

## Instruções

### Step 1 — DMMM
Para cada objetivo:
- Objective → Goals → KPIs → Targets → Segments

### Step 2 — So What Test
Para cada KPI proposto:
- "So what?" → Por que importa?
- "Now what?" → O que fazemos?
Se não responder → REMOVER.

### Step 3 — Dashboard Layout
1 página, 5-7 métricas, cada uma com:
- Valor atual
- Comparação (vs anterior, vs target)
- Trend (up/down/stable)
- Action trigger

### Step 4 — Update Frequency
Frequência de atualização = frequência de decisão.
- Diário: métricas operacionais (CPA, conversões)
- Semanal: métricas táticas (funnel metrics)
- Mensal: métricas estratégicas (CLV, NPS, cohorts)

## Output Schema
```yaml
dashboard:
  name: ""
  audience: ""
  metrics:
    - name: ""
      source: ""
      formula: ""
      target: ""
      so_what: ""
      now_what: ""
      frequency: ""
  layout: "description or wireframe"
  update: {frequency: "", owner: "", review_meeting: ""}
```
