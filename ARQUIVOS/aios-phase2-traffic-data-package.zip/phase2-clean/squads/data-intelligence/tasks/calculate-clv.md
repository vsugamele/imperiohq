# Task: Calculate CLV — Customer Lifetime Value

## Metadata
- **Agent:** @peter-fader
- **Tier:** 0

## Input
```yaml
required:
  - transaction_data: "Histórico de transações (customer_id, date, amount)"
  - time_period: "Período de dados disponíveis"
optional:
  - cost_data: "Custo de servir cada segmento"
  - acquisition_source: "Fonte de aquisição por cliente"
```

## Instruções

### Step 1 — CLV Simplificado
CLV = (Ticket Médio × Frequência Anual × Margem) / Churn Rate

### Step 2 — CLV por Segmento
Calcular CLV para cada segmento RFM.

### Step 3 — CLV vs CPA
Comparar CLV com CPA por canal de aquisição.
- CLV/CPA > 3: Investir agressivamente
- CLV/CPA 1.5-3: Investir com cautela
- CLV/CPA < 1.5: Otimizar ou cessar

### Step 4 — Recomendações
Baseado nos números, recomendar alocação de budget.

## Output Schema
```yaml
clv_analysis:
  overall: {avg_clv: "", median_clv: "", range: ""}
  by_segment: [{segment: "", clv: "", size: "", revenue_share: ""}]
  clv_vs_cpa: [{channel: "", clv: "", cpa: "", ratio: "", action: ""}]
  recommendations: []
```
