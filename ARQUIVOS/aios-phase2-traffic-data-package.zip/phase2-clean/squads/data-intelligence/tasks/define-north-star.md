# Task: Define North Star Metric

## Metadata
- **Agent:** @sean-ellis
- **Tier:** 0

## Input
```yaml
required:
  - business_model: "infoproduto | e-commerce | SaaS | serviço | community"
  - core_value: "Qual valor principal o produto entrega?"
  - current_metrics: "Métricas atualmente rastreadas"
```

## Instruções

### Step 1 — Identificar Core Value
O que faz o cliente VOLTAR? O que significa SUCESSO para o cliente?

### Step 2 — Candidatas a North Star
Listar 3-5 métricas candidatas e avaliar contra critérios:
1. Reflete valor para o cliente? (não vanity)
2. Leading indicator de receita?
3. Equipe pode influenciar diretamente?
4. Mensurável com frequência regular?

### Step 3 — Definir Operacionalmente
- Nome exato da métrica
- Fórmula de cálculo
- Fonte dos dados
- Frequência de medição
- Target atual e desejado

### Step 4 — Input Metrics
Quais métricas ALIMENTAM a North Star?
North Star = f(input_1, input_2, input_3)

## Output Schema
```yaml
north_star:
  metric: ""
  definition: ""
  formula: ""
  current_value: ""
  target: ""
  input_metrics: [{name: "", influence: "", owner: ""}]
  measurement: {source: "", frequency: "", dashboard: ""}
```
