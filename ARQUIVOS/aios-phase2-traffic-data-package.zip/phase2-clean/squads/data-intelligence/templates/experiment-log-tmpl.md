# Template: Experiment Log

## Experiment #{number}

| Field | Value |
|-------|-------|
| **Name** | {experiment_name} |
| **Date** | {start_date} → {end_date} |
| **AARRR Stage** | {acquisition/activation/retention/revenue/referral} |
| **Hypothesis** | If {action}, then {metric} will {change} because {reason} |
| **ICE Score** | I:{X} C:{X} E:{X} = {total} |

### Design
- **Control:** {what_stays_the_same}
- **Treatment:** {what_changes}
- **Sample:** {size_needed}
- **Duration:** {weeks}
- **Primary metric:** {metric} (current: {X}, target: {Y})
- **Guardrails:** {metrics_that_should_NOT_change}

### Results
- **Primary metric:** {before} → {after} ({change}%)
- **Significant?** Yes/No (p-value: {X})
- **Guardrails:** {all_stable?}

### Decision
- **Outcome:** Win / Lose / Inconclusive
- **Learning:** {what_we_learned}
- **Next action:** {ship_it / iterate / try_different_approach}

---
*Log every experiment. Losers teach as much as winners.*
