# Template: Metrics Dictionary

## Format per Metric

| Field | Value |
|-------|-------|
| **Name** | {metric_name} |
| **Definition** | {what_it_measures} |
| **Formula** | {calculation} |
| **Source** | {data_source} |
| **Frequency** | {how_often_measured} |
| **Owner** | {who_is_responsible} |
| **Target** | {target_value} |
| **So What** | {why_it_matters} |
| **Now What** | {action_if_above_target / action_if_below_target} |
| **Related** | {related_metrics} |

## Categories
- **North Star:** {north_star_metric}
- **AARRR:** Acquisition, Activation, Retention, Revenue, Referral
- **Health:** Customer Health Score components
- **Financial:** CLV, CPA, ROAS, Revenue, Margin

## Rules
- Every metric has an owner
- Every metric has an action
- If no action → remove from dictionary
- Review dictionary quarterly
