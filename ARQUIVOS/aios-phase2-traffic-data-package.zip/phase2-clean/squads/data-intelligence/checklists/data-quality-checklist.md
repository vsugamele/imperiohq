# Checklist: Data Quality

## Before Analysis
- [ ] Data source identified and documented
- [ ] Date range defined
- [ ] Sample size sufficient for conclusions
- [ ] Missing data quantified (<5% acceptable)
- [ ] Outliers identified and handled
- [ ] Duplicates removed

## During Analysis
- [ ] Metrics operationally defined (formula documented)
- [ ] Comparison baseline established (vs period, vs target, vs benchmark)
- [ ] Segments applied where relevant
- [ ] Correlation ≠ Causation acknowledged
- [ ] Statistical significance checked for experiments

## Before Reporting
- [ ] "So What" test passed for every metric
- [ ] Visualizations clear and not misleading
- [ ] Actionable recommendations included
- [ ] Limitations and caveats noted
- [ ] Owner and review cadence defined
