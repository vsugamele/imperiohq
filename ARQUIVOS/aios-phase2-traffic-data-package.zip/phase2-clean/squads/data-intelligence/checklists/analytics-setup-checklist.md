# Checklist: Analytics Setup

## Foundation
- [ ] North Star Metric defined
- [ ] AARRR metrics mapped
- [ ] Metrics dictionary created
- [ ] Data sources inventoried

## Tracking
- [ ] Website analytics configured (GA4 / Mixpanel / etc.)
- [ ] Conversion events defined and tracked
- [ ] UTM convention defined and documented
- [ ] Cross-platform tracking configured
- [ ] Server-side tracking if needed (iOS 14+)

## Dashboards
- [ ] Executive dashboard (monthly, strategic)
- [ ] Marketing dashboard (weekly, tactical)
- [ ] Operations dashboard (daily, operational)
- [ ] Each dashboard passes So What test

## Experiments
- [ ] Experiment process defined (ICE → Test → Learn)
- [ ] Experiment log template created
- [ ] Statistical significance calculator available
- [ ] Experiment review cadence defined (weekly/bi-weekly)

## Team
- [ ] Analytics owner defined
- [ ] Dashboard review cadence defined
- [ ] Data literacy baseline for team
