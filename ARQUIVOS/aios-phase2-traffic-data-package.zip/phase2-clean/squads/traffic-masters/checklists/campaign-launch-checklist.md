# Checklist: Campaign Launch

## Pre-Launch
- [ ] Avatar profile definido
- [ ] Plataforma selecionada com justificativa
- [ ] Budget alocado (60/20/20)
- [ ] KPIs definidos (CPA, ROAS, CTR targets)
- [ ] Landing page live e testada (mobile + desktop)
- [ ] Message match (ad headline = LP headline)

## Creative
- [ ] Ad Grid 3×3 preenchido (9 variações mínimo)
- [ ] Hook Library com 5+ hooks
- [ ] Copy revisado pelo copy-chief (se disponível)
- [ ] Formatos corretos por plataforma
- [ ] Thumbnails testados (se YouTube)

## Tracking
- [ ] Pixel/tag instalado e verificado
- [ ] Conversions configuradas
- [ ] UTMs em todos os links
- [ ] Google Analytics / Meta Events configurados
- [ ] Relatório de performance template pronto

## Campaign Setup
- [ ] Estrutura de campanha conforme framework
- [ ] Audiências configuradas (custom, lookalike, interest, broad)
- [ ] Bid strategy definida
- [ ] Placement configurado
- [ ] Budget distribuído corretamente

## Retargeting
- [ ] Audiências de retarget criadas
- [ ] Ads de retarget prontos (objection, social proof, urgency)
- [ ] Frequency cap definido

## Go/No-Go
```
Pre-Launch: ___/6 ✅
Creative: ___/5 ✅
Tracking: ___/5 ✅
Setup: ___/5 ✅
Retarget: ___/3 ✅

≥20: GO
15-19: GO com monitoring intensivo
<15: NO-GO — resolver issues
```
