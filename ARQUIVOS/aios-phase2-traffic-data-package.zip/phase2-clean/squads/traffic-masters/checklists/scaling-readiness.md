# Checklist: Scaling Readiness (DPI²)

## Diagnose (todos devem ser ✅)
- [ ] CPA estável (variação <15%) por 7+ dias
- [ ] ROAS acima do target por 7+ dias
- [ ] 50+ conversões por semana
- [ ] Frequency < 3 (não saturado)
- [ ] Nenhum sinal de creative fatigue (CTR estável)

## Prepare
- [ ] 5+ criativos NOVOS prontos para launch
- [ ] Audiências expandidas mapeadas (próximo layer)
- [ ] Landing page otimizada (speed <3s, mobile score >80)
- [ ] Infra/servidor suporta 2-3x tráfego atual
- [ ] Budget adicional aprovado

## Risk Management
- [ ] CPA ceiling definido (pausa automática se ultrapassar)
- [ ] Rollback plan (como voltar ao budget anterior)
- [ ] Alerta configurado para anomalias
- [ ] Review schedule (diário na primeira semana de escala)

## Go/No-Go
```
Diagnose: ___/5 ✅ (TODOS obrigatórios)
Prepare: ___/5 ✅
Risk: ___/4 ✅

Diagnose = 5/5 E Prepare ≥ 4 E Risk ≥ 3: SCALE
Qualquer Diagnose ❌: NÃO ESCALAR — otimizar primeiro
```
