# Template: Campaign Brief

## Campaign Info
- **Name:** {campaign_name}
- **Platform:** {meta | google | youtube}
- **Objective:** {lead_gen | sales | awareness}
- **Budget:** R${daily}/dia (R${monthly}/mês)
- **Duration:** {start_date} → {end_date}

## Target Audience
- **Avatar:** {avatar_summary}
- **Platform behavior:** {where, when, how they use platform}
- **Targeting:** {interests, lookalikes, custom audiences}

## Creative Direction
- **Key message:** {one_sentence_message}
- **Hook approach:** {pattern_interrupt | curiosity | result}
- **Tone:** {aligned_with_brand_voice}
- **Visual:** {style_description}
- **CTA:** {action_text}

## Landing Page
- **URL:** {landing_url}
- **Message match:** Headline = {ad_headline_match}
- **Conversion action:** {form_submit | purchase | schedule}

## KPIs
- **CPA target:** R${cpa}
- **ROAS target:** {roas}x
- **CTR target:** >{ctr}%
- **Daily conversions target:** {conversions}

## Approval
- [ ] Creative approved
- [ ] Landing page tested (mobile + desktop)
- [ ] Tracking configured (pixel, UTMs)
- [ ] Budget approved
