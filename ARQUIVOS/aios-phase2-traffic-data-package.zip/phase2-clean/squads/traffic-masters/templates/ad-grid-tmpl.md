# Template: Ad Grid 3×3 — Matriz de Testes

## Grid Structure

| | Hook A: {pattern_interrupt} | Hook B: {curiosity} | Hook C: {result} |
|---|---|---|---|
| **Static Image** | V1: img + hook A | V2: img + hook B | V3: img + hook C |
| **Video <15s** | V4: vid + hook A | V5: vid + hook B | V6: vid + hook C |
| **Carousel** | V7: car + hook A | V8: car + hook B | V9: car + hook C |

## Testing Budget
- Per variation: R${budget_per_variation}/dia
- Duration: 3 dias mínimo
- Total test budget: 9 × R${budget} × 3 = R${total}

## Win/Kill Criteria
| Métrica | Win | Kill |
|---------|-----|------|
| CTR | >1.5% | <0.8% |
| CPC | <R${target_cpc} | >R${target_cpc × 2} |
| CPA | <R${target_cpa} | >R${target_cpa × 1.5} |

## After Testing
- Top 3 → Scale (+20% budget each 3 days)
- Middle 3 → Iterate (new body/CTA, keep hook)
- Bottom 3 → Kill
