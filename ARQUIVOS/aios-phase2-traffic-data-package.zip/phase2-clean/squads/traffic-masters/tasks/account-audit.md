# Task: Account Audit — Diagnóstico de Conta de Tráfego

## Metadata
- **Agent:** @molly-pittman + platform specialist
- **Tier:** 0 (diagnóstico)

## Input
```yaml
required:
  - platform: "meta | google | youtube | multi"
  - monthly_budget: "Budget mensal atual"
  - current_kpis: {cpa: "", roas: "", ctr: "", cpc: ""}
  - target_kpis: {cpa_target: "", roas_target: ""}
```

## Instruções

### Step 1 — Traffic Engine Check (9 pontos)
Avaliar cada passo do Traffic Engine (0-10 cada):
1. Avatar definido?
2. Customer Journey mapeado?
3. Plataforma correta?
4. Before State documentado?
5. After State documentado?
6. Ad Grid com variações?
7. Landing page com message match?
8. Retargeting engine ativo?
9. Protocolo de escala definido?

### Step 2 — Platform-Specific Audit
Delegar ao platform master relevante.

### Step 3 — Diagnóstico
Classificar: STRUCTURAL | CREATIVE | TARGETING | OFFER | TECHNICAL

### Step 4 — Plano de Ação (imediato, 30 dias, 90 dias)

## Output Schema
```yaml
account_audit:
  traffic_engine_score: 0-90
  platform_audit: {platform: "", findings: []}
  diagnosis:
    primary_issue: "structural | creative | targeting | offer | technical"
    secondary_issues: []
  action_plan:
    immediate: []
    short_term: []
    long_term: []
```

## Quality Gate
- [ ] 9 pontos do Traffic Engine avaliados
- [ ] Platform-specific audit delegado
- [ ] Causa raiz identificada
- [ ] Plano de ação priorizado
