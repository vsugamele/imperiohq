# Task: Traffic Engine Setup — Configuração Completa

## Metadata
- **Agent:** @molly-pittman
- **Tier:** 0
- **depends_on:** Avatar profile (HackerVerso)

## Input
```yaml
required:
  - avatar_profile: "Output do HackerVerso"
  - product_details: "Produto, preço, value ladder"
  - budget: "Budget mensal"
  - platform_preference: "meta | google | youtube | undecided"
```

## Instruções

### 9 Steps do Traffic Engine

**Step 1 — Avatar → Targeting:** Traduzir avatar em segmentação (plataformas, keywords, influencers, conteúdo)

**Step 2 — Customer Journey Map:** Awareness → Evaluation → Conversion com métricas por estágio

**Step 3 — Platform Selection:** 1 plataforma principal + 1 retarget. Regra: dominar 1 antes de diversificar.

**Step 4 — Before State:** O que sente, pensa, busca ANTES

**Step 5 — After State:** O que sente, pensa, tem DEPOIS

**Step 6 — Ad Grid (3x3):** 3 hooks × 3 formatos = 9 variações mínimas

**Step 7 — Landing Page:** Message match obrigatório (ad = LP headline)

**Step 8 — Retargeting Engine:** Audiências por ação (visitou, assistiu, abandonou)

**Step 9 — Scale Protocol:** Critérios de scale up (+20% cada 3-4 dias) e scale down

## Output Schema
```yaml
traffic_engine:
  avatar_targeting: {platforms: [], keywords: [], influencers: []}
  journey_map: {awareness: {}, evaluation: {}, conversion: {}}
  primary_platform: ""
  before_after: {before: {}, after: {}}
  ad_grid: {hooks: [], formats: [], total: 9}
  budget: {acquisition: "60%", retarget: "20%", conversion: "20%"}
  kpis: {cpa: "", roas: "", ctr: "", cpl: ""}
  retarget_audiences: []
  scale_protocol: {up: "+20% each 3-4 days", down: "pause if CPA >25% above target"}
```

## Quality Gate
- [ ] 9 steps completos
- [ ] KPIs definidos ANTES de lançar
- [ ] Budget 60/20/20
- [ ] Ad Grid com 9 variações
