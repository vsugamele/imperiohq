# Task: Creative Optimization — Creative Lab

## Metadata
- **Agent:** @ralph-burns
- **Tier:** 2

## Input
```yaml
required:
  - product: "Produto"
  - avatar_profile: "Avatar"
  - platform: "meta | google | youtube"
```

## Instruções

### 7 Steps
1. **Research Sprint:** Mirror words, competitor ads, top razões de compra/objeções
2. **Hook Library (20+):** Pattern interrupt, curiosidade, resultado, contrarian, social proof
3. **Body Frameworks:** PAS, AIDA, BAB para cada hook
4. **CTA Variations (5):** Direct, Curiosity, Benefit, Urgency, Social
5. **Format Matrix:** hooks × formatos (static, carousel, video short/med, UGC)
6. **Testing Protocol:** $5-10/variação × 3 dias, win/kill criteria
7. **Refresh Cycle:** A cada 2-3 semanas

## Output Schema
```yaml
creative_lab:
  hooks: [{category: "", text: ""}]  # 20+
  bodies: [{hook_ref: "", framework: "", text: ""}]
  ctas: [{type: "", text: ""}]  # 5
  matrix: {total_variations: X}
  testing: {budget: "", duration: "", criteria: {}}
  refresh: "every 2-3 weeks"
```
