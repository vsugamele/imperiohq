# Task: Traffic Strategy — Estratégia BPM Multi-Plataforma

## Metadata
- **Agent:** @depesh-mandalia
- **Tier:** 0

## Input
```yaml
required:
  - traffic_engine: "Output do traffic-engine-setup"
  - business_model: "e-commerce | infoproduto | SaaS | serviço | launch"
  - monthly_budget: "Budget total"
```

## Instruções

### Step 1 — BPM Foundation
Brand POV + Voice + Promise + Story (integrar com HackerVerso positioning)

### Step 2 — Platform Mix
Definir % de budget por plataforma com justificativa.

### Step 3 — Creative Strategy (4 Pillars)
Education, Entertainment, Emotion, Evidence — exemplos para cada.

### Step 4 — Audience Architecture (4 Layers)
Layer 1 (1%): hyper-engaged → Layer 4 (79%): cold broad

### Step 5 — Scaling Protocol (3 Levers)
Budget, Audiences, Creatives — 1 por vez.

## Output Schema
```yaml
traffic_strategy:
  bpm: {pov: "", voice: "", promise: ""}
  platform_mix: [{platform: "", pct: "", objective: ""}]
  creative_pillars: {education: [], entertainment: [], emotion: [], evidence: []}
  audience_layers: [{layer: 1, size: "", targeting: ""}]
  scaling: {levers: ["budget", "audiences", "creatives"]}
  timeline: {month_1: "", month_2: "", month_3: ""}
```
