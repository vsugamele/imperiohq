# Task: Brasil Strategy — Tráfego Mercado Brasileiro

## Metadata
- **Agent:** @pedro-sobral
- **Tier:** 2

## Input
```yaml
required:
  - business_type: "infoproduto | e-commerce | serviço | launch"
  - product_price: "R$"
  - payment_methods: "cartão | boleto | pix | todos"
```

## Instruções

### Metodologia ABC
**A (Audiência):** Quente (engajamento IG, lista), Morno (lookalike 1-3%), Frio (interesses), Aberto (broad — funciona MUITO bem no BR).

**B (Budget):** Perpétuo = 70/20/10. Lançamento = 15% pre-prelaunch, 25% PLCs, 60% cart open.

**C (Criativo):** Vídeo curto Reels/Stories dominante. Humor > produção. Autenticidade > polish. Linguagem BR.

### Particularidades
- CPA real = CPA × 1.2 (ajuste boleto/inadimplência 15-30%)
- Mobile: 90%+ — TUDO mobile-first
- Pico: 20h-23h
- 70% das vendas de lançamento nos últimos 3 dias
- Testar público aberto SEMPRE (algoritmo Meta forte no BR)

### Rotina Operacional
Diária: 8h métricas, 9h budgets, 10h kill losers, 14h check, 17h análise, 20h peak check.
Semanal: seg review, ter-qua criativos, qui mid-review, sex otimizar pra weekend.

## Output Schema
```yaml
brasil:
  abc: {audiencia: {}, budget: {}, criativo: {}}
  cpa_adjustment: "×1.2 (boleto)"
  peak_hours: "20h-23h"
  rotina: {diaria: [], semanal: []}
```
