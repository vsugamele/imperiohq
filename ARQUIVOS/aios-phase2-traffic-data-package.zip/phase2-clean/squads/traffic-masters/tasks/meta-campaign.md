# Task: Meta Campaign — Campanha Facebook/Instagram

## Metadata
- **Agent:** @nicholas-kusmich (lead gen) / @depesh-mandalia (brand)
- **Tier:** 1

## Input
```yaml
required:
  - objective: "lead_gen | sales | awareness"
  - budget_daily: "Budget diário"
  - creatives: "Criativos OU briefing"
  - landing_page: "URL"
```

## Instruções

### Step 1 — Campaign Structure
5 Ad Sets: Lookalike 1% (customers), Lookalike 1% (email), Interest A, Interest B, Broad.
3 Ads por Ad Set (Video, Image, Carousel).

### Step 2 — Configuration
CBO, automatic placement, conversion optimization.

### Step 3 — Creative Specs
Feed 1080x1080/1350, Stories 1080x1920, Video <60s com caption.

### Step 4 — Testing Protocol
$5-10/ad set/dia × 3 dias. Win: CTR >1.5%, CPC < target.

### Step 5 — Retargeting
Custom Audience: visitors 7d/14d/30d, IG engagement, video viewers.

## Output Schema
```yaml
meta_campaign:
  structure: {ad_sets: [], ads_per_set: 3}
  config: {optimization: "CBO", placement: "automatic"}
  testing: {budget: "", duration: "3 days", criteria: {}}
  retarget: [{audience: "", trigger: ""}]
```
