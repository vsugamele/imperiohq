# Task: Scaling Strategy — DPI² Protocol

## Metadata
- **Agent:** @ralph-burns + @depesh-mandalia
- **Tier:** 2
- **depends_on:** 7+ dias de resultados positivos

## Input
```yaml
required:
  - current_metrics: {cpa: "", roas: "", daily_budget: ""}
  - target: {revenue_target: "", timeline: ""}
```

## Instruções

### DPI² Method

**Diagnose:** CPA estável 7d? ROAS acima target 7d? 50+ conversões/semana? Frequency <3?

**Prepare:** 5+ criativos novos, audiências expandidas, LP otimizada, infra pronta.

**Increase:** +20% cada 3-4 dias. Se CPA sobe >25% → pausar 5 dias. Se estabiliza → continuar.

**Iterate:** Criativos novos a cada 2 semanas. Audiências a cada mês. Check 3 Deaths (Creative Fatigue, Audience Saturation, Offer Decay).

## Output Schema
```yaml
scaling:
  readiness: {passed: true/false, blockers: []}
  schedule: [{week: X, action: "", budget: ""}]
  iterate: {creative_refresh: "2 weeks", audience_refresh: "monthly"}
  risk: {cpa_ceiling: "", pause_trigger: ""}
```
