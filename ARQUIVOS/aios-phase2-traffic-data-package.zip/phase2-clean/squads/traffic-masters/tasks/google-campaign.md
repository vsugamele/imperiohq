# Task: Google Campaign — Setup Google Ads

## Metadata
- **Agent:** @kasim-aslam
- **Tier:** 1

## Input
```yaml
required:
  - business_type: "e-commerce | lead-gen | saas | local"
  - budget_monthly: "Budget mensal"
  - target_cpa: "CPA target"
```

## Instruções

### Step 1 — Account Structure (Golden Ratio)
60% BoF (Search Brand + High Intent + Shopping), 20% MoF (Display/YouTube Retarget), 20% ToF (Prospecting)

### Step 2 — Keyword Research
Seed keywords → expansion → categorize (commercial, informational) → negative keywords (100+ no dia 1)

### Step 3 — Ad Creation
3 RSAs por ad group, 15 headlines, 4 descriptions, all extensions.

### Step 4 — Bidding
Start: Manual CPC → After 30 conversions: Target CPA/ROAS

### Step 5 — Quality Score
Target QS ≥ 7: ad relevance + LP experience + expected CTR

## Output Schema
```yaml
google_campaign:
  structure: {bof: "60%", mof: "20%", tof: "20%"}
  campaigns: [{name: "", type: "", keywords: []}]
  negatives: []
  ads: [{headlines: [], descriptions: []}]
  bidding: {initial: "manual_cpc", target: "target_cpa"}
```
