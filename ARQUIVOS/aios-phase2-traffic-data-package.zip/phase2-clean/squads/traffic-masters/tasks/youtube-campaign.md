# Task: YouTube Campaign — Setup YouTube Ads

## Metadata
- **Agent:** @tom-breeze
- **Tier:** 1

## Input
```yaml
required:
  - objective: "awareness | consideration | conversion"
  - video_script: "Script ADUCATE ou vídeo pronto"
  - budget_daily: "Budget diário"
```

## Instruções

### Step 1 — ADUCATE Check
Verificar 7 elementos: Aim (5s hook), Difficulty, Understanding, Credibility, Action Plan, Teach, Exit (CTA).

### Step 2 — Campaign Types
Awareness → Bumper + In-Stream. Consideration → Discovery. Conversion → TrueView for Action.

### Step 3 — Targeting
Custom Intent (keywords Google), Affinity, In-Market, Placements (canais específicos), Retarget.

### Step 4 — Testing
3-5 thumbnails, 2-3 hooks. R$50-100/dia × 5 dias por variação.

## Output Schema
```yaml
youtube_campaign:
  aducate: {complete: true/false, missing: []}
  type: ""
  targeting: {custom_intent: [], placements: []}
  testing: {thumbnails: X, hooks: X, budget: ""}
```
