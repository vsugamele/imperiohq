# Benchmarks de Tráfego — Mercado Brasil (2024-2025)

## Meta (Facebook/Instagram)

### CPL (Custo por Lead)
| Nicho | CPL Médio | CPL Bom | CPL Excelente |
|-------|----------|---------|---------------|
| Infoproduto | R$3-8 | R$2-3 | <R$2 |
| E-commerce | R$1-4 | R$0.50-1 | <R$0.50 |
| B2B/Serviço | R$8-25 | R$5-8 | <R$5 |
| Saúde/Fitness | R$2-6 | R$1-2 | <R$1 |
| Finanças | R$5-15 | R$3-5 | <R$3 |

### CPA (Custo por Aquisição)
| Ticket | CPA Médio | CPA Bom |
|--------|----------|---------|
| Low (<R$100) | R$20-50 | R$10-20 |
| Mid (R$100-500) | R$50-150 | R$30-50 |
| High (R$500-2000) | R$150-500 | R$80-150 |
| Premium (>R$2000) | R$300-1000 | R$150-300 |

### CTR
- Feed: 1-2% (bom >1.5%)
- Stories: 0.5-1.5% (bom >1%)
- Reels: 1-3% (bom >2%)

## Google Ads
| Tipo | CPC Médio BR | CTR Médio |
|------|-------------|-----------|
| Search Brand | R$0.30-1.00 | 5-15% |
| Search Non-Brand | R$1.00-5.00 | 2-5% |
| Shopping | R$0.20-1.50 | 1-3% |
| Display | R$0.10-0.50 | 0.3-0.8% |

## YouTube
| Formato | CPV Médio | View Rate |
|---------|----------|-----------|
| In-Stream (skip) | R$0.03-0.10 | 15-30% |
| Bumper (6s) | R$0.01-0.05 | 90%+ |
| Discovery | R$0.05-0.15 | 3-8% |

## Ajustes Brasil
- Boleto: adicionar 15-30% ao CPA (inadimplência)
- PIX: melhor conversão que cartão (sem fricção)
- Parcelamento: aumenta conversão 20-40% em tickets >R$200
- Mobile: 90%+ do tráfego — TUDO mobile-first
- Pico: 20h-23h (volume + conversão mais altos)
