# BRIEFING: Phase 2 — Traffic-Masters + Data-Chief

## O Que Este Pacote Contém

**40 arquivos** que completam os chiefs de tráfego e dados.

### Traffic-Masters (22 arquivos)

| Categoria | Qtd | Descrição |
|---|---|---|
| Agents | 8 | Chief + 7 specialists (Pittman, Mandalia, Kusmich, Aslam, Breeze, Burns, Sobral) |
| Tasks | 9 | Account audit, traffic engine, BPM strategy, Meta/Google/YouTube campaigns, scaling, creative lab, Brasil strategy |
| Templates | 2 | Ad Grid 3×3, Campaign Brief |
| Checklists | 2 | Campaign Launch, Scaling Readiness (DPI²) |
| Data | 1 | Platform Benchmarks Brasil (CPL, CPA, CTR por nicho) |

**Tier System:**
- T0 Strategy: @molly-pittman (Traffic Engine 9 steps) + @depesh-mandalia (BPM Method)
- T1 Platform: @nicholas-kusmich (Meta) + @kasim-aslam (Google) + @tom-breeze (YouTube)
- T2 Execution: @ralph-burns (Creative Lab + DPI² Scaling) + @pedro-sobral (Brasil/ABC)

### Data-Chief (18 arquivos)

| Categoria | Qtd | Descrição |
|---|---|---|
| Agents | 7 | Chief + 6 specialists (Fader, Ellis, Mehta, Spinks, Kao, Kaushik) |
| Tasks | 6 | CLV calculation, RFM segmentation, North Star, Growth experiments, Health Score, Dashboard |
| Templates | 2 | Metrics Dictionary, Experiment Log |
| Checklists | 2 | Data Quality, Analytics Setup |
| Data | 1 | Metrics Frameworks KB (AARRR, RFM, CLV, DMMM, ICE, SPACES) |

**Tier System:**
- T0 Fundamentação: @peter-fader (CLV/RFM) + @sean-ellis (AARRR/North Star/Growth)
- T1 Operacionalização: @nick-mehta (Churn) + @david-spinks (Community) + @wes-kao (Learning)
- T2 Comunicação: @avinash-kaushik (Attribution/Dashboards)

## Deploy

```bash
# No repo aios-core

# Traffic agents
mkdir -p .claude/commands/Traffic/agents/
cp commands/Traffic/agents/*.md .claude/commands/Traffic/agents/

# Data agents
mkdir -p .claude/commands/Data/agents/
cp commands/Data/agents/*.md .claude/commands/Data/agents/

# Traffic squad
cp -r squads/traffic-masters/ squads/traffic-masters/

# Data squad
cp -r squads/data-intelligence/ squads/data-intelligence/
```

## Testar

```bash
# Traffic
@traffic-masters-chief account-audit → Deve carregar @molly-pittman
@traffic-masters-chief meta-campaign → Deve rotear @nicholas-kusmich + @ralph-burns
@traffic-masters-chief brasil → Deve carregar @pedro-sobral

# Data
@data-chief north-star → Deve carregar @sean-ellis
@data-chief clv → Deve carregar @peter-fader
@data-chief dashboard → Deve carregar @avinash-kaushik
```

## Integração

```
HackerVerso (strategy) → Copy-Chief (copy) → Traffic-Masters (distribution)
                                                    ↓
                                              Data-Chief (measurement)
                                                    ↓
                                              [Feedback loop to all]
```

## Status AIOS

| Chief | Status | Arquivos |
|---|---|---|
| HackerVerso | ✅ | 41 |
| Copy-Chief | ✅ | 55 |
| Traffic-Masters | ✅ | 22 |
| Data-Chief | ✅ | 18 |
| Story-Chief | ❌ Fase 3 | ~30 |
| Legal-Chief | ❌ Fase 3 | ~25 |
| Design-Chief | ❌ Fase 4 | ~25 |
| Cyber-Chief | ❌ Fase 4 | ~25 |
| DB-Sage | ❌ Fase 5 | ~45 |
| Design-System | ❌ Fase 5 | ~35 |
| Tools-Orchestrator | ❌ Fase 5 | ~20 |

**Total entregue: 136 arquivos (4/11 chiefs operacionais)**
