# Task: API Security Setup

## Metadata
- **Agent:** @api-security
- **Tier:** 2

## Input
```yaml
required:
  - api_type: "REST | GraphQL"
  - auth_method: "JWT | OAuth2 | API Key"
  - endpoints: "Lista de endpoints principais"
```

## Instruções

### Step 1 — Authentication Setup
Configurar auth method escolhido com best practices.

### Step 2 — Authorization (RBAC)
Definir roles e permissions por endpoint.

### Step 3 — Rate Limiting
Configurar limites por tier (anonymous, auth, premium).

### Step 4 — Input Validation
Para cada endpoint: validar inputs, sanitize, type check.

### Step 5 — Security Headers + CORS
Headers obrigatórios + CORS restritivo.

## Output Schema
```yaml
api_security:
  auth: {method: "", config: {}}
  rbac: [{role: "", endpoints: [{path: "", methods: []}]}]
  rate_limits: [{tier: "", limit: "", window: ""}]
  validation: [{endpoint: "", params: [{name: "", type: "", validation: ""}]}]
  headers: [{header: "", value: ""}]
  cors: {origins: [], methods: [], credentials: true/false}
```
