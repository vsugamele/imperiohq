# Task: Backup & Recovery Plan

## Metadata
- **Agent:** @cloud-architect + @incident-responder
- **Tier:** 2

## Input
```yaml
required:
  - systems: "Quais sistemas precisam de backup"
  - rpo: "Quanto dado posso perder (horas)"
  - rto: "Quanto tempo posso ficar down (horas)"
```

## Instruções

### Step 1 — RPO/RTO Analysis
| Sistema | RPO | RTO | Backup Frequency | Recovery Method |
|---------|-----|-----|-------------------|----------------|

### Step 2 — Backup Strategy
- Database: automated snapshots + WAL archiving
- Files: incremental backup to separate region
- Code: Git (inherently backed up)
- Config: Infrastructure as Code (versioned)

### Step 3 — Recovery Procedures
Runbook para cada cenário de recovery.

### Step 4 — Testing Schedule
- Monthly: verify backup integrity
- Quarterly: full recovery drill
- Annually: disaster recovery simulation

## Output Schema
```yaml
backup_recovery:
  systems: [{name: "", rpo: "", rto: "", backup: "", recovery: ""}]
  schedule: {backup_frequency: "", test_frequency: ""}
  procedures: [{scenario: "", steps: [], estimated_time: ""}]
```
