# Task: Incident Response Plan

## Metadata
- **Agent:** @incident-responder
- **Tier:** 2

## Input
```yaml
required:
  - business_type: "tipo de negócio"
  - critical_systems: "sistemas mais críticos"
  - team_contacts: "quem é responsável"
```

## Instruções

### Step 1 — Severity Matrix
Definir SEV1, SEV2, SEV3 com critérios específicos.

### Step 2 — Response Procedures (6 Phases)
Para cada severity: Preparation → Identification → Containment → Eradication → Recovery → Lessons Learned.

### Step 3 — Communication Templates
- Internal: "Incidente detectado em [sistema]. Severity: [X]. Status: [investigating/mitigating/resolved]."
- External (se data breach): notificação ANPD + titulares.

### Step 4 — Runbooks
Runbooks para cenários comuns:
- Site down, database corruption, data breach, DDoS, compromised credentials.

### Step 5 — Post-Mortem Template

## Output Schema
```yaml
incident_plan:
  severity: [{level: "", criteria: "", sla: "", escalation: ""}]
  procedures: [{phase: 1-6, actions: [], owner: ""}]
  communication: {internal: "", external: ""}
  runbooks: [{scenario: "", steps: []}]
  contacts: [{role: "", name: "", phone: "", escalation_order: X}]
```
