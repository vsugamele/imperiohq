# Task: Infrastructure Setup

## Metadata
- **Agent:** @cloud-architect + @devops-engineer
- **Tier:** 1

## Input
```yaml
required:
  - project_type: "web app | API | SaaS | e-commerce | infoproduto"
  - scale: "MVP | growing | established"
  - budget: "monthly cloud budget"
  - team_size: "1 | 2-5 | 5+"
```

## Instruções

### Step 1 — Stack Selection (@cloud-architect)
Recomendar stack baseado em projeto + escala + budget.

### Step 2 — Architecture Diagram
Desenhar arquitetura com todas as camadas.

### Step 3 — CI/CD Pipeline (@devops-engineer)
Configurar pipeline de deploy automatizado.

### Step 4 — Monitoring Setup
Métricas, logs, alertas, uptime.

### Step 5 — Security Baseline
- HTTPS everywhere
- Secrets in vault
- Backups automated
- Access control configured

## Output Schema
```yaml
infrastructure:
  stack: [{layer: "", service: "", provider: "", cost: ""}]
  architecture: "description"
  pipeline: {stages: [], tool: ""}
  monitoring: {metrics: "", logs: "", alerts: []}
  security: {https: true, secrets: "", backups: "", access: ""}
  cost_estimate: {monthly: "", breakdown: []}
```
