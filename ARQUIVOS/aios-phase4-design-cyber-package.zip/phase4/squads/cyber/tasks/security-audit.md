# Task: Security Audit — OWASP Top 10

## Metadata
- **Agent:** @owasp-sentinel
- **Tier:** 0

## Input
```yaml
required:
  - target: "URL / app / API"
  - type: "web app | API | mobile app | infrastructure"
  - tech_stack: "Technologies used"
```

## Instruções

### Step 1 — OWASP Top 10 Check
Avaliar cada item A01-A10 com status: pass | fail | partial.

### Step 2 — Security Headers Check
- Strict-Transport-Security (HSTS)
- Content-Security-Policy (CSP)
- X-Content-Type-Options
- X-Frame-Options
- Referrer-Policy
- Permissions-Policy

### Step 3 — Dependency Scan
Verificar dependências com CVEs conhecidos.

### Step 4 — Risk Matrix
| Finding | Severity | CVSS | Fix Priority |
|---------|----------|------|-------------|

### Step 5 — Remediation Plan
Ordenado por severity + ease of fix.

## Output Schema
```yaml
security_audit:
  owasp: [{id: "", status: "pass|fail|partial", finding: "", fix: ""}]
  headers: [{header: "", present: true/false, value: ""}]
  dependencies: [{package: "", version: "", cve: "", severity: ""}]
  risk_matrix: [{finding: "", severity: "", cvss: 0-10, priority: ""}]
  score: 0-100
  remediation: [{priority: 1-N, action: "", effort: "", impact: ""}]
```
