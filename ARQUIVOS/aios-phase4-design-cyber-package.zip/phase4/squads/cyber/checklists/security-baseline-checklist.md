# Checklist: Security Baseline

## Authentication
- [ ] Strong password policy (min 8 chars, complexity)
- [ ] MFA available (and enforced for admin)
- [ ] Rate limiting on login (max 5 attempts/min)
- [ ] Secure session management (httpOnly, secure, SameSite)
- [ ] Password hashing (bcrypt/argon2, NOT md5/sha1)

## Authorization
- [ ] RBAC implemented (roles with least privilege)
- [ ] Server-side permission checks on every request
- [ ] No direct object references exposed
- [ ] Admin routes protected

## Data Protection
- [ ] HTTPS everywhere (no HTTP)
- [ ] Data encrypted at rest
- [ ] Sensitive data not in logs
- [ ] PII handling compliant with LGPD
- [ ] Backups encrypted and tested

## Application Security
- [ ] OWASP Top 10 reviewed
- [ ] Security headers configured (HSTS, CSP, X-Frame)
- [ ] Input validation on all user inputs
- [ ] Output encoding to prevent XSS
- [ ] CORS properly configured (not wildcard)
- [ ] File upload validation (type, size, scan)

## Infrastructure
- [ ] Secrets in vault (not in code/env files in repo)
- [ ] Dependency scanning automated
- [ ] Firewall configured (deny by default)
- [ ] Monitoring and alerting active
- [ ] Incident response plan documented

## DevOps
- [ ] CI/CD pipeline includes security scan
- [ ] No secrets in version control
- [ ] Staging environment mirrors production
- [ ] Deployment requires approval for production
- [ ] Rollback procedure documented and tested

## Score
```
Auth: ___/5  Authz: ___/4  Data: ___/5
App: ___/6  Infra: ___/5  DevOps: ___/5
Total: ___/30

≥25: Solid baseline
18-24: Gaps to address (prioritize by risk)
<18: Significant security debt
```
