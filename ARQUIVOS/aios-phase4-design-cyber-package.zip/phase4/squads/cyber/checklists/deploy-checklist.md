# Checklist: Pre-Deploy

## Code
- [ ] All tests passing
- [ ] No console.log / debug code
- [ ] No hardcoded secrets
- [ ] Dependency audit clean (no critical CVEs)
- [ ] Code review approved

## Security
- [ ] Security headers configured
- [ ] HTTPS verified
- [ ] CORS configured correctly
- [ ] Rate limiting active
- [ ] Input validation on new endpoints

## Infrastructure
- [ ] Environment variables set in production
- [ ] Database migrations ready
- [ ] Backup verified (can restore?)
- [ ] Monitoring dashboards ready
- [ ] Alerts configured for new features

## Performance
- [ ] Load time < 3s (mobile)
- [ ] Images optimized
- [ ] API response time < 500ms (p95)
- [ ] No N+1 queries

## Rollback
- [ ] Rollback procedure documented
- [ ] Previous version tagged and accessible
- [ ] Database rollback possible (if migration)
- [ ] Feature flags for gradual rollout (if applicable)

## Go/No-Go
```
Code: ___/5  Security: ___/5  Infra: ___/5
Performance: ___/4  Rollback: ___/4
Total: ___/23

≥20: DEPLOY
15-19: DEPLOY with monitoring
<15: DO NOT DEPLOY
```
