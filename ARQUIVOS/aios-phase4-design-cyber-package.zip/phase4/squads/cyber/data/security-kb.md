# Knowledge Base: Security & Infrastructure

## OWASP Top 10 (2021)
A01 Broken Access Control, A02 Cryptographic Failures, A03 Injection, A04 Insecure Design, A05 Security Misconfiguration, A06 Vulnerable Components, A07 Auth Failures, A08 Integrity Failures, A09 Logging Failures, A10 SSRF

## Zero Trust Principles
1. Verify explicitly 2. Least privilege 3. Assume breach

## STRIDE Threat Model
Spoofing → Auth, Tampering → Integrity, Repudiation → Logging, Info Disclosure → Encryption, DoS → Rate Limiting, Elevation → Authorization

## JWT Best Practices
- Access token: 15-30min expiry
- Refresh token: single-use rotation
- Store: httpOnly secure cookie
- Validate: signature + all claims

## Security Headers
HSTS, CSP, X-Content-Type-Options, X-Frame-Options, Referrer-Policy, Permissions-Policy

## Password Hashing
GOOD: bcrypt (cost 12+), argon2id
BAD: md5, sha1, sha256 (without salt)
NEVER: plaintext

## CVSS Severity
Critical 9.0-10.0 (24h fix), High 7.0-8.9 (7d), Medium 4.0-6.9 (30d), Low 0.1-3.9 (90d)

## Recommended Stack (Solo/Small Team)
Frontend: Vercel (Next.js), Backend: Supabase, DB: PostgreSQL (Supabase), Auth: Supabase Auth, Storage: Supabase Storage, Email: Resend, Monitoring: Sentry + Vercel Analytics

## Backup Strategy
3-2-1 Rule: 3 copies, 2 different media, 1 off-site
Test backups quarterly. Untested backup = no backup.

## Incident Severity
SEV1: Production down / data breach → Immediate response
SEV2: Degraded service / feature broken → Response in hours
SEV3: Minor bug / non-critical → Response in days
