# Template: Post-Mortem (Blameless)

## Incident Summary
- **Date:** {date}
- **Duration:** {start_time} → {end_time} ({total_duration})
- **Severity:** {SEV1/2/3}
- **Impact:** {who/what was affected}

## Timeline
| Time | Event |
|------|-------|
| {time} | {what happened} |

## Root Cause
{Why did this happen? Keep asking "why" 5 times.}

## Contributing Factors
- {Factor 1}
- {Factor 2}

## What Went Well
- {Something that worked in the response}

## What Went Wrong
- {Something that made it worse or slower}

## Action Items
| Action | Owner | Deadline | Priority |
|--------|-------|----------|----------|
| {fix} | {who} | {when} | {P1/P2/P3} |

## Lessons Learned
{What did we learn that prevents this from happening again?}

---
*This is a BLAMELESS post-mortem. We focus on systems and processes, not individuals.*
