# Task: Design Landing Page

## Metadata
- **Agent:** @refactoring-ui + @luke-wroblewski
- **Tier:** 1
- **depends_on:** BrandScript (Copy-Chief) ou copy pronto

## Input
```yaml
required:
  - copy: "Headlines, body, CTAs (output do Copy-Chief)"
  - brand: "Cores, fontes, logo (output da brand identity OU existente)"
  - conversion_goal: "lead | purchase | signup | webinar"
```

## Instruções

### Step 1 — Layout Sections
```
1. Hero (above fold): headline + sub + CTA + visual
2. Social Proof Bar: logos ou "X clientes"
3. Problem: 3 pain points
4. Solution: features/benefits (3 colunas)
5. How it Works: 3 steps
6. Testimonials: 3 cards
7. Pricing: 1-3 tiers (se aplicável)
8. FAQ: 5-7 perguntas (accordion)
9. Final CTA: repeat hero CTA
10. Footer: links, legal, contact
```

### Step 2 — Visual Hierarchy (@refactoring-ui)
Definir para cada seção: size, weight, color, spacing.

### Step 3 — Mobile Adaptation (@luke-wroblewski)
- Sticky CTA bottom
- Hamburger nav
- Stacked columns
- Simplified hero

### Step 4 — Conversion Elements
- CTA color = primary brand color (destaque máximo)
- Form: mínimo de campos
- Trust signals próximo do CTA (guarantee, security, social proof)

## Output Schema
```yaml
landing_page:
  sections: [{name: "", content: "", layout: "", mobile_adaptation: ""}]
  cta: {text: "", color: "", position: ["hero", "mid", "final"]}
  form: {fields: [], position: ""}
  trust_signals: []
```
