# Task: Design System Setup

## Metadata
- **Agent:** @refactoring-ui + @dieter-rams
- **Tier:** 1

## Input
```yaml
required:
  - brand_identity: "Output da brand identity ou cores/fontes existentes"
  - platform: "web | mobile | both"
```

## Instruções

### Step 1 — Tokens
- Colors: primary (50-900), neutral (50-900), semantic
- Spacing: 4, 8, 12, 16, 24, 32, 48, 64, 96, 128
- Typography: scale (12-72), weights, line-heights
- Border-radius: 4, 8, 12, 16, full
- Shadows: sm, md, lg, xl

### Step 2 — Components
- Button: primary, secondary, ghost, destructive (+ sizes: sm, md, lg)
- Input: text, email, password, select, textarea, checkbox, radio
- Card: default, outlined, elevated
- Badge: default, success, warning, error, info
- Alert: info, success, warning, error
- Modal: sm, md, lg
- Table: default, striped
- Navigation: navbar, sidebar, breadcrumb, tabs

### Step 3 — Patterns
- Forms: label position, validation, error states
- Empty states: illustration + message + CTA
- Loading: skeleton, spinner, progress bar
- Error pages: 404, 500, offline

## Output Schema
```yaml
design_system:
  tokens: {colors: {}, spacing: [], typography: {}, radii: [], shadows: []}
  components: [{name: "", variants: [], sizes: [], states: []}]
  patterns: [{name: "", when: "", structure: ""}]
```
