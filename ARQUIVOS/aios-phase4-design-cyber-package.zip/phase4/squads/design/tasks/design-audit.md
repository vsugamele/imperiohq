# Task: Design Audit — Avaliação Completa

## Metadata
- **Agent:** @dieter-rams (principles) + @don-norman (UX) + @refactoring-ui (UI)
- **Tier:** 0

## Input
```yaml
required:
  - url_or_screenshots: "URL do site/app ou screenshots"
  - context: "landing page | app | dashboard | e-commerce | site institucional"
```

## Instruções

### Step 1 — 10 Principles Check (@dieter-rams)
Avaliar cada princípio 0-10. Score total /100.

### Step 2 — Emotional Design Check (@don-norman)
Visceral (0-10), Behavioral (0-10), Reflective (0-10).

### Step 3 — UI Systems Check (@refactoring-ui)
- Visual hierarchy clara? (0-10)
- Spacing consistente? (0-10)
- Color system coerente? (0-10)
- Typography system? (0-10)

### Step 4 — Mobile Check (@luke-wroblewski)
- Above the fold otimizado? (0-10)
- Touch targets 44px+? (0-10)
- Forms otimizados? (0-10)

### Step 5 — Dark Patterns Check (@vitaly-friedman)
Verificar se há dark patterns presentes.

## Output Schema
```yaml
design_audit:
  rams_score: 0-100
  emotional: {visceral: 0-10, behavioral: 0-10, reflective: 0-10}
  ui: {hierarchy: 0-10, spacing: 0-10, color: 0-10, typography: 0-10}
  mobile: {above_fold: 0-10, touch: 0-10, forms: 0-10}
  dark_patterns: [{found: "", fix: ""}]
  overall: 0-100
  top_3_fixes: []
```
