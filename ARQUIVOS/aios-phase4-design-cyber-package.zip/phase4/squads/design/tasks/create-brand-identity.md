# Task: Create Brand Identity

## Metadata
- **Agent:** @jessica-walsh
- **Tier:** 1
- **depends_on:** BrandScript (Story-Chief) + avatar (HackerVerso)

## Input
```yaml
required:
  - brand_name: ""
  - brandscript: "Output SB7 ou resumo de posicionamento"
  - audience: "Avatar profile"
  - competitors: "3-5 referências visuais de concorrentes"
```

## Instruções

### Step 1 — 3 Keywords Visuais
Definir 3 palavras que guiam toda identidade visual.

### Step 2 — Moodboard
20-30 referências → filtrar por 3 keywords → padrões visuais.

### Step 3 — Color Palette
Primary (+ shades), Secondary, Accent, Neutral, Semantic.

### Step 4 — Typography
Heading font + Body font. Justificativa para cada.

### Step 5 — Logo Direction
Concept, versions (primary, secondary, icon, mono).

### Step 6 — Brand Guidelines
Usage rules, do's, don'ts, applications.

## Output Schema
```yaml
brand_identity:
  keywords: ["", "", ""]
  colors: {primary: {hex: "", shades: []}, secondary: "", accent: "", neutral: []}
  typography: {heading: {font: "", weight: ""}, body: {font: "", weight: ""}}
  logo: {concept: "", versions: []}
  guidelines: {spacing: "", min_size: "", clear_space: "", dos: [], donts: []}
```
