# Task: Design Presentation — Slides

## Metadata
- **Agent:** @jessica-walsh (visual) + integra output @nancy-duarte (narrative)
- **Tier:** 2
- **depends_on:** Sparkline narrative (Story-Chief)

## Input
```yaml
required:
  - sparkline: "Output do craft-presentation (Story-Chief)"
  - brand: "Brand identity / colors / fonts"
  - duration: "15min | 30min | 45min"
```

## Instruções

### Step 1 — Slide Count
Regra: 1 slide por minuto + 20% para transition slides.
15min = 18 slides, 30min = 36 slides, 45min = 54 slides.

### Step 2 — Slide Types
- Title slide (1): nome, título, data
- Section dividers: 1 por seção principal
- Content slides: 1 idea per slide
- Quote slides: citação grande, fundo clean
- Data slides: 1 gráfico simples
- Image slides: full-bleed photo
- Final CTA slide: call to action claro

### Step 3 — Glance Test
Cada slide deve comunicar em 3 segundos.

### Step 4 — Visual Direction
Aplicar brand identity aos slides com consistência.

## Output Schema
```yaml
presentation:
  total_slides: X
  slides: [{number: X, type: "", idea: "", visual_direction: "", notes: ""}]
  template: {colors: "", fonts: "", layout_grid: ""}
```
