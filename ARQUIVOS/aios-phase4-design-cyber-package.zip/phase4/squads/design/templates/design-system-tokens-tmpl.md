# Template: Design System Tokens

## Colors
```
primary-50:  #  (lightest)
primary-100: #
primary-200: #
primary-300: #
primary-400: #
primary-500: #  (base)
primary-600: #
primary-700: #
primary-800: #
primary-900: #  (darkest)

neutral-50:  #  (background)
neutral-100: #
neutral-200: #  (borders)
neutral-300: #
neutral-400: #
neutral-500: #  (secondary text)
neutral-600: #
neutral-700: #  (primary text)
neutral-800: #
neutral-900: #  (headings)

semantic:
  success: #22C55E
  warning: #F59E0B
  error:   #EF4444
  info:    #3B82F6
```

## Spacing (8px grid)
4, 8, 12, 16, 20, 24, 32, 40, 48, 64, 80, 96, 128

## Typography
```
Heading: {font-family} — weights: 600, 700
Body:    {font-family} — weights: 400, 500, 600

Scale: 12 / 14 / 16 / 18 / 20 / 24 / 30 / 36 / 48 / 60 / 72
Line-height: body 1.5, heading 1.2
```

## Border Radius
2, 4, 6, 8, 12, 16, 9999 (full)

## Shadows
```
sm:  0 1px 2px rgba(0,0,0,0.05)
md:  0 4px 6px rgba(0,0,0,0.07)
lg:  0 10px 15px rgba(0,0,0,0.1)
xl:  0 20px 25px rgba(0,0,0,0.15)
```
