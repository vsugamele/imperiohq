# Template: Landing Page Wireframe

## Section 1 — HERO (Above the Fold)
```
┌─────────────────────────────────────────────┐
│  [Logo]                    [Nav] [CTA btn]  │
│                                              │
│  {HEADLINE — large, bold}                    │
│  {Sub-headline — medium, lighter}            │
│                                              │
│  [{CTA BUTTON}]   {secondary link}           │
│                                              │
│  {Trust: "Trusted by X+" or logos}           │
│                    [Hero Image/Video →]       │
└─────────────────────────────────────────────┘
```

## Section 2 — SOCIAL PROOF BAR
```
┌─────────────────────────────────────────────┐
│  [Logo] [Logo] [Logo] [Logo] [Logo]         │
│  "Used by 10,000+ professionals"            │
└─────────────────────────────────────────────┘
```

## Section 3 — PROBLEM (Pain Points)
```
┌─────────────────────────────────────────────┐
│  {Section headline: "Sound familiar?"}       │
│                                              │
│  [Icon]         [Icon]         [Icon]        │
│  Pain 1         Pain 2         Pain 3        │
│  Description    Description    Description   │
└─────────────────────────────────────────────┘
```

## Section 4 — SOLUTION (Benefits)
```
┌─────────────────────────────────────────────┐
│  {Section headline: "Here's how we help"}    │
│                                              │
│  [Visual]  Benefit 1: headline + description │
│  [Visual]  Benefit 2: headline + description │
│  [Visual]  Benefit 3: headline + description │
└─────────────────────────────────────────────┘
```

## Section 5 — HOW IT WORKS
```
┌─────────────────────────────────────────────┐
│  "3 simple steps"                            │
│                                              │
│  ① Step 1 → ② Step 2 → ③ Step 3             │
│  Description  Description  Description       │
└─────────────────────────────────────────────┘
```

## Section 6-10
Testimonials → Pricing → FAQ (accordion) → Final CTA → Footer
