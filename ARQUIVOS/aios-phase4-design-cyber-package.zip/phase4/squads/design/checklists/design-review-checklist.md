# Checklist: Design Review

## Visual Hierarchy
- [ ] Primary action is visually dominant
- [ ] Secondary elements are visually subdued
- [ ] Clear reading flow (F-pattern or Z-pattern)
- [ ] No competing focal points

## Consistency
- [ ] Colors from design system only
- [ ] Spacing from 8px grid only
- [ ] Typography from defined scale only
- [ ] Components match design system patterns

## Mobile
- [ ] Mobile-first designed
- [ ] Touch targets ≥ 44x44px
- [ ] Text readable without zoom (≥16px body)
- [ ] No horizontal scroll
- [ ] Sticky CTA visible

## Accessibility
- [ ] Color contrast ratio ≥ 4.5:1 (text), ≥ 3:1 (large text)
- [ ] Alt text on all images
- [ ] Form labels associated with inputs
- [ ] Focus states visible
- [ ] Not relying on color alone for info

## Performance
- [ ] Images optimized (WebP, lazy load)
- [ ] Above fold loads in <3s
- [ ] No unnecessary animations on mobile
- [ ] Fonts optimized (subset, preload)

## Conversion
- [ ] CTA visible above the fold
- [ ] CTA repeated at least 2x on page
- [ ] Trust signals near CTA
- [ ] Form has minimum required fields
- [ ] Clear value proposition in <5 seconds

## Score
```
Hierarchy: ___/4   Consistency: ___/4   Mobile: ___/5
Access: ___/5   Performance: ___/4   Conversion: ___/5
Total: ___/27

≥22: Ship it
17-21: Minor fixes then ship
12-16: Significant revision needed
<12: Major redesign
```
