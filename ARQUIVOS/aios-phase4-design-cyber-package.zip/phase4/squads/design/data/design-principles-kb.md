# Knowledge Base: Design Principles

## Dieter Rams — 10 Principles of Good Design
Innovative, Useful, Aesthetic, Understandable, Unobtrusive, Honest, Long-lasting, Thorough, Environmentally friendly, As little design as possible.

## Don Norman — Emotional Design 3 Levels
Visceral (appearance) → Behavioral (usability) → Reflective (meaning)

## Don Norman — Design Principles
Visibility, Feedback, Constraints, Mapping, Consistency, Error Prevention

## Refactoring UI — Visual Hierarchy
Size > Weight > Color > Spacing > Position. 8px grid. Max 2 fonts.

## Luke Wroblewski — Mobile-First
Content priority, thumb zone, 44px touch targets, progressive disclosure

## Gestalt Principles (Visual Perception)
Proximity (close = related), Similarity (similar = grouped), Closure (complete incomplete shapes), Continuity (follow lines/curves), Figure-Ground (foreground vs background)

## Color Theory Quick Reference
- Complementary: opposite on wheel (high contrast)
- Analogous: adjacent on wheel (harmony)
- Triadic: 3 equidistant (vibrant)
- 60-30-10 rule: 60% dominant, 30% secondary, 10% accent

## Typography Rules
- Max 2 font families
- Body: 16px minimum, line-height 1.5
- Headings: line-height 1.2-1.3
- Max line width: 60-75 characters
- Contrast: dark text on light bg (not pure black on white)

## Layout Patterns
- F-pattern: text-heavy pages (blog, news)
- Z-pattern: marketing pages (landing, home)
- Single column: mobile, forms, articles
- Grid: galleries, product listings, dashboards
