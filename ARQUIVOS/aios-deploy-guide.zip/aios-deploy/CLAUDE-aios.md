# AIOS — AI Operating System for Digital Business

## System Overview

This repo contains 11 specialized AI chiefs organized in a multi-agent architecture.
Each chief has agent personas in `.claude/commands/` and operational files in `squads/`.

## Architecture

```
User Request → Router → Chief → Sub-Agent (Tier) → Task → Output
```

## Chiefs & Routing

When the user asks for help, route to the correct chief:

| Context | Chief | Commands Path |
|---------|-------|--------------|
| Avatar, posicionamento, mecanismo único, persona | HackerVerso | .claude/commands/HackerVerso/agents/ |
| Copy, headline, email, VSL, sales page, persuasão | Copy-Chief | .claude/commands/Copy/agents/ |
| Tráfego, Meta Ads, Google Ads, YouTube, campanha, ROAS | Traffic-Masters | .claude/commands/Traffic/agents/ |
| Métrica, analytics, CLV, NPS, funil, AARRR, health score | Data-Chief | .claude/commands/Data/agents/ |
| Narrativa, storytelling, pitch, apresentação, SB7, Sparkline | Story-Chief | .claude/commands/Storytelling/agents/ |
| Contrato, LGPD, tributário, CLT, PJ, compliance, sócios | Legal-Chief | .claude/commands/Legal/agents/ |
| Design, UI, UX, landing page, brand, logo, cores | Design-Chief | .claude/commands/Design/agents/ |
| Segurança, OWASP, deploy, infra, CI/CD, API security | Cyber-Chief | .claude/commands/Cyber/agents/ |
| Schema, SQL, Supabase, RLS, migration, cache, Redis | DB-Sage | .claude/commands/Database/agents/ |
| Tokens, componente, Tailwind, shadcn, acessibilidade | Design-System | .claude/commands/DesignSystem/agents/ |
| Automação, n8n, workflow, integração, webhook, AI agents | Tools-Orchestrator | .claude/commands/Tools/agents/ |

## How to Use

1. **Read the chief file** first (e.g., `copy-chief.md`) to understand routing
2. The chief routes to the correct **sub-agent** based on the mission
3. Load the corresponding **task file** from `squads/{chief}/tasks/`
4. Follow the task steps, using **templates** from `squads/{chief}/templates/`
5. Validate against **checklists** from `squads/{chief}/checklists/`
6. Reference **knowledge bases** from `squads/{chief}/data/`

## Tier System (All Chiefs Follow This)

- **Tier 0 (Mandatory):** Diagnostic/foundational — ALWAYS run first
- **Tier 1 (Masters):** Core execution agents
- **Tier 2 (Specialists):** Domain-specific experts

## Operational Files

```
squads/{chief}/
  tasks/       → Step-by-step mission instructions
  templates/   → Fill-in-the-blank frameworks
  checklists/  → Quality gates (score-based)
  data/        → Knowledge bases and references
```

## Business Loop

```
HackerVerso (strategy) → Story-Chief (narrative) → Copy-Chief (persuasion)
→ Design-Chief (visual) → Design-System (components) → Traffic-Masters (distribution)
→ Data-Chief (measurement) → Legal-Chief (compliance) → Cyber-Chief (security)
→ DB-Sage (data layer) → Tools-Orchestrator (automation) → FEEDBACK LOOP
```

## Important Rules

- ALWAYS load the chief agent file before any sub-agent
- ALWAYS run Tier 0 diagnostic before execution
- Legal-Chief: ALWAYS add disclaimer "orientação geral, consulte advogado"
- All agents use DNA Mental framework with numbered heuristics (H1, H2, H3...)
- Output should follow the YAML schema defined in each agent file
- Cross-reference between chiefs when tasks overlap (e.g., Copy needs Story first)
