#!/bin/bash
# =============================================================
# AIOS Deploy Script
# Uso: bash deploy-aios.sh /caminho/dos/zips /caminho/do/repo
# Exemplo: bash deploy-aios.sh ~/Downloads ~/aios-core
# =============================================================

ZIPS_DIR="${1:-.}"
REPO_DIR="${2:-.}"

echo "🧠 AIOS Deploy"
echo "  Zips: $ZIPS_DIR"
echo "  Repo: $REPO_DIR"
echo ""

# Criar estrutura
echo "📁 Criando estrutura..."
mkdir -p "$REPO_DIR/.claude/commands"/{HackerVerso,Copy,Traffic,Data,Storytelling,Legal,Design,Cyber,Database,DesignSystem,Tools}/agents
mkdir -p "$REPO_DIR/squads"/{hackerverso,copy-chief,traffic-masters,data-intelligence,storytelling,legal,design,cyber,db-sage,design-system,tools}/{tasks,templates,checklists,data}

# Extrair e copiar cada fase
TMP=$(mktemp -d)

for phase in 2 3 4 5; do
  ZIP=$(find "$ZIPS_DIR" -name "*phase${phase}*" -name "*.zip" 2>/dev/null | head -1)
  if [ -n "$ZIP" ]; then
    echo "📦 Extraindo Phase $phase: $(basename $ZIP)"
    unzip -qo "$ZIP" -d "$TMP/phase${phase}/"

    # Encontrar e copiar agents
    find "$TMP/phase${phase}" -path "*/commands/*/agents/*.md" | while read f; do
      CHIEF=$(echo "$f" | grep -oP 'commands/\K[^/]+')
      cp "$f" "$REPO_DIR/.claude/commands/$CHIEF/agents/" 2>/dev/null
    done

    # Encontrar e copiar squads
    for subdir in tasks templates checklists data; do
      find "$TMP/phase${phase}" -path "*/squads/*/$subdir/*.md" | while read f; do
        SQUAD=$(echo "$f" | grep -oP 'squads/\K[^/]+')
        mkdir -p "$REPO_DIR/squads/$SQUAD/$subdir"
        cp "$f" "$REPO_DIR/squads/$SQUAD/$subdir/" 2>/dev/null
      done
    done
  else
    echo "⚠️  Phase $phase zip não encontrado em $ZIPS_DIR"
  fi
done

# Limpar
rm -rf "$TMP"

# Report
echo ""
echo "✅ Deploy completo!"
echo ""
echo "📊 Inventário:"
echo "  Commands (agents): $(find "$REPO_DIR/.claude/commands" -name "*.md" -type f 2>/dev/null | wc -l) arquivos"
echo "  Squads (tasks+templates+checklists+data): $(find "$REPO_DIR/squads" -name "*.md" -type f 2>/dev/null | wc -l) arquivos"
echo ""
echo "  Chiefs:"
for chief in $(ls "$REPO_DIR/.claude/commands/" 2>/dev/null); do
  count=$(find "$REPO_DIR/.claude/commands/$chief" -name "*.md" -type f 2>/dev/null | wc -l)
  [ "$count" -gt 0 ] && echo "    $chief: $count agents"
done
echo ""
echo "⚠️  Próximos passos:"
echo "  1. Copie CLAUDE-aios.md para $REPO_DIR/CLAUDE.md"
echo "  2. Confirme que Phase 0 (HackerVerso) e Phase 1 (Copy) já estão no repo"
echo "  3. Abra 'claude' no repo e teste: 'crie uma headline para meu curso'"
