# Prompt para Colar no Claude Code

Cole este texto inteiro no Claude Code quando estiver dentro do repo aios-core:

---

Preciso que você faça o deploy completo do sistema AIOS neste repo.

## Arquivos fonte
Os zips do AIOS estão em [SUBSTITUIR_PELO_CAMINHO]. São 4 pacotes:
- aios-phase2-traffic-data-package.zip
- aios-phase3-story-legal-package.zip
- aios-phase4-design-cyber-package.zip
- aios-phase5-final-package.zip

## O que fazer

1. Extrair cada zip
2. Criar a estrutura de diretórios se não existir:
   - .claude/commands/{Traffic,Data,Storytelling,Legal,Design,Cyber,Database,DesignSystem,Tools}/agents/
   - squads/{traffic-masters,data-intelligence,storytelling,legal,design,cyber,db-sage,design-system,tools}/{tasks,templates,checklists,data}/

3. Copiar os arquivos de cada fase para os locais corretos:
   - `commands/*/agents/*.md` → `.claude/commands/*/agents/`
   - `squads/*/tasks/*.md` → `squads/*/tasks/`
   - `squads/*/templates/*.md` → `squads/*/templates/`
   - `squads/*/checklists/*.md` → `squads/*/checklists/`
   - `squads/*/data/*.md` → `squads/*/data/`

4. Criar o arquivo CLAUDE.md na raiz do repo com o conteúdo do arquivo CLAUDE-aios.md (vou te passar em seguida)

5. Verificar e reportar:
   - Total de arquivos .md em .claude/commands/
   - Total de arquivos .md em squads/
   - Listar todos os chiefs e quantos agents cada um tem

Comece extraindo os zips e me mostre o que tem dentro de cada um.
