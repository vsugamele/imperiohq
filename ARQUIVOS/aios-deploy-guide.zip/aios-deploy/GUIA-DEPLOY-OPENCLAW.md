# AIOS — Guia Prático: Deploy no Claude Code + Integração OpenClaw

---

## PARTE 1: Fazer o Claude Code Implementar os Arquivos

### O Prompt (cola isso no Claude Code dentro do repo aios-core)

Abra o terminal no repo e rode:

```bash
cd ~/aios-core   # ou onde está seu repo
claude
```

Depois cole este prompt:

```
Preciso que você implemente os arquivos do AIOS que estão nos zips de cada fase.
Os zips estão em [CAMINHO_DOS_ZIPS].

Para cada fase:
1. Extraia o zip
2. Copie os agents para .claude/commands/{Chief}/agents/
3. Copie tasks, templates, checklists e data para squads/{chief}/

A estrutura final deve ser:

.claude/commands/
  HackerVerso/agents/    → 10 agents (já existem? confirmar)
  Copy/agents/           → 12 agents (já existem? confirmar)
  Traffic/agents/        → 8 agents
  Data/agents/           → 7 agents
  Storytelling/agents/   → 13 agents
  Legal/agents/          → 8 agents
  Design/agents/         → 8 agents
  Cyber/agents/          → 8 agents
  Database/agents/       → 7 agents
  DesignSystem/agents/   → 6 agents
  Tools/agents/          → 5 agents

squads/
  hackerverso/           → tasks, templates, checklists, data
  copy-chief/
  traffic-masters/
  data-intelligence/
  storytelling/
  legal/
  design/
  cyber/
  db-sage/
  design-system/
  tools/

Depois de copiar, crie o CLAUDE.md na raiz do repo com o conteúdo
que vou te passar em seguida. Confirme quantos arquivos .md existem
no total em .claude/commands/ e squads/.
```

### CLAUDE.md — O Arquivo Mais Importante

Depois que ele copiar os arquivos, cole este segundo prompt:

```
Crie o arquivo CLAUDE.md na raiz do repo com este conteúdo:
```

E passe o conteúdo abaixo (está no arquivo CLAUDE.md que vou gerar separado).

### Alternativa Mais Simples (Recomendada)

Se quiser evitar copiar prompts enormes, faça o seguinte:

```bash
# 1. Extrair todos os zips numa pasta temporária
mkdir /tmp/aios-all
unzip aios-phase2-traffic-data-package.zip -d /tmp/aios-all/
unzip aios-phase3-story-legal-package.zip -d /tmp/aios-all/
unzip aios-phase4-design-cyber-package.zip -d /tmp/aios-all/
unzip aios-phase5-final-package.zip -d /tmp/aios-all/

# 2. Abrir Claude Code no repo
cd ~/aios-core
claude

# 3. Cole este prompt curto:
```

```
Os arquivos do AIOS estão extraídos em /tmp/aios-all/.
Cada subpasta (phase2, phase3, phase4, phase5) contém:
- commands/{Chief}/agents/*.md → copiar para .claude/commands/{Chief}/agents/
- squads/{squad}/* → copiar para squads/{squad}/

Faça o deploy de todos os arquivos e depois me mostre
o total de arquivos .md em .claude/commands/ e squads/.
```

O Claude Code vai entender a estrutura, copiar tudo, e confirmar.

---

## PARTE 2: CLAUDE.md (O Cérebro do AIOS)

Este arquivo vai na raiz do repo. Ele ensina o Claude Code
a rotear automaticamente para o chief certo baseado no contexto.

Crie `~/aios-core/CLAUDE.md` com o conteúdo que está no arquivo
separado `CLAUDE-aios.md` que acompanha este guia.

---

## PARTE 3: Integração com OpenClaw

### 3.1 — Como Funciona

OpenClaw usa **Skills** (pastas com SKILL.md) exatamente como Claude Code.
O formato é compatível — os dois seguem o padrão **AgentSkills**.

Isso significa que os agents do AIOS podem virar skills do OpenClaw
com adaptações mínimas.

A arquitetura fica assim:

```
Você (WhatsApp/Telegram/Discord)
  → OpenClaw (gateway local)
    → Skill AIOS Router (classifica a missão)
      → Claude API (com system prompt do agent certo)
        → Executa task + retorna resultado
    → Resultado volta pelo chat
```

### 3.2 — Instalar OpenClaw

```bash
# Requisito: Node.js 22+
npm install -g openclaw@latest
openclaw onboard --install-daemon
```

Siga o wizard: escolha o modelo (Claude é recomendado), conecte
WhatsApp/Telegram, configure API key da Anthropic.

### 3.3 — Criar Skills do AIOS no OpenClaw

Cada chief vira uma skill. A pasta fica em:

```
~/.openclaw/skills/           # ou <workspace>/skills/
  aios-router/
    SKILL.md
  aios-copy-chief/
    SKILL.md
  aios-traffic/
    SKILL.md
  aios-story/
    SKILL.md
  aios-legal/
    SKILL.md
  aios-design/
    SKILL.md
  aios-cyber/
    SKILL.md
  aios-db-sage/
    SKILL.md
  aios-design-system/
    SKILL.md
  aios-tools/
    SKILL.md
  aios-data/
    SKILL.md
```

### 3.4 — Skill Principal: AIOS Router

Criar `~/.openclaw/skills/aios-router/SKILL.md`:

```markdown
---
name: aios-router
description: "AIOS - AI Operating System. Sistema multi-agent de negócios digitais.
  Roteia para o chief correto baseado no contexto. Use quando o usuário
  mencionar: copy, headline, email, VSL, tráfego, Meta Ads, Google Ads,
  YouTube, storytelling, narrativa, pitch, contrato, LGPD, tributário,
  design, UI, UX, landing page, segurança, OWASP, banco de dados, schema,
  Supabase, automação, n8n, API, workflow, métricas, analytics, funil."
metadata:
  openclaw:
    emoji: "🧠"
---

# AIOS — AI Operating System Router

Você é o AIOS, um sistema operacional de IA para negócios digitais com 11 chiefs especializados.

## Routing Rules

Quando o usuário pedir algo, identifique o chief correto:

| Keywords | Chief | Ação |
|----------|-------|------|
| copy, headline, email, VSL, sales page, persuasão | Copy-Chief | Carregar instruções de squads/copy-chief/ |
| tráfego, Meta Ads, Google, YouTube, campanha, ROAS | Traffic-Masters | Carregar squads/traffic-masters/ |
| história, narrativa, pitch, apresentação, storytelling | Story-Chief | Carregar squads/storytelling/ |
| contrato, LGPD, tributário, CLT, PJ, sócio, compliance | Legal-Chief | Carregar squads/legal/ |
| design, UI, UX, landing page, brand, logo, cores | Design-Chief | Carregar squads/design/ |
| segurança, OWASP, deploy, infra, API security | Cyber-Chief | Carregar squads/cyber/ |
| banco, schema, Supabase, SQL, migration, cache | DB-Sage | Carregar squads/db-sage/ |
| componente, Tailwind, shadcn, tokens, acessibilidade | Design-System | Carregar squads/design-system/ |
| automação, n8n, workflow, integração, webhook, IA | Tools-Orchestrator | Carregar squads/tools/ |
| métrica, analytics, CLV, NPS, funil, AARRR | Data-Chief | Carregar squads/data-intelligence/ |
| avatar, posicionamento, mecanismo, persona | HackerVerso | Carregar squads/hackerverso/ |

## Workflow

1. Identificar o chief correto pelo contexto
2. Carregar o agent-persona correspondente do chief
3. O chief identifica qual sub-agent (tier) acionar
4. Executar a task seguindo os steps do arquivo de task
5. Validar contra o checklist do squad
6. Retornar resultado formatado

## Referências

Os arquivos de agents, tasks, templates, checklists e data estão no repo aios-core.
Use o tool de leitura de arquivos para carregar o conteúdo necessário.
```

### 3.5 — Skills dos Chiefs (exemplo: Copy-Chief)

Criar `~/.openclaw/skills/aios-copy-chief/SKILL.md`:

```markdown
---
name: aios-copy-chief
description: "Especialista em copywriting e persuasão. Use quando o usuário
  pedir headlines, emails, VSL, sales pages, sequências de email, ou
  qualquer texto persuasivo para vendas e marketing."
metadata:
  openclaw:
    emoji: "✍️"
---

# Copy-Chief — Squad de Copywriting

Você é o Copy-Chief do AIOS com 11 agents especializados.

## Tier System

### Tier 0 — Diagnóstico (OBRIGATÓRIO)
- Analisar nível de awareness (Eugene Schwartz: Unaware → Product Aware)
- Definir sofisticação do mercado (1-5)

### Tier 1 — Masters
- Gary Halbert: Headlines, leads, hooks
- David Ogilvy: Long-form, research-based
- Gary Bencivenga: Emotional triggers
- Dan Kennedy: Direct response, urgency

### Tier 2 — Especialistas
- Frank Kern: Webinars, VSL, launches
- Russell Brunson: Funnels, story selling
- Joanna Wiebe: Conversion copy, A/B testing

## Routing
- "headline" ou "título" → Gary Halbert approach
- "email" → Sequência com awareness progression
- "VSL" ou "vídeo de vendas" → Frank Kern framework
- "sales page" → Combine Gary Halbert (headline) + Dan Kennedy (body) + Joanna Wiebe (CTA)
- "funnel" → Russell Brunson value ladder

## Task Execution
Leia os arquivos de tasks em squads/copy-chief/tasks/ para instruções detalhadas.
Cada task tem steps específicos, input requerido e output schema.

## Quality Gate
Toda copy deve passar pelo checklist em squads/copy-chief/checklists/.
```

Repita o padrão para cada chief, adaptando description e conteúdo.

### 3.6 — Conectar OpenClaw ao Repo aios-core

No `openclaw.json`, adicione o diretório do repo como extraDirs:

```json
{
  "skills": {
    "load": {
      "extraDirs": ["/home/seu-user/aios-core/.claude/commands"]
    },
    "entries": {
      "aios-router": { "enabled": true },
      "aios-copy-chief": { "enabled": true },
      "aios-traffic": { "enabled": true },
      "aios-story": { "enabled": true },
      "aios-legal": { "enabled": true },
      "aios-design": { "enabled": true },
      "aios-cyber": { "enabled": true },
      "aios-db-sage": { "enabled": true },
      "aios-design-system": { "enabled": true },
      "aios-tools": { "enabled": true },
      "aios-data": { "enabled": true }
    }
  }
}
```

### 3.7 — Fluxo Integrado (Claude Code + OpenClaw)

```
DESENVOLVIMENTO (você no terminal):
  Claude Code + AIOS commands
  → /project:Copy:agents:copy-chief
  → Cria copy, testa, itera

OPERAÇÃO 24/7 (OpenClaw no servidor):
  WhatsApp/Telegram → OpenClaw
  → Skill aios-router classifica
  → Aciona chief correto
  → Executa task
  → Responde no chat

AUTOMAÇÃO (n8n conectando tudo):
  Webhook (Hotmart/Kiwify) → n8n
  → Trigger OpenClaw skill
  → AIOS processa
  → Resultado volta pro CRM/email/WhatsApp
```

### 3.8 — Integração OpenClaw + n8n (Para Automação Completa)

OpenClaw tem suporte nativo a webhooks. Configure no n8n:

```
n8n Workflow:
  [Webhook Trigger] → [HTTP Request para OpenClaw]
    URL: http://localhost:3456/api/message
    Body: { "message": "Crie uma headline para [produto]", "session": "aios" }
  → [Recebe resposta] → [Envia resultado]
```

---

## PARTE 4: Resumo dos Passos

### Deploy no Claude Code (5 minutos)
1. Extrair zips numa pasta
2. Abrir Claude Code no repo
3. Pedir para copiar os arquivos para .claude/commands/ e squads/
4. Criar CLAUDE.md na raiz
5. Testar: mencionar "crie uma headline" → deve rotear para Copy-Chief

### Integração OpenClaw (30 minutos)
1. Instalar OpenClaw (`npm install -g openclaw@latest`)
2. Criar skills do AIOS em ~/.openclaw/skills/
3. Configurar openclaw.json com os skills habilitados
4. Conectar WhatsApp/Telegram
5. Testar: mandar "preciso de uma headline pro meu curso" no WhatsApp
6. OpenClaw roteia → AIOS processa → resposta volta no chat

### Automação n8n (opcional, 1 hora)
1. Configurar webhooks Hotmart/Kiwify → n8n
2. n8n aciona OpenClaw via API
3. AIOS processa automaticamente
4. Resultado vai para CRM/email/WhatsApp
