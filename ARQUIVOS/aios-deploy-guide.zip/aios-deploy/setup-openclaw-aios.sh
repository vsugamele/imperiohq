#!/bin/bash
# =============================================================
# AIOS → OpenClaw Skills Generator
# Uso: bash setup-openclaw-aios.sh /caminho/do/repo
# Exemplo: bash setup-openclaw-aios.sh ~/aios-core
# =============================================================

REPO="${1:-$HOME/aios-core}"
SKILLS_DIR="$HOME/.openclaw/skills"

echo "🦞 AIOS → OpenClaw Skills Setup"
echo "  Repo: $REPO"
echo "  Skills: $SKILLS_DIR"
echo ""

# Mapa: chief → emoji, keywords
declare -A CHIEFS=(
  ["aios-router"]="🧠|Router principal do AIOS. Sistema multi-agent de negócios digitais. Use para qualquer pedido sobre negócios, marketing, vendas, copy, tráfego, design, segurança, banco de dados, automação, legal, storytelling, métricas."
  ["aios-copy"]="✍️|Copywriting e persuasão. Use para headlines, emails, VSL, sales pages, sequências de email, textos de vendas, copy para anúncios."
  ["aios-traffic"]="🚀|Tráfego pago e mídia. Use para Meta Ads, Google Ads, YouTube Ads, campanhas, ROAS, CPA, escalar, criativos, audiências."
  ["aios-story"]="📖|Storytelling e narrativa. Use para pitch, apresentação, BrandScript, Sparkline, narrativa de marca, história pessoal, StoryBrand."
  ["aios-legal"]="⚖️|Jurídico e compliance. Use para contratos, LGPD, tributário, CLT vs PJ, acordo de sócios, compliance digital, abertura empresa."
  ["aios-design"]="🎨|Design e visual. Use para UI, UX, landing page, brand identity, visual hierarchy, cores, tipografia, wireframe."
  ["aios-cyber"]="🔒|Segurança e infraestrutura. Use para OWASP, security audit, deploy, CI/CD, Docker, cloud, API security, backup."
  ["aios-db"]="🗄️|Banco de dados. Use para schema, SQL, PostgreSQL, Supabase, RLS, migration, cache, Redis, performance, indexação."
  ["aios-design-system"]="🧩|Design System e componentes. Use para tokens, Tailwind, shadcn, componentes, acessibilidade, WCAG."
  ["aios-tools"]="⚙️|Automação e ferramentas. Use para n8n, workflow, API, webhook, integração, AI agents, MCP, prompt engineering."
  ["aios-data"]="📊|Data e analytics. Use para métricas, CLV, NPS, AARRR, funil, health score, North Star, dashboard, KPIs."
)

# Mapa: skill → chief dir no repo
declare -A CHIEF_DIRS=(
  ["aios-copy"]="Copy"
  ["aios-traffic"]="Traffic"
  ["aios-story"]="Storytelling"
  ["aios-legal"]="Legal"
  ["aios-design"]="Design"
  ["aios-cyber"]="Cyber"
  ["aios-db"]="Database"
  ["aios-design-system"]="DesignSystem"
  ["aios-tools"]="Tools"
  ["aios-data"]="Data"
)

# Mapa: skill → squad dir no repo
declare -A SQUAD_DIRS=(
  ["aios-copy"]="copy-chief"
  ["aios-traffic"]="traffic-masters"
  ["aios-story"]="storytelling"
  ["aios-legal"]="legal"
  ["aios-design"]="design"
  ["aios-cyber"]="cyber"
  ["aios-db"]="db-sage"
  ["aios-design-system"]="design-system"
  ["aios-tools"]="tools"
  ["aios-data"]="data-intelligence"
)

for skill in "${!CHIEFS[@]}"; do
  IFS='|' read -r emoji desc <<< "${CHIEFS[$skill]}"
  SKILL_DIR="$SKILLS_DIR/$skill"
  mkdir -p "$SKILL_DIR"

  if [ "$skill" = "aios-router" ]; then
    # Router skill - referencia todos os chiefs
    cat > "$SKILL_DIR/SKILL.md" << ROUTER_EOF
---
name: aios-router
description: "$desc"
metadata:
  openclaw:
    emoji: "$emoji"
---

# AIOS — AI Operating System Router

Você é o AIOS, um sistema operacional de IA para negócios digitais.
Você tem 11 chiefs especializados. Identifique o contexto e aja como
o chief correto.

## Routing

| Keywords | Chief |
|----------|-------|
| copy, headline, email, VSL, sales page | Copy-Chief |
| tráfego, Meta Ads, Google Ads, YouTube, campanha | Traffic-Masters |
| narrativa, storytelling, pitch, apresentação | Story-Chief |
| contrato, LGPD, tributário, CLT, PJ, compliance | Legal-Chief |
| design, UI, UX, landing page, brand, cores | Design-Chief |
| segurança, OWASP, deploy, infra, CI/CD | Cyber-Chief |
| schema, SQL, Supabase, RLS, migration | DB-Sage |
| tokens, Tailwind, shadcn, componente, a11y | Design-System |
| automação, n8n, workflow, webhook, AI agents | Tools-Orchestrator |
| métrica, analytics, CLV, NPS, funil, AARRR | Data-Chief |
| avatar, posicionamento, mecanismo, persona | HackerVerso |

## Instruções

1. Identifique o chief correto pelo contexto da mensagem
2. Assuma o papel daquele chief
3. Use o tier system: sempre comece pelo Tier 0 (diagnóstico)
4. Depois acione o Tier 1 (execução) ou Tier 2 (especialista)
5. Siga os steps da task correspondente
6. Valide contra o checklist antes de entregar

## Referência

Os arquivos completos dos agents estão em: $REPO/.claude/commands/
Os arquivos operacionais estão em: $REPO/squads/
ROUTER_EOF
    echo "✅ $skill (router)"

  else
    # Chief-specific skill
    CHIEF_DIR="${CHIEF_DIRS[$skill]:-}"
    SQUAD_DIR="${SQUAD_DIRS[$skill]:-}"
    CHIEF_FILE="$REPO/.claude/commands/$CHIEF_DIR/agents/"

    # Pegar o conteúdo do chief file se existir
    CHIEF_CONTENT=""
    if [ -d "$CHIEF_FILE" ]; then
      CHIEF_MD=$(find "$CHIEF_FILE" -name "*chief*" -o -name "*sage*" -o -name "*orchestrator*" 2>/dev/null | head -1)
      if [ -n "$CHIEF_MD" ] && [ -f "$CHIEF_MD" ]; then
        # Adicionar frontmatter e usar o conteúdo original
        cat > "$SKILL_DIR/SKILL.md" << SKILL_HEADER
---
name: $skill
description: "$desc"
metadata:
  openclaw:
    emoji: "$emoji"
---

SKILL_HEADER
        cat "$CHIEF_MD" >> "$SKILL_DIR/SKILL.md"

        # Adicionar referência aos squads
        cat >> "$SKILL_DIR/SKILL.md" << SKILL_FOOTER

## Referência OpenClaw

Tasks detalhadas: $REPO/squads/$SQUAD_DIR/tasks/
Templates: $REPO/squads/$SQUAD_DIR/templates/
Checklists: $REPO/squads/$SQUAD_DIR/checklists/
Knowledge Base: $REPO/squads/$SQUAD_DIR/data/
SKILL_FOOTER
        echo "✅ $skill (from chief file)"
        continue
      fi
    fi

    # Fallback: criar skill básica
    cat > "$SKILL_DIR/SKILL.md" << FALLBACK_EOF
---
name: $skill
description: "$desc"
metadata:
  openclaw:
    emoji: "$emoji"
---

# ${skill#aios-} Chief

$desc

## Instruções

Carregue os arquivos de referência para contexto completo:
- Agents: $REPO/.claude/commands/$CHIEF_DIR/agents/
- Tasks: $REPO/squads/$SQUAD_DIR/tasks/
- Templates: $REPO/squads/$SQUAD_DIR/templates/
- Checklists: $REPO/squads/$SQUAD_DIR/checklists/
- Data: $REPO/squads/$SQUAD_DIR/data/
FALLBACK_EOF
    echo "✅ $skill (fallback)"
  fi
done

echo ""
echo "🦞 Skills criadas em: $SKILLS_DIR"
echo ""
echo "📋 Próximos passos:"
echo "  1. Adicione ao openclaw.json:"
echo '     "skills": { "entries": { "aios-router": { "enabled": true } } }'
echo "  2. Reinicie: openclaw gateway restart"
echo "  3. Teste via WhatsApp: 'Crie uma headline para meu curso de finanças'"
