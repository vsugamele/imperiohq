# AIOS — Guia Completo de Deploy no Claude Code

## 1. O Que São Esses Arquivos

Os arquivos .md que criamos são **custom slash commands** e **skills** do Claude Code.
Quando estão em `.claude/commands/` no seu repo, o Claude Code os reconhece automaticamente.

Exemplo: o arquivo `.claude/commands/Traffic/agents/molly-pittman.md` cria o comando
`/project:Traffic:agents:molly-pittman` no Claude Code.

Mas o mais poderoso é que o CLAUDE.md (na raiz do repo) funciona como o **cérebro central**
que ensina o Claude Code a USAR esses arquivos automaticamente.

---

## 2. Deploy: Passo a Passo

### 2.1 — Preparar o Repo

```bash
cd ~/aios-core  # seu repo

# Criar estrutura de commands
mkdir -p .claude/commands/{HackerVerso,Copy,Traffic,Data,Storytelling,Legal,Design,Cyber,Database,DesignSystem,Tools}/agents

# Criar estrutura de squads
mkdir -p squads/{hackerverso,copy-chief,traffic-masters,data-intelligence,storytelling,legal,design,cyber,db-sage,design-system,tools}/{tasks,templates,checklists,data}
```

### 2.2 — Extrair os Pacotes

```bash
# Extrair cada fase (ajustar caminhos conforme onde salvou os zips)
unzip aios-phase2-traffic-data-package.zip -d /tmp/phase2
unzip aios-phase3-story-legal-package.zip -d /tmp/phase3
unzip aios-phase4-design-cyber-package.zip -d /tmp/phase4
unzip aios-phase5-final-package.zip -d /tmp/phase5

# Phase 2
cp /tmp/phase2/commands/Traffic/agents/*.md .claude/commands/Traffic/agents/
cp /tmp/phase2/commands/Data/agents/*.md .claude/commands/Data/agents/
cp -r /tmp/phase2/squads/traffic-masters/* squads/traffic-masters/
cp -r /tmp/phase2/squads/data-intelligence/* squads/data-intelligence/

# Phase 3
cp /tmp/phase3/phase3/commands/Storytelling/agents/*.md .claude/commands/Storytelling/agents/
cp /tmp/phase3/phase3/commands/Legal/agents/*.md .claude/commands/Legal/agents/
cp -r /tmp/phase3/phase3/squads/storytelling/* squads/storytelling/
cp -r /tmp/phase3/phase3/squads/legal/* squads/legal/

# Phase 4
cp /tmp/phase4/phase4/commands/Design/agents/*.md .claude/commands/Design/agents/
cp /tmp/phase4/phase4/commands/Cyber/agents/*.md .claude/commands/Cyber/agents/
cp -r /tmp/phase4/phase4/squads/design/* squads/design/
cp -r /tmp/phase4/phase4/squads/cyber/* squads/cyber/

# Phase 5
cp /tmp/phase5/phase5/commands/Database/agents/*.md .claude/commands/Database/agents/
cp /tmp/phase5/phase5/commands/DesignSystem/agents/*.md .claude/commands/DesignSystem/agents/
cp /tmp/phase5/phase5/commands/Tools/agents/*.md .claude/commands/Tools/agents/
cp -r /tmp/phase5/phase5/squads/db-sage/* squads/db-sage/
cp -r /tmp/phase5/phase5/squads/design-system/* squads/design-system/
cp -r /tmp/phase5/phase5/squads/tools/* squads/tools/
```

### 2.3 — Para Phase 0 (HackerVerso) e Phase 1 (Copy-Chief)

Se já estão no repo, apenas confirmar que estão em:
```
.claude/commands/HackerVerso/agents/*.md
.claude/commands/Copy/agents/*.md
squads/hackerverso/*
squads/copy-chief/*
```

### 2.4 — Copiar o CLAUDE.md

```bash
# O arquivo mais importante — copiar CLAUDE.md para a raiz do repo
cp CLAUDE.md ~/aios-core/CLAUDE.md
```

### 2.5 — Verificar

```bash
# Contar arquivos
find .claude/commands -name "*.md" | wc -l  # deve ser ~92
find squads -name "*.md" | wc -l             # deve ser ~166
cat CLAUDE.md | head -5                       # deve mostrar o header do AIOS
```

---

## 3. Como Usar no Claude Code

### 3.1 — Abrir o Claude Code no repo

```bash
cd ~/aios-core
claude
```

O Claude Code automaticamente lê o CLAUDE.md e conhece TODO o sistema.

### 3.2 — Invocar Chiefs (linguagem natural)

Você NÃO precisa usar slash commands. O CLAUDE.md ensina o Claude a rotear automaticamente:

```
> Preciso criar uma campanha de Meta Ads pro meu curso de finanças

Claude vai:
1. Ler o CLAUDE.md → identifica que é Traffic
2. Carregar .claude/commands/Traffic/agents/traffic-masters-chief.md
3. O chief roteia para @nicholas-kusmich (Meta) + @ralph-burns (criativos)
4. Carregar squads/traffic-masters/tasks/meta-campaign.md
5. Executar step by step
```

### 3.3 — Invocar via Slash Commands (direto)

```
/project:Traffic:agents:traffic-masters-chief
/project:Copy:agents:copy-chief
/project:Storytelling:agents:story-chief
/project:Legal:agents:legal-chief
/project:Design:agents:design-chief
/project:Cyber:agents:cyber-chief
/project:Database:agents:db-sage
/project:DesignSystem:agents:design-system-chief
/project:Tools:agents:tools-orchestrator
```

### 3.4 — Carregar Agents Específicos

```
/project:Traffic:agents:molly-pittman
/project:Copy:agents:gary-halbert
/project:Storytelling:agents:donald-miller
/project:Database:agents:supabase-architect
```

### 3.5 — Workflow Completo (exemplo)

```
Usuário: "Quero lançar um infoproduto de emagrecimento com sucos"

Claude (com CLAUDE.md):
1. @hackerverso-chief → avatar, positioning, mechanism
2. @story-chief → @donald-miller → BrandScript SB7
3. @copy-chief → sales page, email sequence, VSL
4. @design-chief → landing page, brand identity
5. @traffic-masters-chief → Meta Ads, YouTube
6. @data-chief → North Star, AARRR, Health Score
7. @legal-chief → LGPD, compliance, claims
8. @cyber-chief → security baseline
9. @db-sage → schema Supabase
10. @tools-orchestrator → n8n automações
```

---

## 4. Alternativa: Skills (Recomendado para Novas Versões)

O Claude Code agora suporta **Skills** (`.claude/skills/`) que são mais poderosos.
Para converter commands em skills:

```bash
# Para cada chief, criar skill directory
mkdir -p .claude/skills/traffic-masters/
# Mover o chief como SKILL.md
cp .claude/commands/Traffic/agents/traffic-masters-chief.md .claude/skills/traffic-masters/SKILL.md
# Adicionar frontmatter
```

Adicionar frontmatter no topo do SKILL.md:
```yaml
---
name: traffic-masters
description: "Gestão de tráfego pago. Use quando o usuário mencionar Meta Ads, Google Ads, YouTube Ads, campanhas, tráfego, CPA, ROAS, escalar, criativos."
---
```

Com skills, o Claude Code **auto-detecta** quando usar cada chief baseado na descrição.

---

## 5. Estrutura Final do Repo

```
aios-core/
├── CLAUDE.md                          ← CÉREBRO CENTRAL
├── .claude/
│   ├── commands/                      ← AGENT PERSONAS (slash commands)
│   │   ├── HackerVerso/agents/        (10 agents)
│   │   ├── Copy/agents/               (12 agents)
│   │   ├── Traffic/agents/            (8 agents)
│   │   ├── Data/agents/               (7 agents)
│   │   ├── Storytelling/agents/       (13 agents)
│   │   ├── Legal/agents/              (8 agents)
│   │   ├── Design/agents/             (8 agents)
│   │   ├── Cyber/agents/              (8 agents)
│   │   ├── Database/agents/           (7 agents)
│   │   ├── DesignSystem/agents/       (6 agents)
│   │   └── Tools/agents/              (5 agents)
│   └── settings.json                  ← Config do Claude Code
├── squads/                            ← OPERATIONAL FILES
│   ├── hackerverso/                   (tasks, templates, checklists, data)
│   ├── copy-chief/
│   ├── traffic-masters/
│   ├── data-intelligence/
│   ├── storytelling/
│   ├── legal/
│   ├── design/
│   ├── cyber/
│   ├── db-sage/
│   ├── design-system/
│   └── tools/
└── src/                               ← SEU CÓDIGO
```
