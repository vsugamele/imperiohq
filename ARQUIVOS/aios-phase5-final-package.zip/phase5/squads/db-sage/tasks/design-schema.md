# Task: Design Schema

## Metadata
- **Agent:** @codd-normalizer
- **Tier:** 0

## Input
```yaml
required:
  - domain: "O que o sistema faz"
  - entities: "Entidades principais (users, orders, products, etc.)"
  - requirements: "Requisitos de negócio"
```

## Instruções

### Step 1 — Entity Identification
Listar todas as entidades e seus atributos.

### Step 2 — Relationship Mapping
Definir relações: 1:1, 1:N, N:N com junction tables.

### Step 3 — Normalize to 3NF
Verificar cada tabela contra 1NF, 2NF, 3NF. Corrigir violações.

### Step 4 — Anti-Pattern Check
Verificar contra anti-patterns comuns.

### Step 5 — SQL DDL
Gerar CREATE TABLE statements com constraints, indexes, triggers.

## Output Schema
```yaml
schema:
  tables: [{name: "", columns: [{name: "", type: "", constraints: ""}], indexes: [], rls: []}]
  relationships: [{from: "", to: "", type: "", fk: ""}]
  migrations: ["CREATE TABLE ..."]
  anti_patterns: [{found: "", fix: ""}]
```
