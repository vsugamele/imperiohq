# Task: Optimize Database Performance

## Metadata
- **Agent:** @index-optimizer + @joe-celko
- **Tier:** 2

## Input
```yaml
required:
  - slow_queries: "Queries que estão lentas"
  - table_sizes: "Tamanho aproximado das tabelas"
```

## Instruções

### Step 1 — EXPLAIN ANALYZE
Rodar EXPLAIN ANALYZE em cada slow query. Identificar:
- Seq Scans em tabelas grandes
- Missing indexes
- Inefficient JOINs
- N+1 patterns

### Step 2 — Index Strategy
Criar indexes necessários (B-tree, GIN, partial, composite).

### Step 3 — Query Rewrite (@joe-celko)
Reescrever queries: set-based, CTEs, window functions.

### Step 4 — Cache Layer (@redis-specialist, se necessário)
Identificar queries que beneficiam de cache.

## Output Schema
```yaml
optimization:
  queries: [{original: "", optimized: "", improvement: ""}]
  indexes: [{table: "", columns: [], type: "", rationale: ""}]
  cache: [{query_pattern: "", ttl: "", strategy: ""}]
  estimated_improvement: ""
```
