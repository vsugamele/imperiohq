# Task: Setup Supabase Project

## Metadata
- **Agent:** @supabase-architect
- **Tier:** 1
- **depends_on:** design-schema

## Input
```yaml
required:
  - schema: "Output do design-schema"
  - auth_providers: "email | google | github | magic_link"
  - rls_requirements: "Quem pode ver/editar o quê"
```

## Instruções

### Step 1 — Create Tables
Aplicar DDL do schema design no Supabase.

### Step 2 — Enable RLS
Habilitar RLS em TODAS as tabelas. Criar policies:
- Public read (se aplicável)
- Owner CRUD (user can manage own data)
- Admin full access

### Step 3 — Auth Configuration
Configurar providers, redirect URLs, email templates.

### Step 4 — Database Functions
- update_updated_at trigger
- Soft delete function (se aplicável)
- Custom functions para business logic

### Step 5 — Storage Buckets
Configurar buckets com policies de acesso.

### Step 6 — Edge Functions
Setup para webhook handlers, integrations.

## Output Schema
```yaml
supabase_setup:
  tables: [{name: "", rls_enabled: true, policies: []}]
  auth: {providers: [], settings: {}}
  functions: [{name: "", trigger: "", sql: ""}]
  storage: [{bucket: "", public: true/false, policies: []}]
  edge_functions: [{name: "", purpose: ""}]
```
