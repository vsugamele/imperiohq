# Task: Create Migration

## Metadata
- **Agent:** @migration-engineer
- **Tier:** 2

## Input
```yaml
required:
  - change: "O que precisa mudar no schema"
  - current_data: "Tem dados em produção? Quantos rows?"
```

## Instruções

### Step 1 — Assess Risk
Classificar a migration: low | medium | high risk.

### Step 2 — Write UP migration
SQL para aplicar a mudança.

### Step 3 — Write DOWN migration
SQL para reverter a mudança.

### Step 4 — Data Migration (se necessário)
Script para migrar dados existentes.

### Step 5 — Rollback Plan
O que fazer se der errado.

## Output Schema
```yaml
migration:
  name: ""
  risk: "low | medium | high"
  up: "SQL"
  down: "SQL"
  data_migration: {needed: true/false, script: "", batch_size: 0}
  rollback: ""
  estimated_time: ""
```
