# Checklist: Schema Review

## Normalization
- [ ] All tables in 3NF (no transitive dependencies)
- [ ] No God Tables (>20 columns → consider decomposition)
- [ ] No EAV anti-pattern
- [ ] Proper junction tables for N:N relationships

## Naming
- [ ] Tables plural, snake_case
- [ ] Columns singular, snake_case
- [ ] FKs follow {table_singular}_id pattern
- [ ] Consistent naming across schema

## Required Columns
- [ ] Every table has id (UUID or bigint)
- [ ] Every table has created_at (timestamptz)
- [ ] Every table has updated_at (timestamptz with trigger)
- [ ] Soft delete tables have deleted_at

## Indexes
- [ ] All FKs indexed
- [ ] Frequently queried columns indexed
- [ ] No over-indexing on write-heavy tables
- [ ] Composite indexes ordered by selectivity

## Security (Supabase)
- [ ] RLS enabled on ALL tables
- [ ] Policies cover SELECT, INSERT, UPDATE, DELETE
- [ ] No policy allows unrestricted access
- [ ] Service role key NEVER exposed to client

## Constraints
- [ ] NOT NULL where appropriate
- [ ] CHECK constraints for valid values
- [ ] UNIQUE constraints where needed
- [ ] FK constraints with proper ON DELETE behavior

## Score
```
Normal: ___/4  Naming: ___/4  Columns: ___/4
Indexes: ___/4  Security: ___/4  Constraints: ___/4
Total: ___/24

≥20: Ship it
15-19: Minor fixes
<15: Significant revision needed
```
