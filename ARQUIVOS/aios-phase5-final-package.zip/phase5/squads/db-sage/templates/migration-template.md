# Template: Migration

## Migration: {YYYYMMDDHHMMSS}_{description}

### UP
```sql
-- Description: {what this migration does}
-- Risk: {low | medium | high}
-- Estimated time: {X seconds on Y rows}

BEGIN;

-- Changes here
ALTER TABLE {table} ADD COLUMN {column} {type} DEFAULT {value};

-- Data migration (if needed)
-- UPDATE {table} SET {column} = {value} WHERE {condition};

COMMIT;
```

### DOWN
```sql
-- Rollback
BEGIN;

ALTER TABLE {table} DROP COLUMN {column};

COMMIT;
```

### Checklist
- [ ] Tested on staging with production-size data
- [ ] DOWN migration tested
- [ ] No breaking changes to existing queries
- [ ] Indexes added for new queryable columns
- [ ] RLS policies updated if needed
