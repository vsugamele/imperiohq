# Template: Database Schema

## Table: {table_name}
```sql
CREATE TABLE {table_name} (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  -- columns here
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at TIMESTAMPTZ -- soft delete (nullable)
);

-- Indexes
CREATE INDEX idx_{table_name}_{column} ON {table_name}({column});

-- Updated_at trigger
CREATE TRIGGER set_updated_at
  BEFORE UPDATE ON {table_name}
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- RLS
ALTER TABLE {table_name} ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own" ON {table_name}
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own" ON {table_name}
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own" ON {table_name}
  FOR UPDATE USING (auth.uid() = user_id);
```

## Naming Conventions
- Tables: plural, snake_case (users, order_items)
- Columns: singular, snake_case (first_name, created_at)
- PKs: id (UUID)
- FKs: {table_singular}_id (user_id)
- Indexes: idx_{table}_{column}
- Policies: descriptive string
