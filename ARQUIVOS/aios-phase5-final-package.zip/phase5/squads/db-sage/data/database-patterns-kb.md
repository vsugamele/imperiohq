# Knowledge Base: Database Patterns

## PostgreSQL Data Types (most used)
- UUID: gen_random_uuid() — IDs
- TEXT: unbounded strings
- VARCHAR(N): bounded strings
- INTEGER / BIGINT: numbers
- NUMERIC(p,s): precise decimals (money)
- BOOLEAN: true/false
- TIMESTAMPTZ: dates with timezone (ALWAYS use TZ)
- JSONB: flexible structured data (indexable)
- TEXT[]: arrays
- ENUM: defined set of values

## Index Types
B-tree (default, equality/range), GIN (JSONB/arrays/full-text), GiST (geometric/range), Hash (equality only), Partial (WHERE clause), Composite (multi-column), Covering (INCLUDE)

## RLS Quick Reference (Supabase)
```sql
-- Enable
ALTER TABLE t ENABLE ROW LEVEL SECURITY;
-- Read own
CREATE POLICY "read_own" ON t FOR SELECT USING (auth.uid() = user_id);
-- Admin all
CREATE POLICY "admin_all" ON t FOR ALL USING (is_admin());
-- Public read
CREATE POLICY "public_read" ON t FOR SELECT USING (true);
```

## Query Patterns
- CTE: WITH ... AS (SELECT ...) for readability
- Window: ROW_NUMBER(), SUM() OVER for analytics
- Recursive CTE: tree/hierarchy traversal
- UPSERT: INSERT ... ON CONFLICT DO UPDATE
- Lateral Join: correlated subquery in FROM

## Performance Rules
1. Never SELECT *
2. Index all FKs
3. EXPLAIN ANALYZE before optimizing
4. EXISTS > IN for subqueries
5. Batch operations (not row-by-row)
6. Connection pooling (PgBouncer/Supavisor)

## Supabase Specifics
- PostgREST: auto-generates API from schema
- Realtime: WebSocket subscriptions on table changes
- Edge Functions: Deno runtime for server-side logic
- Storage: S3-compatible with RLS policies
- Auth: GoTrue-based, JWT tokens
