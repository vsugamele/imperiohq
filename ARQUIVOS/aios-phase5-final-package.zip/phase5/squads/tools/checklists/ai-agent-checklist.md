# Checklist: AI Agent Quality

## Prompt Design
- [ ] Clear role definition
- [ ] Specific instructions (not vague)
- [ ] Output format defined (YAML/JSON)
- [ ] Examples provided (few-shot)
- [ ] Guardrails (ALWAYS/NEVER rules)

## Architecture
- [ ] Single responsibility per agent
- [ ] Routing logic clear and tested
- [ ] Chain steps validated
- [ ] Context window managed (not overflowing)
- [ ] Model selection appropriate (cost vs quality)

## Tools & MCP
- [ ] MCP servers connected and tested
- [ ] Tool access scoped (least privilege)
- [ ] Tool errors handled gracefully
- [ ] Fallback if tool unavailable

## Quality
- [ ] Output validated against schema
- [ ] Human-in-the-loop for critical decisions
- [ ] Monitoring of agent performance
- [ ] Cost tracking per agent/chain
- [ ] Regular prompt refinement

## Score
```
Prompt: ___/5  Architecture: ___/5
Tools: ___/4  Quality: ___/5
Total: ___/19

≥16: Production ready
12-15: Needs refinement
<12: Not ready
```
