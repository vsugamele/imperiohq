# Checklist: Automation Quality

## Design
- [ ] Clear trigger defined
- [ ] All steps documented
- [ ] Error handling for each step
- [ ] Idempotent (running twice = same result)
- [ ] Edge cases identified

## Integration
- [ ] API credentials stored securely (not in workflow)
- [ ] Rate limits respected (delays/batching)
- [ ] Webhook signatures verified
- [ ] Data mapping validated
- [ ] Timeout handling

## Reliability
- [ ] Retry strategy configured (3x exponential)
- [ ] Dead letter queue for failed items
- [ ] Alert on failure (Slack/email)
- [ ] Monitoring dashboard
- [ ] Manual trigger available for testing

## Performance
- [ ] Batch processing for large datasets
- [ ] Async where possible
- [ ] No unnecessary API calls
- [ ] Connection pooling (if DB)

## Documentation
- [ ] Workflow purpose documented
- [ ] Input/output format documented
- [ ] Error scenarios documented
- [ ] Recovery procedures documented

## Score
```
Design: ___/5  Integration: ___/5  Reliability: ___/5
Performance: ___/4  Documentation: ___/4
Total: ___/23

≥19: Production ready
14-18: Needs improvements
<14: Not ready
```
