# Knowledge Base: Tools Ecosystem

## Automation Platforms
| Platform | Best For | Cost |
|----------|---------|------|
| n8n (self-hosted) | Full control, complex workflows | Free (self-host) |
| n8n Cloud | Managed n8n | $20+/mo |
| Zapier | Simple, non-technical users | $20+/mo |
| Make (Integromat) | Visual, mid-complexity | $10+/mo |

## AI/LLM APIs
| Provider | Models | Best For |
|----------|--------|---------|
| Anthropic | Claude Opus/Sonnet/Haiku | Reasoning, coding, analysis |
| OpenAI | GPT-4o, o1 | General purpose, vision |
| Google | Gemini | Multimodal, long context |

## Common Integrations (BR Infoproduto Stack)
| Category | Tools |
|----------|-------|
| Payment | Hotmart, Kiwify, Eduzz, Asaas, Stripe |
| Email | ActiveCampaign, RD Station, Mailchimp, Resend |
| Messaging | WhatsApp Business API, Telegram Bot, Discord |
| CRM | RD Station, HubSpot, Pipedrive |
| Database | Supabase, Firebase, Airtable |
| Storage | Supabase Storage, Cloudflare R2, S3 |
| Analytics | GA4, Mixpanel, PostHog |
| Social | Meta Graph API, YouTube Data API |

## MCP Servers Available
Supabase, Notion, Canva, Figma, Stripe, Vercel, n8n, Crypto.com, Mermaid Chart

## Integration Patterns
- Webhook: event-driven, real-time
- Polling: schedule-based, simpler
- Queue: async processing, reliable
- Stream: real-time data flow

## Error Handling
- Retry: 3x exponential backoff (1s, 4s, 16s)
- Dead Letter: store failed items for review
- Circuit Breaker: stop calls to failing service
- Fallback: alternative action on failure
