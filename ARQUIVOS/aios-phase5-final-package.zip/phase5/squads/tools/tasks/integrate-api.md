# Task: Integrate External API

## Metadata
- **Agent:** @api-integrator
- **Tier:** 1

## Input
```yaml
required:
  - service: "Nome do serviço"
  - purpose: "Para que integrar"
  - endpoints: "Quais endpoints usar"
```

## Instruções

### Step 1 — API Research
Documentação, auth method, rate limits, webhooks.

### Step 2 — Authentication Setup
Configurar auth (API key, OAuth2, JWT).

### Step 3 — Data Mapping
Mapear campos entre sistemas.

### Step 4 — Implementation
Código de integração com error handling.

### Step 5 — Webhook Setup (se disponível)
Configurar webhooks para eventos.

## Output Schema
```yaml
integration:
  service: ""
  auth: {}
  endpoints: [{method: "", path: "", data_map: {}}]
  webhooks: [{event: "", handler: ""}]
  error_handling: {}
```
