# Task: Create n8n Workflow

## Metadata
- **Agent:** @n8n-specialist
- **Tier:** 1

## Input
```yaml
required:
  - purpose: "O que o workflow faz"
  - trigger: "webhook | schedule | manual | db_change"
  - integrations: "Quais serviços conectar"
```

## Instruções

### Step 1 — Trigger Node
Configurar trigger com parâmetros corretos.

### Step 2 — Processing Nodes
Data transformation, API calls, logic.

### Step 3 — Output Nodes
Enviar resultado (email, Slack, DB update, webhook).

### Step 4 — Error Handling
Error trigger → log + alert + retry strategy.

### Step 5 — Testing
Test com dados reais, validar edge cases.

## Output Schema
```yaml
n8n:
  name: ""
  nodes: [{type: "", config: {}, connections: []}]
  error_handling: {}
  test_cases: [{input: "", expected_output: ""}]
```
