# Task: Design Automation Workflow

## Metadata
- **Agent:** @automation-architect
- **Tier:** 0

## Input
```yaml
required:
  - process: "O processo manual atual"
  - trigger: "O que inicia o processo"
  - frequency: "Quantas vezes por dia/semana"
  - tools: "Ferramentas envolvidas"
```

## Instruções

### Step 1 — Process Mapping
Mapear o processo atual step-by-step.

### Step 2 — Automation Score
Frequência × Tempo × Erro × Repetitividade = Score.

### Step 3 — Workflow Design
Trigger → Processing → Output com error handling.

### Step 4 — Tool Selection
Qual plataforma? n8n, Supabase Edge Functions, custom code?

### Step 5 — Implementation Plan

## Output Schema
```yaml
automation:
  process: ""
  score: 0-100
  workflow: {trigger: "", steps: [], error_handling: ""}
  tools: [{name: "", purpose: ""}]
  estimated_savings: "X hours/week"
```
