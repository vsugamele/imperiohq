# Task: Setup AI Multi-Agent System

## Metadata
- **Agent:** @ai-orchestrator
- **Tier:** 2

## Input
```yaml
required:
  - use_case: "O que o sistema AI faz"
  - agents_needed: "Quantos agentes e quais papéis"
  - tools: "Quais ferramentas os agentes precisam (MCP, APIs)"
```

## Instruções

### Step 1 — Agent Design
Definir cada agent: role, system prompt, model, tools.

### Step 2 — Routing Strategy
Como o router decide qual agent usar.

### Step 3 — MCP Configuration
Configurar MCP servers para tool access.

### Step 4 — Chain/Pipeline Design
Definir sequência de agent calls.

### Step 5 — Quality Gates
Validação de output em cada step.

## Output Schema
```yaml
ai_system:
  agents: [{name: "", role: "", model: "", prompt: "", tools: []}]
  router: {strategy: "", rules: []}
  mcp_servers: [{name: "", url: ""}]
  chains: [{name: "", steps: []}]
  quality_gates: [{step: "", validation: ""}]
```
