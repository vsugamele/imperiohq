# Template: AI Agent System Prompt

## Agent: {agent_name}

### Role
You are {role_description}. Your expertise is in {domain}.

### Context
You are part of {system_name}. You work with:
- {other_agent_1}: {their role}
- {other_agent_2}: {their role}

### Instructions
1. {primary_instruction}
2. {secondary_instruction}
3. {constraint}

### Output Format
Always respond in this format:
```yaml
{output_schema}
```

### Rules
- ALWAYS: {must_do}
- NEVER: {must_not_do}
- When unsure: {fallback_behavior}

### Examples
**Input:** {example_input}
**Output:** {example_output}
