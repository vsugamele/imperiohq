# Template: Automation Workflow Brief

## Workflow Info
- **Name:** {name}
- **Purpose:** {what it automates}
- **Trigger:** {webhook | schedule | manual | event}
- **Frequency:** {how often it runs}

## Current Manual Process
1. {step 1}
2. {step 2}
3. {step 3}
Time per execution: {X minutes}

## Automated Workflow
```
[Trigger] → [Step 1] → [Step 2] → [Output]
                ↓ (on error)
            [Error Handler] → [Alert]
```

## Integrations Required
| Service | Purpose | Auth |
|---------|---------|------|
| {service} | {purpose} | {auth_type} |

## Error Handling
- Retry: {X} attempts with {strategy} backoff
- Alert: {Slack/email} on failure
- Dead Letter: {yes/no}

## Success Criteria
- [ ] Runs without manual intervention
- [ ] Handles errors gracefully
- [ ] Monitoring active
- [ ] Saves {X} hours/week
