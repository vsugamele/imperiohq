# Template: Component Documentation

## {ComponentName}

### Description
{What this component does and when to use it}

### Props
| Prop | Type | Default | Description |
|------|------|---------|-------------|
| variant | "primary" \| "secondary" \| "ghost" | "primary" | Visual style |
| size | "sm" \| "md" \| "lg" | "md" | Component size |
| disabled | boolean | false | Disable interaction |

### Variants
- **primary:** {when to use}
- **secondary:** {when to use}
- **ghost:** {when to use}

### Usage
```tsx
<{ComponentName} variant="primary" size="md">
  Click me
</{ComponentName}>
```

### Accessibility
- Role: {role}
- Keyboard: {keys}
- ARIA: {attributes}

### Do's and Don'ts
✅ Do: {good usage}
❌ Don't: {bad usage}
