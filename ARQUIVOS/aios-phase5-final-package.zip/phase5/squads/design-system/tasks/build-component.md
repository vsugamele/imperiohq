# Task: Build Component

## Metadata
- **Agent:** @component-engineer + @a11y-guardian
- **Tier:** 0 + 2

## Input
```yaml
required:
  - component_name: "Nome do componente"
  - purpose: "Para que serve"
  - variants: "Quais variações precisa"
```

## Instruções

### Step 1 — API Design (@component-engineer)
Props, variants, states, composition.

### Step 2 — Implementation
React + Tailwind + CVA pattern.

### Step 3 — Accessibility (@a11y-guardian)
ARIA, keyboard, focus management.

### Step 4 — Documentation
Props table, examples, do's and don'ts.

## Output Schema
```yaml
component:
  name: ""
  code: ""
  props: [{name: "", type: "", default: ""}]
  variants: {}
  a11y: {role: "", aria: [], keyboard: []}
  examples: []
```
