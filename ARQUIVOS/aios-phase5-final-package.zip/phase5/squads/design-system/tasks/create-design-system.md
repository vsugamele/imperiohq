# Task: Create Design System

## Metadata
- **Agent:** @token-architect → @component-engineer → @tailwind-master
- **Tier:** 0 → 1

## Input
```yaml
required:
  - brand_identity: "Colors, fonts, logo (from Design-Chief)"
  - platform: "web | mobile | both"
  - framework: "React + Tailwind (default)"
```

## Instruções

### Step 1 — Tokens (@token-architect)
Create complete token system: colors (global → semantic → component), spacing (8px grid), typography, radii, shadows, with dark mode mapping.

### Step 2 — Tailwind Config (@tailwind-master)
Map tokens to tailwind.config.js. Install plugins.

### Step 3 — Component Catalog (@component-engineer)
Define P0 components with variants, states, props, a11y.

### Step 4 — shadcn Setup (@shadcn-specialist)
Install shadcn/ui, add P0 components, customize with tokens.

### Step 5 — A11y Baseline (@a11y-guardian)
Verify all components pass WCAG 2.1 AA.

## Output Schema
```yaml
design_system:
  tokens: {colors: {}, spacing: {}, typography: {}, radii: {}, shadows: {}}
  tailwind_config: {}
  components: [{name: "", variants: [], a11y: {}}]
  setup_commands: []
```
