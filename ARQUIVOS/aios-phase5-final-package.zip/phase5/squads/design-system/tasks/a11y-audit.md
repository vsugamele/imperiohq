# Task: Accessibility Audit

## Metadata
- **Agent:** @a11y-guardian
- **Tier:** 2

## Input
```yaml
required:
  - target: "URL ou componente"
  - level: "A | AA | AAA"
```

## Instruções

### Step 1 — Automated Scan
axe-core + Lighthouse accessibility.

### Step 2 — Manual Testing
Keyboard navigation, focus order, screen reader.

### Step 3 — Color Contrast
Check all text/background combinations.

### Step 4 — Remediation Plan

## Output Schema
```yaml
a11y_audit:
  score: 0-100
  level: "A | AA | AAA"
  issues: [{rule: "", severity: "", element: "", fix: ""}]
  keyboard: {pass: true/false, issues: []}
  contrast: [{element: "", ratio: "", pass: true/false}]
  remediation: [{priority: 1-N, issue: "", fix: "", effort: ""}]
```
