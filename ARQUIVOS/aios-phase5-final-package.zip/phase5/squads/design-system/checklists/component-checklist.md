# Checklist: Component Quality

## API Design
- [ ] Single responsibility (1 purpose)
- [ ] Props are typed and documented
- [ ] Default values for optional props
- [ ] Consistent with other components in system

## Variants & States
- [ ] All variants visually distinct
- [ ] States: default, hover, active, focus, disabled
- [ ] Loading state (if async)
- [ ] Error state (if applicable)
- [ ] Empty state (if data-dependent)

## Accessibility
- [ ] Semantic HTML (button, not div)
- [ ] ARIA attributes where needed
- [ ] Keyboard navigable
- [ ] Focus visible
- [ ] Color contrast ≥ 4.5:1
- [ ] Screen reader tested

## Responsive
- [ ] Works on mobile (320px+)
- [ ] Touch targets ≥ 44x44px
- [ ] No horizontal overflow

## Code Quality
- [ ] Uses design tokens (no hardcoded values)
- [ ] Uses CVA for variants
- [ ] Composable (works with other components)
- [ ] No unnecessary dependencies

## Score
```
API: ___/4  States: ___/5  A11y: ___/6
Responsive: ___/3  Code: ___/4
Total: ___/22

≥18: Ship it
14-17: Minor fixes
<14: Needs revision
```
