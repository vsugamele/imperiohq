# Knowledge Base: Component Patterns

## CVA (Class Variance Authority)
```tsx
const component = cva("base-classes", {
  variants: { intent: {...}, size: {...} },
  defaultVariants: { intent: "primary", size: "md" }
})
```

## Composition Patterns
- Compound: <Select><Select.Option> (complex UIs)
- Polymorphic: as="a" prop (change rendered element)
- Slots: named areas for flexible content
- Render Props: when child needs parent state

## shadcn/ui Components
Forms: Button, Input, Label, Select, Textarea, Checkbox, Form
Feedback: Alert, Toast (Sonner), Progress, Skeleton
Nav: Tabs, NavigationMenu, Breadcrumb, Command
Display: Table, Card, Badge, Avatar, Separator
Overlay: Dialog, Sheet, Popover, Tooltip, DropdownMenu

## ARIA Quick Reference
- button: role="button" (native <button> preferred)
- aria-label: for icon-only interactive elements
- aria-describedby: for help text
- aria-expanded: for collapsible sections
- aria-live="polite": for dynamic content updates
- role="alert": for important messages

## Keyboard Patterns
Button: Enter/Space | Modal: Escape close, focus trap
Tabs: Arrow keys switch | Dropdown: Arrow keys, Enter select, Escape close

## Tailwind Class Order
Layout → Sizing → Spacing → Typography → Colors → Effects → States
```
